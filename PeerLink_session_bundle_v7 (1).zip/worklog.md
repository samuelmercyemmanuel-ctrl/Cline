# Worklog — Multi-Agent Shared Log

---
Task ID: 0
Agent: main (Super Z)
Task: Recover previous session's simulation-replication work and deliver the zip the user was promised.

Work Log:
- Searched /home/z/my-project/ (download/, scripts/, upload/, skills/), /home/z (all dotdirs), /tmp, git repo (log, reflog, stash, branches), and shell history.
- Read /tmp/boot-timeline.log: this container was freshly initialized at 2026-09-05T15:10:59Z ("Project initialization check" → skills extraction → git init → initial scaffold commit). 
- Git contains only the scaffold commit (f11747f: .env, .gitignore, download/README.md). No worklog, no shell history, no uploads, no simulation code, no zip anywhere on disk (only library-internal archives under .venv and /home/official_skills/).

Stage Summary:
- HARD BLOCKER: The previous conversation ran in a different container instance. This environment is a fresh boot; ALL prior work (simulation source, replica code, any zip produced) is unrecoverable from this machine.
- The conversation-level summary of the prior session was also empty (placeholder only), so the identity of the simulation (name/domain/source) is unknown from context as well.
- No zip exists because there is nothing to zip yet. Fabricating a fake deliverable would violate the user's "exact, zero mistakes" requirement.
- Required from user to unblock: the original simulation source — uploaded file(s), a URL to the original, or a precise description. Once received: rebuild 1:1, verify behavior equivalence, zip ALL code + progress, deliver.

---
Task ID: 1
Agent: main (Super Z)
Task: Recover all PeerLink artifacts from scratch (fresh container)

Work Log:
- Cloned github.com/EdenAlpha/Peerlink1 (handoff doc + qwesys decoders + Session-A bundle, 43 files)
- Installed unicorn 2.1.4 / capstone 5.0.9 / pyelftools 0.33 into /home/z/.venv
- Found eFootball 11.0.1 (versionCode 311000101) .apks on APKCombo; wrote surgical ranged downloader (scripts/apks_surgical_download.py + scripts/inner_apk_remote.py)
- Downloaded config.arm64_v8a.apk (57MB) -> libUE4.so: SHA-256 2ac4ff17ac8ad713d9531c2601e38a3c8335e02ea882ba2dc4445c191c1298cd == PINNED HASH (exact Konami build)
- Pulled dt270_mobile_all.cpk (18MB) from pad_it_0.apk asset pack; extracted all 81 files (21 tutorial replay pairs + constants)
- Decoded constant_match.bin (QWESYS) -> ball.o 1040B, ball.o[0x30]=0x00, float 7.5 @ 0x2c and 0x140 (drag) - all match transcript pins
- Restored canonical layout: apk_lab/libUE4.so, apk_lab/analysis/*.{npz,json,asm}, scripts/*.py, apk_lab/cpk/dt270_out/...

Stage Summary:
- FULL ARTIFACT RECOVERY COMPLETE. The exact binary, the replay oracle corpus, ball.o, static-analysis DBs and Session-A scripts are all present and hash-verified. Environment: 8.9G disk free (prior session died at 100% full - now safe).
- Next: Milestone-1 regression (uc_loader selftest + ball_poc), then rebuild lost Milestone-2/3 harnesses, then advance to paramsB construction.

---
Task ID: 2
Agent: main (Super Z)
Task: Rebuild lost Milestone-2 harness (real ball object + bit-exact validation)

Work Log:
- Wrote scripts/uc_loader2.py (enhanced loader): PROT/FETCH_PROT fault coverage, GOT hijack via plt_map (operator new/delete), zeroing allocator, posix_memalign/pthread/vsnprintf real stubs, neutralize(), per-address watchers with removal, component-manager/substep-global/registry fabricators
- Wrote scripts/ball_object_run.py (M2 harness): hybrid construction via 6a35434 semantics (alloc 0x14B8 -> 6e92768 base ctor -> 6e91da8 module ctor), holder wiring before module ctor, tick via ball_update_entry 0x6e938a0
- Neutralization set derived empirically: 6e921a0 (ICU factory +0x498), 6e92228 (ICU factory +0x358/+0x3a8), 68b24c4 (registration ctor +0x3f8), 6e920e0 (match-setup reader, abort path via 68c8c14->68ce104->ICU)
- F0 PASS: construction clean, both 296B states init with y = exact ground radius 0.1086859330534935
- DECODED the observer layer: chain_top builds 4 observers from holder; observer[0] = state publisher: pre-hook writes 12-byte placement per substep via 6a6b604 into trajectory recorder target, snapshots state into obs+0x10 on LAST substep (gate: [0x9959f98]-1 == idx), finish publishes obs+0x10 via memcpy
- ROOT CAUSE of stale output: [0x9959f98] never set (0) -> snapshot never fired -> construction ground state published. Fixed: set_N writes BOTH 0x98dddc8 chain and 0x9959f98
- ROOT CAUSE of ground-contact crash: component lookup 6ea0874 -> 68d3cc0 -> 68d3cb8 does ldr x0,[x0,#8] - component HOLDS A POINTER to params. Fixed: *(C+8) = P, ball.o installed at P (not inline at C+8). Auto-zero pages had masked this as zero-drag (why F1 trivially passed at v=0)
- F1 PASS bit-exact (0 byte diffs, N-1 rule); FC PASS: commit rule = N-1 confirmed for N=2,3,5,8 (0 diffs)
- Fixed tick_feedback order (tick then feed) and watcher accumulation bug

Stage Summary:
- M2 harness rebuilt, F0/F1/FC green with REAL params (ball.o via proper pointer). Full F2/F3/FB suite running. Physics through object path reproduces reference values (tick0: y=2.9865, vy=-0.3632).
- KEY NEW DECODES this session: observer[0] publish mechanism, [0x9959f98] last-substep snapshot gate (= N-1 commit rule root cause), 68d3cb8 component pointer dereference, 6a35434 exact construction sequence, 6a35688 driven driver (6e93aec state installer: pos->+0x30, 0x700->+0x90, quat->+0x98).

---
Task ID: 3
Agent: main (Super Z)
Task: Finish Milestone 3 (replay flight fit) and deliver the permanent download link the user demanded.

Work Log:
- Verified container survival + M2 suite re-run: ALL PASS (F2 30/30 0-diffs, FB peaks 2.0458/1.4216/0.9589/0.6415, restitution 0.6949)
- Rebuilt rep_flight_fit v2 through the object path; crashed at 25.5 m/s in the speed-class ladder 0x6ea555c (infinite recursion when thresholds zero)
- FULLY DECODED the ladder: x0 = the 296B state; 6 thresholds at +0x74..0x88; class table 12B entries at +0x2c+class*0xc; mode at +0x8c (0=ladder, 1=FText, >=2=zero-return via 68352cc); recursion = speed -= [0x88] when speed >= all thresholds
- Found the ladder caller: kernel 0x6ea0958 -> 0x6ea1938 (air-curve/drag fn, call at 0x6ea0a44; guards incl. pos.y>0.1187 airborne); ladder gate: |vx|+|vy| > conv(10)^2 = 7.716 (L1 norm vs squared threshold - game units quirk). M2 never crashed because drop-from-3m peaks at 7.53 < 7.716
- Working-state discovery: kernel x2 = a chain-allocated heap buffer (NOT +0x30/+0x158); entry copies ball+0x30 -> working state; observer publish feeds back via +0x158 -> +0x30
- 2efaae8 = static initializer (zeros, cxa machinery) - NOT the ladder filler; 6ea5a68 = big object ctor (zero-init) - NOT the state ladder setter either; real filler = paramsB machinery, still unreconstructed
- DECODED THE TWO-STREAM TICK ARCHITECTURE (the framing breakthrough):
  * entry branch byte [ball+0x2D3]: recorder path (6e942c0 transform + N x 6a6b604 record writes, NO kernel) vs physics path (chain_top)
  * chain_top calls chain_mid TWICE: (a) 0x6ea1f64 w3=1 (init step on substep 0, N substeps) -> published stream +0x158; (b) 0x6ea23d4 w3=0 N=1 (ONE PURE semi-implicit substep) -> the RECORDER stream
  * Measured: entry tick N=3 with feedback = 2x velocity advance (gravity -19.61); .rep records = pure w4=0 substeps (replay dx ~ 0.91 m/record = v'*dt, gravity -9.8067 exact through pure chains)
- record-chain fit v3 (pure w4=0 kernel chain, state+0x8c mode 8 to disable the unreconstructed ladder):
  * calibration: gravity -9.8067 all 7 rows; drag_x@25.5 airRegist=1: -10.909
  * FIT CLOSES: v0=[24.76, 5.2, -4.7], rot=0, airRegist=0.399, resid RMS 0.0241 m, OOS max 0.0774 m (replay quantization ~1.6 cm - at noise level)
  * prior session's "missing forces" anomaly resolves to effective airRegist ~0.4 vs ball.o raw 1.0 (paramsB hypothesis now precisely testable)
- Packaged FINDINGS.md + RESUME.md + full bundle zip; uploaded to permanent hosts

Stage Summary:
- M3 FLIGHT FIT CLOSED: kernel-only model reproduces the shooting_02 flight to cm-level with airRegist 0.399, zero spin. The correct record-stream semantics (pure w4=0 substep chains) is decoded and implemented.
- NEW DECODES: two-stream tick architecture, ladder semantics + crash root cause, drag_fn guards, L1-vs-squared threshold gate, recorder/published stream split, 6ea2454/6ea20d8 state merge pipeline
- REMAINING GAP (precisely localized): paramsB state installer that fills the real ladder thresholds (state +0x74..0x88) at kick time; then mode-0 fit + full-replay driven-mode equivalence + ProcessMatchMain climb
- DELIVERED: bundle PeerLink_session_bundle_v2.zip (14,258,244 B, sha256 ebb1537c8fa89282a9bfd3bcbbb0ff0b162289d0cfc7d96bdeebc047fb106045) at mirrors: gofile.io/d/j8FBkITs (verified 200) and x0.at/8X8y.zip (verified byte-exact via head+tail range compare); full permanence path = GitHub release on user's repo (documented in download/LINKS.md); local copy in download/

---
Task ID: 4
Agent: main (Super Z)
Task: M4 — execute the photocopy strategy: climb from the ball core to the
match tick, run the real game path headlessly (no equation rewrites).

Work Log:
- Re-ran M2 regression at session start: ALL PASS (bit-exactness intact)
- Strategy pivot per user: keep Konami machine code, find the plugs only
- Broke the BL-only call-graph wall: added 2.04M unconditional-B tail-call
  edges (scripts/bscan.py -> fgraph2.npz)
- Ancestry intersection (ball x player x command seeds): ball∩player
  converged to ONE function 0x6a00e50 = the 110-command dispatcher
  ([cmd+8]=id, jump table, 0..0x6c, fans to 0x6a027f8 command classes)
- Reconstructed the exact spine: 0x69c3e98 (GameModeMatchListenerRecv
  Message.cpp, top virtual entry) -> 0x69c6c58 -> 0x698ada0 ->
  0x69917d8 (MatchMain state machine, state byte [obj+0x139], 11 states,
  hub called by 4 listeners) -> 0x69919e0 ('playing' state handler) ->
  0x6a059b0 (update ball module) -> 0x6a36a64 driver_C -> 0x6a35688
  driven -> 0x6e938a0 ball_update_entry (9-node chain)
- Rebuilt source-path string mine (53 embedded G:\PES22HC paths -> file:func
  map, wall_cross.py); ProcessMatchMain.cpp = 0x802d9d0 confirmed
- Discovered vtable slots via packed-reloc addends: driver family vtable
  0x978d388, module manifest table at 0x98d0500 region (40+ entries)
- DECODED the module architecture: match+0x3C98 -> ball module MANAGER
  (ctor 0x6a352c4, vtables 0x978d388/+0x18, global 0xa469908), 3 module
  lanes at mgr+0x38/+0x40/+0x48 (ctor w1=lane), current lane [mgr+0xC],
  current module [mgr+0x30], [module+2]=is-current gate (6a35970)
- DECODED full construction driver 0x6a35434 (gate 0x71faa50(mgr+0x58),
  rebuilds lanes 0/1: new 0x14B8 -> 6e92768(w1) -> 6e91da8(w1), first
  driven tick 6a35688(mgr,0,0,0,0))
- Built scripts/match_core_run.py (M4 harness): manager ctor 0x6a352c4
  constructs CLEAN (vtable 0x978d388 exact); real game path
  0x6a059b0(match stub) -> driver_C -> 6 kernel calls (N=3 x lanes A+B),
  ZERO faults — the match-object -> module-manager -> module layer is
  photocopies and running
- DECODED driven driver 0x6a35688(mgr, lane, x,y,z) = install pos + tick
  (verified (7.5,1.25,-3.5) installed exactly; gravity advances y);
  driver_C = reset-style tick (installs (0,0,0)/(1,0,100)/(2,0,100);
  y=0 clamps to ground radius); driver_B installs from entity array
  ([entity+0x218] xyz) with y=1.7/0.01 — restart placements
- Closure funnel: from 0x69917d8 22,337 fns / 8.4 MB; from 0x69919e0
  20,334 fns / 8.2 MB; 356 PLT imports (FreeType/input = strip class)
- .trep first decode: 12B header + 1200 x 844B samples (16B sample hdr +
  828 payload); 375/422 u16 lanes constant; mode toggles bytes 24/216,
  phase byte 148 — controller-state stream (M5 command-feed work)
- Updated FINDINGS.md (§8 M4 section, §9 next steps), RESUME.md; bundle v3

Stage Summary:
- M4 PHOTOCOPY ACHIEVED AT MODULE LAYER: the real game path
  (match -> module manager -> 3-lane modules -> kernel) executes
  headlessly under Unicorn with zero faults, on Konami's own ARM64 code.
- The full update spine is mapped with a 9-node exact call chain from the
  GameMode message entry to the ball kernel; the 110-command dispatcher
  (0x6a00e50) identified as the command core.
- REMAINING for full-match photocopy: per-frame continuous tick caller
  (candidates 6a362d0/0x6a37068/0x6e92ce8), MatchMain SM harness
  (singletons 0x813fe80/0x81604f4), .trep command feed, paramsB installer.
- Bundle v3 packaged and mirrored (see download/LINKS.md).

---
Task ID: 5
Agent: main (Super Z)
Task: M5 — the lockstep bridge: decode the real per-frame tick, the .rep
record stream, and validate the flight through the real game path.

Work Log:
- User clarified the end goal: Peerlink = deterministic lockstep netplay
  (peers exchange controller inputs via UDP, identical sim => identical
  state). Validation strategy pinned: .trep in -> tick -> .rep compare.
- Re-ran M2 suite + M4 harness at session start: ALL PASS / zero faults.
- .rep oracle pinned: 44,400 hdr + 1,200 x 10,976; 808 global + 31x328
  entities; ball = THREE 28B slots at +0x2D4/+0x2F0/+0x30C. Data confirms
  the 3-lane manager: slots 1/2 PARKED at (1,0,100)/(2,0,100) = driver_C
  reset installs. Ball record writer = 0x6a6b604 (28B, gate 0x9959f98).
- .trep = input/event stream (NOT entity feed): shot-charge bits at
  bytes 196/216, event bursts in u32 lanes 110-159 during frames 42-49,
  angle lane at byte 156; formation-script lanes during idle.
- Found the tutorial path builder 0x727c9c4 (73 replay strings, adrp+add
  scan) and traced loaders 0x68d0a44/0x6a526b8 (match-side replay ctrl).
- Found the INPUT BANK singleton *(0xa417188) (0x1C070B): 1200-frame
  history ring, command-header pool 800x0x18, per-entity command states
  31x0x20, message queue; pump 0x6a075b8; serialize pair 0x6774ce4/
  0x67750ec; 1200 = ~44s rollback/resync substrate (the game's own
  netplay fabric).
- Decoded the playing-state tick map 0x69919e0: input collect -> virtual
  controller (0x68b0408/0x68b1e90/0x7256700, 3x0x50 slots) -> ball via
  0x6a059b0([match+0x2F8]) -> dt 1/27 install -> team orchestrator.
- ARCHITECTURE DECODED - the two entries = the two streams:
  ball_update_entry 0x6e938a0 -> chain_top (Call A: published stream,
  RETURNS after Call A); 0x6e92ce8(module, dt) -> 0x6ea233c = ONE PURE
  w4=0 substep on module+0x158 (the .rep record stream, SELF-ADVANCING
  chain, physics dt=1/27 hardcoded via 0x6813eb8, frame-boundary gate on
  time accumulator [module+8], install gate via [module+0x2F8]).
  driver_B 0x6a359f4 calls it per lane with dt=1.0 (frame units).
- M3 anomaly SOLVED: the game chain passes kernel x3 = 0x6ea0874()+8 =
  P+8 (params+8). Kernel drag coeff = f32 at x3+0. M2/M3 installed ball.o
  at P+0 => game path read ball.o[+8]=7.0 (17x drag => the 20x damping
  anomaly). Writing airRegist at P+8 => real-path flight matches oracle.
- Kick installer decoded: 0x6e93aec (pos from src, substate 7, flags
  0x700, quat, ground clamp 0.1084, [module+0x2D8]=3).
- VALIDATION: kernel control (M3 semantics) reproduces oracle frames
  49-56 at 0.7-9.7cm; real path (0x6e92ce8, state@+0x158, air@P+8)
  matches at same cm-level f50-54 (2.4-10cm); recorder idx2 record per
  tick = the .rep record. Spin install (rot from .rep quat derivative,
  |w|~6.9 rad/s) activates the Magnus curve. Late-frame gap = paramsB
  values (ladder thresholds + spin-drag constants) - precisely localized.
- Updated FINDINGS.md (new section 10, milestone table), RESUME.md.

Stage Summary:
- M5 LOCKSTEP BRIDGE DECODED: the real per-frame tick, the .rep record
  stream generator, the input bus (the game's own rollback substrate),
  and the params-offset root cause. The real-path flight validation
  runs at cm-level against the game's own records.
- Remaining for full bit-exact flight: paramsB values from the kick
  event; then MatchMain SM harness + .trep command feed (M6).
- Bundle v4 packaged and mirrored (see download/LINKS.md).

---
Task ID: M6-M8
Agent: main (session C)
Task: Make the actual MatchMain state machine (0x69917d8) run headlessly
with state=PLAYING; construct the real input bank; decode the .trep input
stream; demonstrate the real kick installer. Per user directive: climb
ABOVE the ball to the playing-state update and let Konami's code install
context itself.

Work Log:
- Environment restored from v4 bundle (scripts + analysis DBs + 21 tutorial
  replays); venv rebuilt (unicorn 2.1.4, capstone, pyelftools, numpy, scipy).
- libUE4.so re-fetched via APKCombo surgical downloader (fresh signed R2 URL
  scraped from the 11.0.1 old-versions page; scripts/fetch_libue4.py),
  SHA-256 verified: 2ac4ff17...1298cd. All regressions reproduce: M2 ALL
  PASS, M4 M0/M1 PASS, M5d real-path flight + recorder-stream mapping.
- CRITICAL BUG FIXED: raw file scans were using file-offset==vaddr, but the
  ELF segments are NOT identity-mapped (text delta -0x4000, data -0x8000,
  .data/.bss -0xC000). New scripts/scan.py (v2o() + vectorized adrp/bl
  scans). .rodata (jump tables, constants) IS identity-mapped, so all
  earlier vaddr-in-.rodata results stand; earlier TEXT scans (find_bl,
  adrp) were partially wrong and are now redone correctly.
- MatchMain state machine 0x69917d8 FULLY DECODED: 11-state jump table at
  0xc69522 (byte offsets * 4 from 0x6991848). state 1 = PLAYING (guard: bit8
  of [*(0xa40ff48)+0x270] via 0x6914c18; guard: *(0xa409788)[9] vtable+0x48
  must return true). state 0 -> state 1 via 0x8160680(x22) ([B+0x30]==4) +
  0x68b5ed8(match, 0). Singletons: A=*(0xa4cff08) (0x813fe80),
  B=*(0xa4d0228) (0x81604f4), vtobj=*(0x9959fa0) (0x6836474, virtuals
  +0x10/+0x288/+0x2a0/+0x290/+0x1c8), dtmgr=*(0xa409b10) (0x66f0238).
- 0x69919e0 (PLAYING update) decoded end-to-end: clear scratch
  (0x142/0x144/0x27c); input collect 0x68b0408(match+0x265B0) -> virtual
  controller attach 0x720edb0(match+0x26840) + 0x720e3ac + 0x720ee5c;
  0x68b047c; ball: [match+0x2DB] -> 0x6a059b0([match+0x2F8]); else
  0x69920f0 + 0x6992174; dt install 0x66f1770(*(0xa409b10), 1/0x6813eb8());
  0x68034d0(match[0x14c]); branch on [match+0x146] -> 0x6992218/0x699221c
  (both RET) -> TAIL CALL 0x6992220(match) = team orchestrator.
- DATA-ONLY PLUGS discovered: the lazy-getter family (0x68b0408 -> [hub+0x40],
  0x68b2a3c -> [hub+0x48], 0x68b335c(match+0x26B60) -> [+0x48]) reads a
  validity byte [X+8] then cached ptr [X+0x40/0x48]; create path reads
  SOURCE ptr [X+0x30]: if NULL the game's own code stores NULL and returns
  NULL cleanly. So: [region+8]=1 + [region+0x30]=NULL = "no source
  configured" — zero code patching. (M2-style neutralization NOT needed
  here.)
- M6 PASS (scripts/matchmain_run.py): SM called with state=1 ->
  0x69919e0 -> input collect (NULL, skip) -> 0x6a059b0 -> ball module
  manager -> driver_C -> 6 KERNEL CALLS -> dt=1/27 EXACT (0.03703703731298447)
  -> team orchestrator 0x6992220 -> returns clean. ZERO faults. 38,117
  basic blocks, 495 distinct functions (107 in the player-machinery range).
- M6-exec (scripts/matchmain_exec.py): match-object write map (1,298 bytes
  changed, 12-byte stride pattern in the 0x300-0x2a00 region = per-entity
  timer/stat blocks); team sides (match+0x227D0) untouched (player objects
  not constructed yet); ball +0x158 unchanged (ball at rest at ground center,
  6 kernel calls still fired). Coverage saved to mm_exec_funcs.npy.
- M7a PASS (scripts/inputbank_run.py): the REAL input bank ctor 0x6a06b60
  runs headlessly on a 0x1C070 buffer: 21,068 blocks, ZERO faults, the
  1200-frame history ring + command-header pool + per-entity states fully
  initialized (18,161 nonzero bytes). Singleton *(0xa417188); pump
  0x6a075b8 (message queue at bank+0x1BFE0 -> 0x6a07d68 per-entity
  registration); feed path mapped: pump called from 0x6a9ba94 (message
  listener, vtable slot 0x978e288) with dt from 0x72205b4/0x6813eb8.
- .TREP DECODED (scripts/trep_deep.py + hex analysis):
  * 12B header {id, 12, 828} + 1200 x 844B (16B hdr + 828B payload).
  * Sample hdr: f32 1.0 (time scale) + 12B zeros.
  * Payload = 24 input records x 0x3A (58B): bytes 196..587, stride 0x3A;
    each = {9B config/const, u16 sub-id, 5B zeros, u16 counter (increments
    ~7/record), u16 checksum-like, u16 flags (0x18 at byte 205), 24B
    keyframe floats, 4B zeros}. Analog cluster at +144..+172: 6 floats
    (charge 0..0.644, angle 0..358.067, two drifting pairs) + u16 slots
    at 156/158.
  * Button lane: bytes 200/201 = 0/1 (press!) during the action window;
    bytes 204-207 = 0xA3 0x00 0x18 0x00 command header (appears while
    button held).
  * Camera record: 9 floats (+208..+244: pos 3f + target 3f + fov-ish 2f).
  * Replay trajectory record at +338..: 9 floats per frame, 12B stride:
    3 points A/B/C (x: 38.0->38.6, y: 39.8->40.3, z: 41.6->42.1 frozen
    after action) + 2 curved-axis floats. Camera path for replay playback.
  * Kick timing: analog 37-49, button 42-49, ball launches at .rep f48.
  * Survey of all 21 tutorials: consistent (analog burst precedes action;
    trajectory runs during control period then freezes).
- M8 (scripts/m8_kick_installer.py): real kick installer 0x6e93aec(module,
  src, quat) called with the game's own code: writes INPUT state +0x30:
  pos (12B f32), substate 7 = KICKED at +0x91, flags 0x700, quaternion,
  ground clamp y=0.1084 (0x3DDE96BB), [module+0x2D8]=3, notify chain
  ([module+0x300] -> 0x6ab1150/0x6ab1104), 0x68bf588 resets at module+0x3C
  (velocity!) and +0x48 (rot!) => THE INSTALLER ZEROES VELOCITY BY DESIGN.
  The kick VELOCITY comes AFTER, from the player-action processor (the
  paramsB climb: charge/angle from the .trep analog cluster -> velocity +
  spin + ladder thresholds). Entry tick 0x6e938a0 + continuous ticks
  0x6e92ce8 then fly the ball through the real path (frame alignment =
  the known two-stream offset, FINDINGS 3).

Stage Summary:
- M6: THE MATCHMAIN STATE MACHINE RUNS HEADLESSLY — the user's directive
  #1. The full playing-state frame executes through Konami's own code:
  input collect -> ball module manager (6 kernel calls) -> dt 1/27 -> team
  orchestrator. Zero faults, 495 functions covered.
- M7a: the real input bank constructs headlessly; the .trep = the game's
  per-frame input stream (24 tracked input records + analog cluster +
  camera + replay trajectory), decoded to field level.
- M8: the real kick installer demonstrated; its semantics (velocity zeroed,
  KICKED substate) pinpoint the paramsB/action-processor climb as the
  exact next step for the kick velocity.
- Remaining for 1200/1200: (a) player module construction (manifest table
  0x98d0500, 63 module-manager entries; construction fn 0x6a02000 reads
  match+0x3818 region), (b) the action processor -> kick velocity + spin +
  ladder thresholds (paramsB), (c) input-bank message-queue feed of .trep
  samples (0x6a07d68 path), (d) then the full replay exactness test.
- Bundle v5 packaged (scripts + updated FINDINGS/RESUME + analysis JSONs).

---
Task ID: 9 (v5 bundle upload)
Agent: main
Task: Upload PeerLink_session_bundle_v5.zip to a public permanent host (user reported x0.at/F0aH.zip pattern; v5 was never uploaded last session - context ran out after packaging).

Work Log:
- Container intact: v5 zip at /home/z/my-project/PeerLink_session_bundle_v5.zip (18,331,210 B, 154 entries, zip integrity OK).
- x0.at: 403 IP banned (both default + browser UA). 0x0.st: connect timeout. transfer.sh: down. pixeldrain: auth required. catbox/litterbox: blocked (Invalid uploader / 500).
- gofile.io: SUCCESS via https://store-eu-par-4.gofile.io/contents/uploadfile.
- temp.sh: SUCCESS as backup mirror (browser landing page -> POST button serves file).
- Verified BOTH mirrors byte-exact: md5 910f0991986e1c29a15d3ca07a563443 (gofile server-side report; temp.sh full round-trip download md5).

Stage Summary:
- PRIMARY: https://gofile.io/d/ueuG0mr9  (PeerLink_session_bundle_v5.zip, md5 910f0991986e1c29a15d3ca07a563443, 18,331,210 B)
- BACKUP (3-day): https://temp.sh/tUwJP/PeerLink_session_bundle_v5.zip (same md5; browser page -> click POST to download)
- gofile guestToken (manage/delete file): N68Fy3pIJg6KusdaQYoeBKepM2nry89B, fileId e1c5272f-8bf9-4a23-b2a1-a7695c56d740
- Local copy also at /home/z/my-project/download/PeerLink_session_bundle_v5.zip
- NEXT SESSION TASK (user's standing directive): make 0x69919e0 run with real input bank + full player state; climb to 0x6e93aec paramsB/action-processor for kick velocity; .trep feed via 0x6a075b8; then 1200/1200 exactness; then trim. See bundle v5 FINDINGS/RESUME for full state.

---
Task ID: 10 (M9: the match-setup command sequencer)
Agent: main
Task: User directive: construct the 22 original Konami player modules; feed .trep through the original input bank/message path; find the original action processor. This session: climb from 0x69919e0 upward via the game's own setup protocol.

Work Log:
- Located the setup entry: 0x6a00e50 (the input-bank dispatcher, vtable slot +0x10 of listener vtables 0x978bf38/0x978cf60) is a SELF-DRIVING 109-COMMAND SEQUENCER: cmd id at [match_core+8], jump table 0xc6bdcc, each handler stores the next cmd id (0x6a01924).
- Decoded the chain: cmd 0 (0x6a0093c main init) -> 1 -> 2 -> 3 -> 4 (0x6a0195c gate -> 0x6a02000 = the construction driver: 2 sides x 11 slots from core+0x10 = THE 22 PLAYER MODULES + 3 extra + [core+0xD8]) -> 5 ... cmd 0x40-0x66 (0x6a027f8 per-player constructions).
- Two-object architecture confirmed: OUTER match (0x69917d8: +0x139 state, +0x2F8 link) vs INNER core (dispatcher: +8 cmd, +0x10 22-slot table, +0x3818/+0x3868 controller hubs, +0x3958/+0x39F8 team data).
- REAL platform layer in uc_loader2.py (each fix root-caused):
  * pthread_once: real init-routine execution (old stub = 292k-retry TLS spin)
  * plain-name rich-stub dispatch (posix_memalign out-pointer, TLS get/set) - the _h suffix never matched the GOT-resolved names
  * real mmap/munmap (arena 0xA90000000000), sysconf(_SC_PAGESIZE)=4096 (the memory pools' per-block overhead)
  * timed_mutex contention-wait removal (0x823bef4, DROP-class)
  * __cxa_guard single-thread semantics (in-progress marker kept, abort dropped)
  * allocator plugin fabrication at [0x9e7b260] routing vt[0x28] to real malloc (0x421eabc has 18,629 call sites)
- Bootstrap: JNI_OnLoad (0x2830374) completes with ZERO faults; init_array 0-14 (the mini-bootstrap) all pass; the full 11,829-entry run passes 5,277 (locale-static cascades, not needed by the sequencer path).
- M9 runtime plug set (data-only): locale facet-insert nop, one-shot gate 0xa417111, 14 hub plugs, ctrl3868/ctrl3818 controllers, registry via the game's lazy getter 0x6a09418, cleaned guard array.
- RESULT: the sequencer runs cmd 0->1->2->3->4 headlessly, ZERO faults (scripts/m9_setup_seq.py, reproducible). cmd 4's gate now reaches the TEAM DATABASE chain (0x70c1c00 -> 0x70c37f0).
- Verified all prior milestones still reproduce after the loader upgrades: ball_object_run ALL PASS, matchmain_run (events + 6 kernel calls + exact dt; state now advances to 4), inputbank_run, m8_kick_installer.

Stage Summary:
- THE SETUP PROTOCOL IS RUNNING: the photocopy path for the 22 players = drive 0x6a00e50's command chain; the .trep feed rides the SAME pipe (the input-bank listener vtable IS the dispatcher).
- Remaining for the 22 players: the team DB (constant_team.bin from the CPK) feeding 0x70c37f0 so cmd 4's gate passes -> 5; then cmd 0x40+ player constructions; then the .trep samples through the bank queue; then the action processor (kick velocity) installs with the players.
- v6 bundle packaged with FINDINGS §16 + this worklog + all harnesses.

---
Task ID: 11 (M10: 22 players constructed + real inner ctor + cmd4→5)
Agent: main
Task: User directive: cross the team-data gate, construct the 22 players
via Konami's own constructors, drive the sequencer to 22/22. This session
restored the container, refetched libUE4.so (fresh R2 URL scraped from
APKCombo; SHA-256 2ac4ff17...1298cd verified), and pushed through.

Work Log:
- Container was reset: v6 downloaded from github.com/EdenAlpha/Peerlink1,
  extracted to /home/z/my-project/{scripts,apk_lab}; venv rebuilt
  (unicorn 2.1.4, capstone, pyelftools, numpy, scipy); libUE4.so refetched
  via refresh_r2.py + fetch_libue4.py (the old signed URL was expired).
- constant_team.bin DECODED: QWESYS container (ff 20 'QWESYS' + u32 comp/
  raw + zlib at +0x10) -> {basePosition.o: 864 bytes} = the formation
  position table (24 entries x 9 floats; pitch coords ~±35m). Decoder:
  scripts/qwesys.py (from the user's upload/).
- ROOT CAUSE #1 FOUND (why the M9 gate bailed at x26==NULL): the cmd-0
  handler RELEASES [inner+0x3868+0x40] (0x68b69a8 @ 0x68b69c8) BEFORE cmd
  4 ever runs. The m9d hub dump proved it: the ctrl3868 pointer vanishes
  between cmd 3 and cmd 4. FIX: harness re-plugs both controller pointers
  before every dispatcher call (m9e..m9f).
- *** THE 22 PLAYERS ARE CONSTRUCTED *** (m9f_drive.py): with the replug,
  the cmd-4 gate runs its slot-fill loop: 0x70c1c00(&side,&slot) = new
  (0x18bf0) + 0x70c37f0 ctor(side,slot) + release -> 0x6993afc(entry) ->
  store [core + side*0x58 + slot*8 + 0x10]. 46 db_query + 46 teamdb_ctor
  + 44 player_ctor events. slots22 = 22/22. cmd 4 -> 5 ADVANCES.
- REAL INNER-CORE CONSTRUCTOR FOUND: 0x69ff76c (called from the outer
  match ctor 0x6992ee0). Installs [core]=0x978cf60 (the listener vtable
  whose vt[+0x10] IS the dispatcher 0x6a00e50), 0x71f8614(core+0x128) =
  the team-data base (hubs at +0x3620+side*0x50), all ctrl/team hubs with
  REAL vtables (0x9787030/71a0/258/310/3c8/6a8), the 22-slot table, the
  0x3bd8 readiness bytes, the 0x101 ids. Running it headlessly installed
  all vtables (fixes the cmd-5 teamdata_get crash) though it faults in
  its late stage (FETCH at 0; documented, non-fatal for the sequencer).
- DISPATCHER JUMP TABLE decoded: u16 byte-offsets at 0xc6bdcc (109
  entries), target = 0x6a00ea4 + off*4. cmds 8..0x66 each call
  0x6a027f8(core, side, slot) = THE PER-PLAYER CONSTRUCTION SEQUENCE
  (the user's 'real 0x6a027f8 constructor events' - comes after cmd 5).
- cmd-5 blockers fixed in order:
  * cv-wait drain spin (0x68a0f1c loop, 0x8b38350 =
    std::condition_variable::wait -> 0x8239c48 -> pthread_cond_wait):
    DROP-class neutralization (nop the cbnz @ 0x68a0f30) - same
    precedent as the v4 camera cond_wait. Queue-drain thread sync.
  * *(0xa40c388) NULL (the message queue hub at 0x67f48d4's insert):
    its init = 0x67f4b24, called from 0x68a7a5c (module-manifest
    registration family). Calling 0x68a7a5c headlessly = clean.
  * *(0xa409e10) NULL (registry hub; the stack visitor at 0x66fcbfc
    gets its tree from 0x66fb244): init = 0x66fb250, runs clean.
- After both inits: cmd 5 handler (0x6a027b0 guards) runs deep; current
  frontier = a vtable slot holding a heap pointer (FETCH_PROT at a 0x9000
  arena address) inside the cmd-5 message dispatch. NEXT: dump the vtable
  at fault time, find which fabricated vtable has an object pointer in a
  function slot, fix/replace with the real one.
- m10 scripts: m9b_gate_trace, m9c_gate_path, m9d_hub_state,
  m9e_watch_clear, m9f_drive (the 22/22 proof), m9g/m9h/m9i (cmd-5 deep
  dives), m10_realctor (the 0x69ff76c run), m10b..m10r (the iterative
  blocker fixes).

Stage Summary:
- slots22 = 22/22 ACHIEVED via Konami's own 0x70c1c00/0x70c37f0/0x6993afc
  chain (the user's task-1 success condition: 22 real player module
  slots filled by the original constructors, nothing fabricated).
- cmd path now: 0 -> 1 -> 2 -> 3 -> 4 (22 slots fill) -> 5.
- The full remaining ladder is decoded: cmd 5 guards -> cmds 6,7 ->
  cmds 8..0x66 (0x6a027f8 per-player) -> 0x67 done.
- Remaining: (a) the cmd-5 vtable-with-heap-pointer fault, (b) cmds
  6..0x66, (c) then the .trep feed through the input bank + the action
  processor (unchanged plan from v6), (d) 1200/1200 replay exactness.

---
Task ID: 12 (v7 bundle upload)
Agent: main
Task: Package + upload the session bundle (22/22 players milestone).

Work Log:
- v7 packaged: 167 entries (all scripts incl. the m9f/m10 proof harnesses,
  analysis JSONs incl. m9f_drive.json + m10t_drive.json, FINDINGS.md
  with the new §17, the restored worklog, constant_team.bin +
  constant_match.bin + ball.o).
- Local: /home/z/my-project/PeerLink_session_bundle_v7.zip (17,706,879 B,
  md5 b63900d53caabc51af51bca343962a3e) and
  /home/z/my-project/download/PeerLink_session_bundle_v7.zip.
- gofile: SUCCESS, server-side md5 MATCHES.
- temp.sh: SUCCESS, full POST roundtrip download md5 MATCHES.
- GitHub push: no credentials in container (user adds the zips from the
  links, same as v4/v5/v6).

Stage Summary:
- PRIMARY: https://gofile.io/d/jRMj05Ng
- BACKUP: https://temp.sh/aKtKm/PeerLink_session_bundle_v7.zip
  (browser page -> POST / click download)
- md5: b63900d53caabc51af51bca343962a3e
- gofile guestToken: plc9hjrKRC8GDNahmuu6Pcruyiqxhh5e
  fileId: ac866b3b-7a4b-4ba0-bce0-4e7ba1a1c08a
- NEXT SESSION (user directive continues): (1) fix the cmd-5 envelope
  fault (blr @0x66f0a40, x8 = [[x25]+0x18] heap ptr; x25 from
  0x66eca24(x20=0xa00000a6e00-ish slot); suspects: the envelope ctor
  family 0x66f243c/0x66f3f3c siblings 0x66f3f68, 0x66f373c, 0x66f308c,
  and the *(0xa409b70) region used by 0x66f1e50), (2) drive cmds 6,7
  then 8..0x66 for the 0x6a027f8 per-player ctor events, (3) the .trep
  feed + action processor per the v6 plan, (4) 1200/1200 exactness.
