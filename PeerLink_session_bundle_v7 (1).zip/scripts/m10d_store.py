#!/usr/bin/env python3
"""M10d: trace handler blocks + the 0x6a01924 cmd store + 0x6a02000."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22
from m10_realctor import A_INNER_CTOR

LO, HI = 0x6a01000, 0x6a02090


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    path = []

    def blk(uc, address, size, ud):
        off = address - core.base
        if LO <= off < HI:
            path.append(off)

    core.uc.hook_add(UC_HOOK_BLOCK, blk)

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        print(f'  FAULT type={type_} addr={address:#x} pc={pc-core.base:#x}')
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=120,
                  max_insns=100_000_000)
    print('inner ctor err:', r['error'])
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(5):
        before, after, err, pc = world.step()
        replug()
        n = sum(1 for p in slots22(core, inner) if p)
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err} slots={n}')

    print('--- tracing step 5 (handler path) ---')
    path.clear()
    before, after, err, pc = world.step()
    replug()
    print(f'step: cmd {before:#x} -> {after:#x} err={err}')
    seq = []
    for b in path:
        if not seq or seq[-1] != b:
            seq.append(b)
    line = [f'{b:#x}' for b in seq]
    print('path (%d):' % len(seq))
    for i in range(0, len(line), 8):
        print('  ' + ' '.join(line[i:i + 8]))


if __name__ == '__main__':
    main()
