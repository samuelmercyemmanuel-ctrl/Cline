#!/usr/bin/env python3
"""M5e: isolate the drag anomaly.

Control: pure kernel chain (M3-style, w4=0, dt=1/27) on the same kick
state with the same params — must reproduce the oracle (M3 level).
Then: same state ticked through 0x6ea233c (with observers) — diverges.

Diff the two post-substep states to find WHAT the observers change.
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import (BallWorld, rd_state, state_vec, STATE_SZ,
                             A_KERNEL)
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m5e_drag_isolate.json'
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_CONT_TICK = 0x6e92ce8
A_PURE_STEP = 0x6ea233c
DT = 1.0 / 27.0


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'quat': q, 'pos': (x / 256, y / 256, z / 256)}


def main():
    o48, o49 = rep_slot0(48), rep_slot0(49)
    p48 = o48['pos']
    v_imp = tuple((np.array(o49['pos']) - np.array(p48)) / DT)
    v0 = (v_imp[0], v_imp[1] + 9.80665 * DT, v_imp[2])

    world = BallWorld(verbose=True)
    world.construct()
    modA = world.ball
    core = world.core
    world.set_N(3)

    # ---- control: kernel-only chain (M3 semantics) ----
    s = bytearray(STATE_SZ)
    struct.pack_into('<3f', s, 0x000, *p48)
    struct.pack_into('<3f', s, 0x00C, *v0)
    s[0x90] = 1
    s[0x91] = 6
    struct.pack_into('<4f', s, 0x098, *o48['quat'])
    struct.pack_into('<i', s, 0x08C, 8)
    stK = core.alloc(STATE_SZ, bytes(s), name='ctrl_state')
    core.uc.mem_write(world.params, struct.pack('<f', 0.399))
    world.reset_kernel_ctx()
    ctrl = []
    for k in range(8):
        r = core.call(A_KERNEL, w0=0, w1=1, x2=stK, x3=world.params,
                      s0=DT, w4=0, w5=0)
        assert not r['error'], r
        ctrl.append(struct.unpack_from('<3f', rd_state(core, stK), 0))
    print('[control kernel chain] first 8 positions:')
    for k, p in enumerate(ctrl):
        o = rep_slot0(49 + k)['pos']
        print(f'  f{49+k}: pred=({p[0]:.3f},{p[1]:.3f},{p[2]:.3f}) '
              f'oracle=({o[0]:.3f},{o[1]:.3f},{o[2]:.3f}) '
              f'err={round(p[0]-o[0],3)},{round(p[1]-o[1],3)},{round(p[2]-o[2],3)}')

    # ---- variant: 0x6ea233c (observers) on module+0x158 ----
    core.uc.mem_write(modA + 0x158, bytes(s))
    core.write_u64(modA + 0x2F8, 0)
    core.write_u32(modA + 0x8, 0)
    obs = []
    for k in range(8):
        r = core.call(A_PURE_STEP, x0=modA + 0x158, x1=0, x2=0)
        if r['error']:
            print(f'  pure-step fault at {k}: {r}')
            break
        obs.append(struct.unpack_from('<3f', rd_state(core, modA + 0x158), 0))
    print('\n[0x6ea233c pure step] first 8 positions:')
    for k, p in enumerate(obs):
        o = rep_slot0(49 + k)['pos']
        print(f'  f{49+k}: pred=({p[0]:.3f},{p[1]:.3f},{p[2]:.3f}) '
              f'oracle=({o[0]:.3f},{o[1]:.3f},{o[2]:.3f}) '
              f'err={round(p[0]-o[0],3)},{round(p[1]-o[1],3)},{round(p[2]-o[2],3)}')

    # ---- state diff after 1 substep: kernel vs observer path ----
    core.uc.mem_write(stK, bytes(s))
    core.uc.mem_write(modA + 0x158, bytes(s))
    world.reset_kernel_ctx()
    core.call(A_KERNEL, w0=0, w1=1, x2=stK, x3=world.params, s0=DT, w4=0, w5=0)
    core.call(A_PURE_STEP, x0=modA + 0x158, x1=0, x2=0)
    a = rd_state(core, stK)
    b = rd_state(core, modA + 0x158)
    diffs = [(i, a[i], b[i]) for i in range(STATE_SZ) if a[i] != b[i]]
    print(f'\n[state diff after 1 substep] {len(diffs)} bytes differ:')
    for i, x, y in diffs[:40]:
        fa = struct.unpack_from('<f', a, i)[0] if i % 4 == 0 and i + 4 <= STATE_SZ else None
        fb = struct.unpack_from('<f', b, i)[0] if fa is not None else None
        print(f'  +{i:#05x}: kernel={x:#04x} obs={y:#04x}' +
              (f'  (f32: {fa:.4f} vs {fb:.4f})' if fa is not None else ''))

    json.dump({'ctrl': ctrl, 'obs': obs,
               'diffs': [[i, x, y] for i, x, y in diffs]},
              open(OUT, 'w'), indent=1, default=float)
    print(f'JSON -> {OUT}')


if __name__ == '__main__':
    main()
