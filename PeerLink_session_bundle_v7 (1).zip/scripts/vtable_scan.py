#!/usr/bin/env python3
"""Vtable extraction + virtual-dispatch bridge for locating the match tick.

1. Scan RW segments (file image) for runs of consecutive qwords that are valid
   text addresses -> vtable candidates (link-time pointers, base 0).
2. Map methods -> vtables; find vtables owning key gameplay functions.
3. Inspect the ProcessMatchMain TU function 0x802d9d0 directly (callees/callers).
4. Identify the match process class and its Update slot.

Output: apk_lab/analysis/vtables.json
"""
import json, os
import numpy as np
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        loads.append(dict(vaddr=seg['p_vaddr'], memsz=seg['p_memsz'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], perms=('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')))
TEXT = [l for l in loads if 'x' in l['perms']][0]
TV, TSZ = TEXT['vaddr'], TEXT['filesz']
fdata = open(SO, 'rb').read()

def v2o(v):
    for l in loads:
        if l['vaddr'] <= v < l['vaddr'] + l['filesz']:
            return v - l['vaddr'] + l['offset']
    return None

# ---------------- vtable extraction ----------------
RWS = [l for l in loads if 'w' in l['perms'] and l['filesz'] > 0x10000]
print('RW segments:', [(hex(l['vaddr']), hex(l['filesz'])) for l in RWS])
vtables = []
for l in RWS:
    sz = (l['filesz'] // 8) * 8
    seg = np.frombuffer(fdata[l['offset']:l['offset'] + sz], dtype='<u8')
    base = l['vaddr']
    in_text = (seg >= TV) & (seg < TV + TSZ) & ((seg & 3) == 0)
    # runs of >= 4 consecutive text pointers
    d = np.diff(in_text.astype(np.int8))
    starts = np.nonzero(d == 1)[0] + 1
    ends = np.nonzero(d == -1)[0] + 1
    if in_text[0]:
        starts = np.concatenate(([0], starts))
    if in_text[-1]:
        ends = np.concatenate((ends, [len(seg)]))
    for s, e in zip(starts, ends):
        if e - s >= 4:
            vtables.append((base + s * 8, s, e, seg[s:e].tolist()))
print(f'vtable candidates: {len(vtables):,}')

method2vt = {}
for addr, s, e, methods in vtables:
    for m in methods:
        method2vt.setdefault(m, []).append(addr)

# ---------------- key functions ----------------
KEY = {
    'ball_chain_top': 0x6ea1e90, 'ball_chain_mid': 0x6ea20fc, 'ball_kernel': 0x6ea0958,
    'ball_update_entry': 0x6e938a0, 'ball_replay_serializer': 0x6e94aa4,
    'player_replay_serializer': 0x6f45bc4, 'player_replay_writer': 0x728d7e0,
    'ball_replay_writer': 0x728d930, 'process_match_main_ref': 0x802d9d0,
    'match_cmd_ctrl_a': 0x6f53644, 'match_cmd_ctrl_b': 0x6f54074,
    'match_data_sync': 0x6f60c74, 'rp_rand_a': 0x7ceafc4, 'rp_rand_b': 0x7cf86f0,
    'match_cmd_stats': 0x7bff91c, 'replay_file_loader': 0x727c9c4,
}
print('\n=== VTABLES CONTAINING KEY FUNCTIONS ===')
found_vts = {}
for name, fn in KEY.items():
    vts = method2vt.get(fn, [])
    found_vts[name] = [hex(v) for v in vts]
    print(f'  {name} ({fn:#x}): {len(vts)} vtables {[hex(v) for v in vts[:4]]}')

# ---------------- vtables related to ProcessMatchMain ----------------
# any vtable whose method list includes 0x802d9d0
pm = method2vt.get(0x802d9d0, [])
print(f'\nProcessMatchMain TU function 0x802d9d0 in {len(pm)} vtables')
vt_dump = {}
for v in pm[:8]:
    idx = None
    for addr, s, e, methods in vtables:
        if addr == v:
            idx = (s, e, methods)
            break
    if idx:
        s, e, methods = idx
        vt_dump[hex(v)] = {'n': len(methods), 'methods': [hex(m) for m in methods]}
        print(f'  vtable {v:#x}: {len(methods)} methods')
        for i, m in enumerate(methods):
            mark = ' <-- ProcessMatchMain' if m == 0x802d9d0 else ''
            print(f'    [{i:2d}] {m:#x}{mark}')

# ---------------- direct inspection of 0x802d9d0 ----------------
md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
def dis(fn, n=60):
    o = v2o(fn)
    if o is None:
        return []
    return list(md.disasm(fdata[o:o + n * 4], fn))

print('\n=== ProcessMatchMain function 0x802d9d0 (head) ===')
for i in dis(0x802d9d0, 40):
    print(f'  {i.address:#x}: {i.mnemonic} {i.op_str}')

# its callees + callers via bl map
bl = np.load(f'{AN}/bl_map.npz')
bl_site, bl_target = bl['bl_site'], bl['bl_target']
o2 = np.argsort(bl_target)
bt, bs = bl_target[o2], bl_site[o2]
lo = np.searchsorted(bt, 0x802d9d0, 'left')
hi = np.searchsorted(bt, 0x802d9d0, 'right')
print(f'callers of 0x802d9d0: {[hex(x) for x in bs[lo:hi].tolist()]}')

# size estimate
entries = np.unique(bl_target)
es = np.sort(entries)
i = np.searchsorted(es, 0x802d9d0)
nxt = es[i + 1] if i + 1 < len(es) else TV + TSZ
print(f'size estimate: {nxt - 0x802d9d0:,} bytes')

# callees: BL sites within function range
m = (bl_site >= 0x802d9d0) & (bl_site < 0x802d9d0 + (nxt - 0x802d9d0))
cal = sorted(set(bl_target[m].tolist()))
print(f'callees ({len(cal)}): {[hex(x) for x in cal[:40]]}')

json.dump({'n_vtables': len(vtables), 'key_in_vtables': found_vts,
           'process_match_main_vts': vt_dump}, open(f'{AN}/vtables.json', 'w'), indent=1)
print('\nJSON ->', f'{AN}/vtables.json')
