#!/usr/bin/env python3
"""M8: use the REAL kick installer 0x6e93aec instead of manual state writes.

FINDINGS 10.3: 0x6e93aec(module, src, quat) installs:
  pos (12B f32 from src), flags 0x700 at state+0x90 (substate 7 = KICKED),
  quaternion, y clamp 0.1084, [module+0x2D8]=3, notify chain.

NOTE (documented gap): the installer does NOT write velocity — the kick
velocity comes from the player-action processing (paramsB machinery, the
.trep analog burst). For this demo, v0 from the .rep derivative is installed
manually; replacing THAT with the real action path is the next climb.

Test: shooting_02, install f48 kick via the real installer, tick 0x6e92ce8,
compare flight vs .rep oracle (m5d semantics).
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import BallWorld, rd_state, state_vec, STATE_SZ
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m8_kick_installer.json'
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_CONT_TICK = 0x6e92ce8
A_KICK_INSTALL = 0x6e93aec
A_KICK_SET_SOURCE = 0x6e93adc
F_FIRST, F_END = 48, 80


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'quat': q, 'pos': (x / 256, y / 256, z / 256), 'raw': blk}


def main():
    oracle = {f: rep_slot0(f) for f in range(F_FIRST, F_END + 2)}
    o48 = oracle[F_FIRST]
    p48 = o48['pos']
    p49 = oracle[F_FIRST + 1]['pos']
    v_imp = tuple((np.array(p49) - np.array(p48)) * 27.0)
    v0 = (v_imp[0], v_imp[1] + 9.80665 / 27.0, v_imp[2])

    world = BallWorld(verbose=True)
    world.construct()
    modA = world.ball
    core = world.core

    # ---------------- REAL kick install ------------------------------------
    # src = {f32 x, f32 y, f32 z} (pos only); quat = 16B
    # The installer writes the INPUT state (+0x30): pos, flags 0x700
    # (substate 7 = KICKED), quat, y-clamp, [module+0x2D8]=3.
    # Velocity: installed at +0x30 manually (documented gap: real source =
    # the player-action paramsB path fed by .trep analog burst).
    s = bytearray(STATE_SZ)
    struct.pack_into('<3f', s, 0x000, *p48)
    struct.pack_into('<3f', s, 0x00C, *v0)
    struct.pack_into('<4f', s, 0x098, *o48['quat'])
    struct.pack_into('<i', s, 0x08C, 8)
    core.uc.mem_write(modA + 0x30, bytes(s))
    core.write_u64(modA + 0x2F8, 0)
    core.write_u32(modA + 0x8, 0)
    core.uc.mem_write(world.params + 8, struct.pack('<f', 0.399))
    world.set_N(3)

    src = core.alloc(16, struct.pack('<3f', *p48) + b'\0' * 4, name='kick_src')
    quat = core.alloc(16, struct.pack('<4f', *o48['quat']), name='kick_quat')

    # call the REAL installer: (module, src, quat)
    pre_state = rd_state(core, modA + 0x30)
    r = core.call(A_KICK_INSTALL, x0=modA, x1=src, x2=quat)
    print('[kick installer] error:', r['error'])
    assert not r['error'], r

    post = rd_state(core, modA + 0x30)
    diff = [i for i, (a, b) in enumerate(zip(pre_state, post)) if a != b]
    pos_after = state_vec(post)
    print('INPUT state (+0x30) bytes changed by installer:', len(diff))
    print('pos after install:', tuple(round(v, 4) for v in pos_after))
    sub = post[0x91]
    print('substate at +0x91 (expect 7 = KICKED):', sub)
    print('[module+0x2D8] (expect 3):', core.safe_read_u32(modA + 0x2D8))
    vel = struct.unpack_from('<3f', post, 0x00C)
    print('velocity after install:', tuple(round(v, 3) for v in vel))
    kick_info = {'changed_bytes': len(diff), 'pos': pos_after,
                 'substate': sub, 'vel': vel, 'diffs': diff,
                 'mod_2D8': core.safe_read_u32(modA + 0x2D8)}

    # ---------------- entry tick (real merge: input -> published) ----------
    # ball_update_entry = 0x6e938a0 with the one-shot gate [module+0x2D4]
    # CONTROL VARIANT: after the real installer (which zeroes velocity, as
    # the game does — the real velocity comes from the action processor),
    # install v0 at +0x30 to measure the rest of the real path.
    core.uc.mem_write(modA + 0x30 + 0x0C, struct.pack('<3f', *v0))
    core.write_u32(modA + 0x2D4, 1)
    r = core.call(0x6e938a0, x0=modA)
    print('[entry tick] error:', r['error'])
    assert not r['error'], r
    pub = rd_state(core, modA + 0x158)
    print('published pos after entry tick:', tuple(round(v, 4) for v in state_vec(pub)))
    kick_info['published_pos'] = state_vec(pub)
    kick_info['substate_published'] = pub[0x91]

    # ---------------- flight via the real continuous tick -----------------
    rows = []
    for k in range(F_END - F_FIRST):
        r = core.call(A_CONT_TICK, x0=modA, s0=1.0, w1=0)
        assert not r['error'], r
        st = state_vec(rd_state(core, modA + 0x158))
        rows.append({'frame': F_FIRST + 1 + k, 'pred': st,
                     'oracle': oracle[F_FIRST + 1 + k]['pos']})

    errs = np.array([np.array(rw['pred']) - np.array(rw['oracle'])
                     for rw in rows])
    rms = float(np.sqrt((errs ** 2).sum(axis=1).mean()))
    maxe = float(np.abs(errs).max())
    nq = sum(1 for rw in rows
             if [int(round(v * 256)) for v in rw['pred']] ==
             [int(round(v * 256)) for v in rw['oracle']])
    print(f'[flight 49..{F_END}] n={len(rows)} rms={rms*100:.2f}cm '
          f'max={maxe*100:.1f}cm exact_i16={nq}/{len(rows)}')
    for rw in rows[:5]:
        e = [round(v, 3) for v in np.array(rw['pred']) - np.array(rw['oracle'])]
        print(f"  f{rw['frame']}: pred={tuple(round(v,3) for v in rw['pred'])} "
              f"oracle={rw['oracle']} err={e}")

    json.dump({'kick_install': kick_info, 'rows': rows, 'rms_m': rms,
               'max_err_m': maxe, 'exact_i16': nq},
              open(OUT, 'w'), indent=1, default=float)
    print('JSON ->', OUT)


if __name__ == '__main__':
    main()
