#!/usr/bin/env python3
"""M10p: watch the stack visitor object's construction."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22
from m10_realctor import A_INNER_CTOR

OBJ = 0x60000fefc38


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    seen_vt = [False]

    def mem_write(uc, type_, address, size, value, ud):
        if OBJ - 0x20 <= address < OBJ + 0x40:
            pc = uc.reg_read(UC_ARM64_REG_PC)
            print(f'  WRITE obj[{address - OBJ:+#x}] = {value:#x} '
                  f'pc={pc - core.base:#x}')

    core.uc.hook_add(UC_HOOK_MEM_WRITE, mem_write)

    def at_938(uc, address, size, ud):
        if not seen_vt[0]:
            seen_vt[0] = True
            print(f'visitor enters 0x66fd938: '
                  f'vt={core.safe_read_u64(OBJ):#x} '
                  f'[+0x18]={core.safe_read_u64(OBJ + 0x18):#x}')

    core.uc.hook_add(UC_HOOK_CODE, at_938,
                     begin=core.base + 0x66fd938, end=core.base + 0x66fd938 + 4)

    def mem_err(uc, type_, address, size, value, ud):
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    core.uc.mem_write(core.base + 0x68a0f30, struct.pack('<I', 0xD503201F))
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    r = core.call(0x68a7a5c, timeout_s=120, max_insns=200_000_000)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)
    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=300,
                  max_insns=1_000_000_000)
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(9):
        before, after, err, pc = world.step(timeout_s=240)
        replug()
    print('--- step 9 (cmd 5): visitor writes ---')
    before, after, err, pc = world.step(timeout_s=240)
    replug()
    print(f'step: cmd {before:#x} -> {after:#x} err={err}')


if __name__ == '__main__':
    main()
