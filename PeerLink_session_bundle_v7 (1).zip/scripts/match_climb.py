#!/usr/bin/env python3
"""M4: locate the match tick via ancestry intersection + downward closure.

Photocopy strategy:
  1. Ancestor BFS (upward) from three independent seeds:
       ball path   : ball_update_entry 0x6e938a0
       player path : player replay writer 0x728d7e0 / serializer 0x6f45bc4
       command path: MatchCommand string user 0x7bff91c / RP_RAND_SEED 0x7ceafc4
  2. Intersection of ancestries = the common per-frame match update driver.
     Minimal elements (whose callers are outside the intersection) = tick roots.
  3. Path ProcessMatchMain 0x802d9d0 -> ball_update_entry (downward BFS,
     shortest path) = the exact call chain through the 'playing' state.
  4. Downward closure from the tick root = the photocopy candidate set;
     report funnel numbers.

Output: apk_lab/analysis/match_climb.json + console.
"""
import json
import numpy as np

AN = '/home/z/my-project/apk_lab/analysis'

fg = np.load(f'{AN}/fgraph.npz')
ent = np.sort(fg['entries'].astype(np.int64))
src = fg['src'].astype(np.int64)
dst = fg['dst'].astype(np.int64)

order = np.argsort(dst)
d_sorted = np.sort(dst)
s_sorted = src[order]

forder = np.argsort(src)
f_sorted = src[forder]
t_sorted = dst[forder]


def callers_of(f):
    i, j = np.searchsorted(d_sorted, f, 'left'), np.searchsorted(d_sorted, f, 'right')
    return np.unique(s_sorted[i:j])


def callees_of(f):
    i, j = np.searchsorted(f_sorted, f, 'left'), np.searchsorted(f_sorted, f, 'right')
    return np.unique(t_sorted[i:j])


def is_entry(f):
    return ent[np.searchsorted(ent, f)] == f if np.searchsorted(ent, f) < len(ent) else False


def ancestors(seed, max_funcs=200000):
    """Upward BFS. Returns (ancestor_set, levels list)."""
    seen = set()
    frontier = [seed]
    levels = []
    while frontier and len(seen) < max_funcs:
        seen.update(frontier)
        levels.append(frontier)
        nxt = set()
        for f in frontier:
            nxt.update(callers_of(f).tolist())
        nxt -= seen
        frontier = sorted(nxt)
    return set(seen), levels


SEEDS = {
    'ball': [0x6e938a0],
    'player': [0x728d7e0, 0x6f45bc4],
    'command': [0x7bff91c, 0x7ceafc4],
}

print('=== UPWARD ANCESTRY (per seed group) ===')
anc = {}
for name, seeds in SEEDS.items():
    u = set()
    for s in seeds:
        a, lv = ancestors(s)
        u |= a
        print(f'  {name} seed {s:#x}: {len(a):,} ancestors, {len(lv)} levels')
    anc[name] = u
    print(f'  => {name} union: {len(u):,}')

inter = anc['ball'] & anc['player'] & anc['command']
inter_bp = anc['ball'] & anc['player']
print(f'\nball ∩ player = {len(inter_bp):,}')
print(f'ball ∩ player ∩ command = {len(inter):,}')

# minimal elements of ball∩player: whose callers are all outside the set
def minimal_nodes(s, cap=40):
    out = []
    for f in sorted(s):
        cs = callers_of(f).tolist()
        if not any(c in s for c in cs):
            out.append(f)
        if len(out) >= cap:
            break
    return out


mins = minimal_nodes(inter_bp)
print(f'minimal common ancestors (ball∩player): {[hex(m) for m in mins[:40]]}')
mins3 = minimal_nodes(inter)
print(f'minimal common ancestors (all three): {[hex(m) for m in mins3[:40]]}')

# ---- downward BFS: ProcessMatchMain -> ball_update_entry shortest path ----
print('\n=== PATH ProcessMatchMain -> ball_update_entry ===')
START, GOAL = 0x802d9d0, 0x6e938a0
from collections import deque

prev = {START: None}
q = deque([START])
GOAL_REACHED = False
LEVEL = 0
visited = 0
while q:
    f = q.popleft()
    visited += 1
    if f == GOAL:
        GOAL_REACHED = True
        break
    for c in callees_of(f).tolist():
        if c not in prev:
            prev[c] = f
            q.append(c)
if GOAL_REACHED:
    path = [GOAL]
    while path[-1] is not None:
        path.append(prev[path[-1]])
    path = [p for p in path if p is not None]
    path.reverse()
    print(f'  path length {len(path)}: {" -> ".join(hex(p) for p in path)}')
else:
    print(f'  NO direct path from ProcessMatchMain (visited {visited:,} funcs) — '
          'dispatch is virtual/data-driven; check indirect edges')

# also try: shortest path from each minimal common ancestor down to ball seed
print('\n=== PATH tick-root candidate -> ball_update_entry ===')


def path_down(start, goal, cap=300000):
    prev = {start: None}
    q = deque([start])
    n = 0
    while q and n < cap:
        f = q.popleft()
        n += 1
        if f == goal:
            p = [goal]
            while p[-1] is not None:
                p.append(prev[p[-1]])
            return [x for x in p if x is not None]
        for c in callees_of(f).tolist():
            if c not in prev:
                prev[c] = f
                q.append(c)
    return None


for m in mins3[:8] + mins[:8]:
    p = path_down(m, GOAL)
    if p:
        print(f'  {m:#x} -> ball: {" -> ".join(hex(x) for x in p)}')

# ---- downward closure funnel from tick root ----
print('\n=== DOWNWARD CLOSURE ===')


def closure(roots):
    seen = set()
    q = deque(roots)
    while q:
        f = q.popleft()
        if f in seen:
            continue
        seen.add(f)
        for c in callees_of(f).tolist():
            if c not in seen:
                q.append(c)
    return seen


root_set = set(mins3[:4]) | set(mins[:4]) or {GOAL}
cl = closure(sorted(root_set))
print(f'closure of tick-root candidates: {len(cl):,} functions')

# PLT-reachable count (imports the closure needs)
plt = json.load(open(f'{AN}/plt_map.json'))
plt_addrs = [int(k, 16) for k in plt]
cl_arr = np.fromiter(cl, dtype=np.int64)
plt_arr = np.array(plt_addrs, dtype=np.int64)
imports_needed = np.intersect1d(cl_arr, plt_arr)
print(f'PLT imports in closure: {len(imports_needed)}')
names = sorted(plt[hex(a)]['sym'] for a in imports_needed.tolist()[:200])
print('  sample:', names[:40])

json.dump({
    'ancestry_sizes': {k: len(v) for k, v in anc.items()},
    'inter_ball_player': len(inter_bp),
    'inter_all': len(inter),
    'minimal_bp': [hex(m) for m in mins],
    'minimal_all': [hex(m) for m in mins3],
    'closure_size': len(cl),
    'imports_needed': [plt[hex(a)]['sym'] for a in imports_needed.tolist()],
}, open(f'{AN}/match_climb.json', 'w'), indent=1)
print('\nJSON ->', f'{AN}/match_climb.json')
