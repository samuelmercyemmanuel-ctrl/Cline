#!/usr/bin/env python3
"""PeerLink enhanced loader v2 — EFootballCore plus the Milestone-2 machinery.

Adds to the Session-A loader (uc_loader.py):
- full fault coverage (UC_HOOK_MEM_PROT / FETCH_PROT — the pc=0 crash class)
- GOT-hijack API (plt_map.json driven): redirect internal-symbol PLT slots
  (operator new/delete — UE FMemory overrides) to Python-emulated stubs
- real import stub suite: zeroing malloc/calloc, posix_memalign (writes ptr),
  pthread TLS keys/mutex, vsnprintf (real formatting), realloc, str*, mmap...
- fault-tolerant guest reads in stub context (safe_read)
- function neutralization (patch RET) for engine-plumbing registrations
- code watchers (per-address hooks with register capture)
- call(fn, ...) with x8 (sret) support and per-call fault log isolation
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from uc_loader import (EFootballCore, STUB_BASE, RET_TRAP, HEAP_BASE,
                       HEAP_SIZE, STACK_BASE, STACK_SIZE, TLS_BASE)
from unicorn import *
from unicorn.arm64_const import *
import unicorn.arm64_const as A64C

AN = '/home/z/my-project/apk_lab/analysis'


def RET_INSN():
    return struct.pack('<I', 0xD65F03C0)


class EFootballCoreV2(EFootballCore):
    def __init__(self, so_path='/home/z/my-project/apk_lab/libUE4.so',
                 base=0x10000000000, fpcr=0, verbose=True):
        super().__init__(so_path=so_path, base=base, fpcr=fpcr, verbose=verbose)
        self.watchers = []
        self._add_prot_hooks()
        self._install_rich_stubs()
        if self.verbose:
            print('[loader2] PROT hooks + rich stubs installed')

    # ---------------------------------------------------------- fault hooks
    def _add_prot_hooks(self):
        uc = self.uc
        # cover fetch-protection faults (pc landing in non-exec pages, e.g. pc=0)
        uc.hook_add(UC_HOOK_MEM_PROT | UC_HOOK_MEM_FETCH_PROT, self._prot_fault)

    def _prot_fault(self, uc, access, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        is_fetch = access in (UC_MEM_FETCH_UNMAPPED, UC_MEM_FETCH_PROT)
        if is_fetch:
            self._log.append(f'FETCH FAULT access={access} addr={address:#x} pc={pc:#x}')
            return False
        # data access to a protected page: try demand-zero outside the image
        if address < self.base and self._auto_pages < 512:
            page = address & ~0xFFF
            try:
                uc.mem_map(page, 0x1000, UC_PROT_READ | UC_PROT_WRITE)
                self._auto_pages += 1
                self._log.append(f'auto-zero page {page:#x} (prot access={access} pc={pc:#x})')
                return True
            except UcError:
                pass
        self._log.append(f'PROT FAULT access={access} addr={address:#x} size={size} pc={pc:#x}')
        return False

    # ------------------------------------------------------------ safe read
    def safe_read(self, addr, n):
        try:
            return bytes(self.uc.mem_read(addr, n))
        except UcError:
            return b'\0' * n

    def safe_read_u64(self, addr):
        return struct.unpack('<Q', self.safe_read(addr, 8))[0]

    def safe_read_u32(self, addr):
        return struct.unpack('<I', self.safe_read(addr, 4))[0]

    def write_u32(self, addr, v):
        self.uc.mem_write(addr, struct.pack('<I', v & 0xFFFFFFFF))

    def write_u64(self, addr, v):
        self.uc.mem_write(addr, struct.pack('<Q', v & 0xFFFFFFFFFFFFFFFF))

    def write_u16(self, addr, v):
        self.uc.mem_write(addr, struct.pack('<H', v & 0xFFFF))

    def write_u8(self, addr, v):
        self.uc.mem_write(addr, bytes([v & 0xFF]))

    def write_f32(self, addr, v):
        self.uc.mem_write(addr, struct.pack('<f', v))

    def read_f32(self, addr):
        return struct.unpack('<f', self.safe_read(addr, 4))[0]

    # ------------------------------------------------------------ GOT hijack
    def hijack_plt(self, symbol, handler_name=None):
        """Write a Python-emulated stub address into the GOT slot used by the
        PLT entry for `symbol` (works for internal symbols too, e.g. _Znwm)."""
        plt = json.load(open(f'{AN}/plt_map.json'))
        hits = [(int(k, 16), v) for k, v in plt.items() if v['sym'] == symbol]
        if not hits:
            raise KeyError(f'PLT entry for {symbol} not found')
        stub = self._get_stub(handler_name or symbol)
        for plt_addr, info in hits:
            got = self.base + info['got']
            self.write_u64(got, stub)
            if self.verbose:
                print(f'[loader2] hijacked {symbol}: PLT {plt_addr:#x} GOT {got:#x} '
                      f'(internal={info.get("internal")}) -> stub {stub:#x}')
        return stub

    def patch_got(self, vaddr, value):
        self.write_u64(self.base + vaddr, value)

    # ------------------------------------------------------------ stub suite
    def _install_rich_stubs(self):
        """Pre-assign stub addresses for the rich import set (dispatch by addr)."""
        for name in ('_Znwm_h', '_Znam_h', '_ZdlPv_h', '_ZdaPv_h',
                     'posix_memalign_h', 'aligned_alloc_h',
                     'vsnprintf_h', 'sprintf_h', 'snprintf_h',
                     'pthread_getspecific_h', 'pthread_setspecific_h',
                     'pthread_key_create_h', 'pthread_key_delete_h',
                     'pthread_mutex_lock_h', 'pthread_mutex_unlock_h',
                     'pthread_mutex_init_h', 'pthread_once_h', 'pthread_self_h',
                     'realloc_h', 'memchr_h', 'strchr_h', 'strcmp_h',
                     'strncmp_h', 'strcpy_h', 'strncpy_h', 'strdup_h',
                     '__android_log_print_h', 'gettimeofday_h', 'clock_gettime_h',
                     'mmap_h', 'mprotect_h', '__errno_h'):
            self._get_stub(name)
        # ---- platform patch (DROP-class): thread-contention wait removal ----
        # std::ndk1::timed_mutex::lock at 0x823bec8 waits while [mtx+0x58]
        # (owner/waiter flag) is set. Headless = no other threads, so the
        # flag can never be legitimately set; garbage in partially-
        # constructed embedded mutexes spins it forever. Same precedent as
        # the v4 camera cond_wait neutralization.
        # 0x823bef4: ldrb w8, [x19, #0x58]  ->  movz w8, #0  (always fast path)
        self.uc.mem_write(self.base + 0x823bef4, struct.pack('<I', 0x52800008))
        # ---- platform patch (DROP-class): __cxa_guard single-thread semantics
        # bionic: [0]=done, [1]=in-progress(owner) + same-thread abort.
        # Headless: keep the in-progress marker (prevents ctor re-entry
        # recursion) but drop the abort (recursive access proceeds with
        # partial data instead of dying). A ctor must reach release to be
        # marked done; abort clears the marker (retryable).
        acq = struct.pack('<12I',
                          0x39400009,          # 0:  ldrb w9, [x0]       (done?)
                          0x34000069,          # 4:  cbz w9, +12 -> 16
                          0x2A1F03E0,          # 8:  mov w0, wzr
                          0xD65F03C0,          # 12: ret
                          0x39400409,          # 16: ldrb w9, [x0, #1]   (in progress?)
                          0x34000069,          # 20: cbz w9, +12 -> 32
                          0x2A1F03E0,          # 24: mov w0, wzr
                          0xD65F03C0,          # 28: ret
                          0x52800029,          # 32: mov w9, #1
                          0x39000409,          # 36: strb w9, [x0, #1]   (mark in-progress)
                          0x52800020,          # 40: mov w0, #1
                          0xD65F03C0)          # 44: ret
        self.uc.mem_write(self.base + 0x8207b84, acq)
        # __cxa_guard_release: done=1, in-progress=0
        self.uc.mem_write(self.base + 0x8207cc8,
                          struct.pack('<4I', 0x52800029, 0x39000009,
                                      0x3900041F, 0xD65F03C0))
        # __cxa_guard_abort: clear in-progress
        self.uc.mem_write(self.base + 0x8207d70,
                          struct.pack('<2I', 0x3900041F, 0xD65F03C0))

    # dispatch: override the parent hook to implement the rich set
    def _stub_hook(self, uc, addr, size, ud):
        name = self.stub_of.get(addr, f'unknown_{addr:#x}')
        # normalize: rich-stub names carry a _h suffix; GOT-relocated calls
        # arrive with the plain symbol name. Strip the suffix so BOTH hit
        # the rich handlers (posix_memalign, pthread_once, mmap, ...).
        if name.endswith('_h'):
            name = name[:-2]
        self.import_calls[name] = self.import_calls.get(name, 0) + 1
        lr = uc.reg_read(UC_ARM64_REG_LR)
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        x1 = uc.reg_read(UC_ARM64_REG_X1)
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        x3 = uc.reg_read(UC_ARM64_REG_X3)
        x4 = uc.reg_read(UC_ARM64_REG_X4)
        ret = 0
        if name in ('memcpy', 'memmove'):
            n = x2
            if n:
                uc.mem_write(x0, self.safe_read(x1, n))
            ret = x0
        elif name == 'memset':
            n = x2
            if n:
                uc.mem_write(x0, bytes([x1 & 0xFF]) * n)
            ret = x0
        elif name in ('malloc', '_Znwm', '_Znam'):
            n = x0 if name == 'malloc' else x0
            ret = self._heap_alloc_zero(n)
        elif name == 'calloc':
            ret = self._heap_alloc_zero(x0 * x1) if x0 and x1 else 0
        elif name in ('realloc',):
            n = x1
            old = self.safe_read(x0, self._alloc_size.get(x0, 0)) if x0 else b''
            ret = self._heap_alloc_zero(max(n, 0))
            if n:
                uc.mem_write(ret, old[:n])
        elif name in ('free', '_ZdlPv', '_ZdaPv'):
            ret = 0
        elif name in ('posix_memalign',):
            # int posix_memalign(void **memptr, size_t alignment, size_t size)
            p = self._heap_alloc_zero(x2, align=x1)
            self.write_u64(x0, p)
            ret = 0
        elif name in ('aligned_alloc',):
            ret = self._heap_alloc_zero(x1, align=x0)
        elif name in ('strlen',):
            data = self.safe_read(x0, 4096)
            idx = data.find(b'\0')
            ret = idx if idx >= 0 else 4096
        elif name in ('strcmp',):
            a = self.safe_read(x0, 256).split(b'\0')[0]
            b = self.safe_read(x1, 256).split(b'\0')[0]
            ret = 0 if a == b else (1 if a > b else 0xFFFFFFFFFFFFFFFF)
        elif name in ('strncmp',):
            a = self.safe_read(x0, x2).split(b'\0')[0]
            b = self.safe_read(x1, x2).split(b'\0')[0]
            ret = 0 if a == b else 1
        elif name in ('strcpy', 'strncpy'):
            src = self.safe_read(x1, 4096).split(b'\0')[0]
            if name == 'strncpy':
                src = src[:x2]
            uc.mem_write(x0, src + b'\0')
            ret = x0
        elif name in ('strdup',):
            src = self.safe_read(x0, 4096).split(b'\0')[0] + b'\0'
            ret = self._heap_alloc_zero(len(src))
            uc.mem_write(ret, src)
        elif name in ('memchr', 'strchr'):
            data = self.safe_read(x0, 512)
            needle = x1 & 0xFF
            idx = data.find(bytes([needle]))
            ret = (x0 + idx) if idx >= 0 else 0
        elif name in ('vsnprintf', 'snprintf'):
            ret = self._emu_snprintf(uc, name, x0, x1, x2)
        elif name in ('sprintf',):
            ret = self._emu_snprintf(uc, name, x0, 1 << 30, x1)
        elif name in ('pthread_getspecific', 'pthread_getspecific'):
            ret = self._tls_get(x0)
        elif name in ('pthread_setspecific', 'pthread_setspecific'):
            self._tls_set(x0, x1)
            ret = 0
        elif name in ('pthread_key_create',):
            # write a fresh key id
            self._key_seq = getattr(self, '_key_seq', 16) + 1
            self.write_u32(x0, self._key_seq)
            ret = 0
        elif name in ('pthread_key_delete', 'pthread_mutex_lock',
                      'pthread_mutex_unlock', 'pthread_mutex_init',
                      'pthread_mutex_lock', 'pthread_mutex_unlock',
                      'pthread_mutex_init', 'pthread_key_delete'):
            ret = 0
        elif name in ('pthread_once', 'pthread_once'):
            # REAL semantics: run the init routine exactly once.
            # The old zero-return stub made TLS init retry ~292k times
            # (once-control never set) -> the 80M-insn spin in cmd 0.
            if x0 and self.safe_read_u32(x0) == 0:
                self.write_u32(x0, 1)          # set FIRST (recursion-safe)
                if x1:
                    # jump into the init routine; ret -> lr (original caller)
                    uc.reg_write(UC_ARM64_REG_X0, 0)
                    uc.reg_write(UC_ARM64_REG_PC, x1)
                    return
            ret = 0
        elif name in ('pthread_self',):
            ret = 0x70000011
        elif name in ('__errno',):
            ret = self._errno_addr()
        elif name in ('gettimeofday', 'clock_gettime'):
            # zero tv structs (deterministic time)
            if x1:
                uc.mem_write(x1, b'\0' * 16)
            ret = 0
        elif name in ('__android_log_print',):
            ret = 0
        elif name in ('mmap',):
            # REAL mmap: map fresh zero pages in a dedicated arena.
            # (The game's memory pools mmap/munmap for growth; the old
            # heap-fake stub corrupted pool bookkeeping.)
            length = x1
            if length:
                if not hasattr(self, '_mmap_next'):
                    self._mmap_next = 0xA90000000000
                a = (self._mmap_next + 0xFFFF) & ~0xFFFF
                need = (length + 0xFFFF) & ~0xFFFF
                try:
                    self.uc.mem_map(a, need, UC_PROT_ALL)
                except UcError:
                    pass
                self._mmap_next = a + need
                ret = a
            else:
                ret = 0
        elif name in ('munmap',):
            # REAL munmap: unmap the page range (best effort).
            if x0 and x1:
                start = x0 & ~0xFFF
                span = (x1 + (x0 - start) + 0xFFF) & ~0xFFF
                try:
                    self.uc.mem_unmap(start, span)
                except UcError:
                    self._log.append(f'munmap({x0:#x},{x1:#x}) failed (ignored)')
            ret = 0
        elif name in ('sysconf',):
            # REAL platform values (ARM64 Android). _SC_PAGESIZE=39 -> 4096;
            # the game's memory pools use it as the per-block overhead.
            if x0 == 39:            # _SC_PAGESIZE
                ret = 4096
            elif x0 == 40:          # _SC_NPROCESSORS_ONLN
                ret = 4
            elif x0 in (74, 118):   # _SC_NPROCESSORS_CONF / _SC_PAGESIZE alt
                ret = 4 if x0 == 74 else 4096
            else:
                ret = 4096
        elif name == '__stack_chk_fail':
            self._log.append(f'STACK GUARD MISMATCH at lr={lr:#x}')
            uc.emu_stop()
            return
        elif name in ('abort',):
            self._log.append(f'abort() called from lr={lr:#x}')
            uc.emu_stop()
            return
        else:
            if len(self._log) < 400:
                self._log.append(f'unhandled import: {name} (lr={lr:#x}) -> returning 0')
        uc.reg_write(UC_ARM64_REG_X0, ret & 0xFFFFFFFFFFFFFFFF)
        uc.reg_write(UC_ARM64_REG_PC, lr)

    def _heap_alloc_zero(self, n, align=16):
        """Zeroing allocator (UE object payloads must be zeroed)."""
        if n == 0:
            n = 16
        a = self.next_heap
        if align and align > 16:
            a = (a + align - 1) & ~(align - 1)
        self.next_heap = (a + max(n, 16) + 0xFF) & ~0xFF
        self._alloc_size = getattr(self, '_alloc_size', {})
        self._alloc_size[a] = n
        try:
            self.uc.mem_write(a, b'\0' * max(n, 16))
        except UcError:
            # grow heap if needed
            need = self.next_heap - HEAP_BASE
            if need > HEAP_SIZE:
                self.uc.mem_map(HEAP_BASE + HEAP_SIZE, 0x10000000)
            self.uc.mem_write(a, b'\0' * max(n, 16))
        return a

    def _tls_get(self, key):
        if not hasattr(self, '_tls_vals'):
            self._tls_vals = {}
        return self._tls_vals.get(key, 0)

    def _tls_set(self, key, val):
        if not hasattr(self, '_tls_vals'):
            self._tls_vals = {}
        self._tls_vals[key] = val

    def _errno_addr(self):
        if not hasattr(self, '_errno_a'):
            self._errno_a = self.alloc(64, b'\0' * 64, name='errno')
        return self._errno_a

    # ---------------------------------------------------------- snprintf emu
    def _emu_snprintf(self, uc, kind, out, size, fmt):
        """Minimal but REAL snprintf: supports %s %d %02d %u %x %f %c %p %%.
        Varargs: ints in x2..x7 then stack (for sprintf: x1..x6)."""
        base_arg = 2 if kind != 'sprintf_h' else 1
        regs = [uc.reg_read(getattr(A64C, f'UC_ARM64_REG_X{i}'))
                for i in range(base_arg, 8)]
        # stack varargs
        sp = uc.reg_read(UC_ARM64_REG_SP)
        stack = []
        try:
            stack_raw = bytes(uc.mem_read(sp, 64))
            for i in range(8):
                (v,) = struct.unpack_from('<Q', stack_raw, i * 8)
                stack.append(v)
        except UcError:
            stack = [0] * 8
        varargs = regs + stack
        fmt_s = self.safe_read(fmt, 512).split(b'\0')[0].decode('utf-8', 'replace')
        out_b = b''
        ai = 0

        def nextarg():
            nonlocal ai
            v = varargs[ai] if ai < len(varargs) else 0
            ai += 1
            return v

        i = 0
        while i < len(fmt_s):
            c = fmt_s[i]
            if c != '%':
                out_b += c.encode()
                i += 1
                continue
            j = i + 1
            spec = '%'
            while j < len(fmt_s) and fmt_s[j] not in 'diufcxXspge%':
                spec += fmt_s[j]
                j += 1
            if j >= len(fmt_s):
                break
            conv = fmt_s[j]
            spec += conv
            try:
                if conv == '%':
                    out_b += b'%'
                elif conv == 's':
                    p = nextarg()
                    out_b += self.safe_read(p, 256).split(b'\0')[0]
                elif conv in 'di':
                    v = nextarg()
                    sv = v if v < (1 << 63) else v - (1 << 64)
                    out_b += (spec % sv).encode()
                elif conv in 'uxX':
                    out_b += (spec % nextarg()).encode()
                elif conv in 'feEgG':
                    # floats come via SIMD; approximate from int regs is wrong,
                    # but the ctor only uses %d/%s — treat as 0.0 fallback
                    raw = nextarg()
                    out_b += (spec % 0.0).encode()
                elif conv == 'c':
                    out_b += bytes([nextarg() & 0xFF])
                elif conv == 'p':
                    out_b += (f'{nextarg():#x}').encode()
            except Exception:
                pass
            i = j + 1
        if kind != 'sprintf_h':
            out_b = out_b[:max(size - 1, 0)]
        try:
            uc.mem_write(out, out_b + b'\0')
        except UcError:
            pass
        return len(out_b)

    # ------------------------------------------------------------ utilities
    def neutralize(self, vaddr, note=''):
        """Patch a function to a bare RET (engine-plumbing neutralization)."""
        self.uc.mem_write(self.base + vaddr, RET_INSN())
        self._neutralized = getattr(self, '_neutralized', set())
        self._neutralized.add(vaddr)
        if self.verbose:
            print(f'[loader2] neutralized {vaddr:#x} {note}')

    def watch(self, vaddr, callback, name=''):
        """Code watcher at one address; callback(uc, core). One hook per
        watcher, dispatch ONLY its own callback. Returns a handle with
        .remove()."""
        w = dict(addr=vaddr, cb=callback, name=name, h=None, active=True)

        def _dispatch(uc, addr, size, ud):
            if w['active']:
                try:
                    w['cb'](uc, self)
                except Exception as e:
                    self._log.append(f'watcher {w["name"]} error: {e}')

        w['h'] = self.uc.hook_add(UC_HOOK_CODE, _dispatch,
                                  begin=self.base + vaddr,
                                  end=self.base + vaddr + 3)
        self.watchers.append(w)
        return w

    def unwatch(self, w):
        w['active'] = False
        try:
            self.uc.hook_del(w['h'])
        except Exception:
            pass
        if w in self.watchers:
            self.watchers.remove(w)

    def call_x8(self, fn, x0=0, x1=0, x2=0, x3=0, w4=0, w5=0, x8=None,
                timeout_s=60, max_insns=100_000_000):
        """Call with x8 (sret) support."""
        uc = self.uc
        uc.reg_write(UC_ARM64_REG_X0, x0)
        uc.reg_write(UC_ARM64_REG_X1, x1)
        uc.reg_write(UC_ARM64_REG_X2, x2)
        uc.reg_write(UC_ARM64_REG_X3, x3)
        uc.reg_write(UC_ARM64_REG_X4, w4)
        uc.reg_write(UC_ARM64_REG_X5, w5)
        if x8 is not None:
            uc.reg_write(UC_ARM64_REG_X8, x8)
        uc.reg_write(UC_ARM64_REG_SP, self.sp0)
        for i in range(6, 29):
            uc.reg_write(getattr(A64C, f'UC_ARM64_REG_X{i}'), 0)
        uc.reg_write(UC_ARM64_REG_X29, self.sp0 - 0x1000)  # sane frame ptr
        uc.reg_write(UC_ARM64_REG_LR, RET_TRAP)
        try:
            uc.emu_start(self.base + fn, RET_TRAP,
                         timeout=timeout_s * 1_000_000, count=max_insns)
            err = None
        except UcError as e:
            err = e
        return {'error': str(err) if err else None,
                'pc': uc.reg_read(UC_ARM64_REG_PC),
                'x0': uc.reg_read(UC_ARM64_REG_X0)}

    # ------------------------------------------------- fabricated singletons
    def fabricate_component_manager(self, comp_id=0x4D, comp_size=0x10000):
        """*(0xa40f950) = M(0x48); [M+0] = comps[245]; comps[comp_id] = C.
        Returns C — install params (ball.o) at C+8."""
        M = self.alloc(0x48, b'\0' * 0x48, name='comp_manager')
        comps = self.alloc(245 * 8, b'\0' * (245 * 8), name='comp_array')
        C = self.alloc(comp_size, b'\0' * comp_size, name=f'comp_{comp_id:#x}')
        self.write_u64(M, comps)
        self.write_u64(comps + 8 * comp_id, C)
        self.write_u64(self.base + 0xa40f950, M)
        if self.verbose:
            print(f'[loader2] component manager @ *(0xa40f950) -> M={M:#x}; '
                  f'comp[{comp_id:#x}] = {C:#x}')
        return C

    def set_substep_global(self, N):
        """*(0x98dddc8) -> &N  (chain_top reads w4 = *(*(0x98dddc8)))."""
        if not hasattr(self, '_n_cell'):
            self._n_cell = self.alloc(16, struct.pack('<II', N, 0), name='n_cell')
        self.write_u32(self._n_cell, N)
        self.write_u64(self.base + 0x98dddc8, self._n_cell)
        return self._n_cell

    def fabricate_module_registry(self, size=0x1000):
        """*(0x98ddd28) -> R (6e91da8 registers module at [R + idx*8 + 0x298])."""
        R = self.alloc(size, b'\0' * size, name='module_registry')
        self.write_u64(self.base + 0x98ddd28, R)
        return R


if __name__ == '__main__':
    core = EFootballCoreV2()
    r = core.call(0x6813eb8)
    bits = core.uc.reg_read(UC_ARM64_REG_S0)
    import struct as _s
    print('[selftest2] timestep =', _s.unpack('<f', _s.pack('<I', bits & 0xFFFFFFFF))[0])
    print('[selftest2] log:', core._log[:5])
