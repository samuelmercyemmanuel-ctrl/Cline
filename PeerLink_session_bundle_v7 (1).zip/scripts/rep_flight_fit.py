#!/usr/bin/env python3
"""MILESTONE 3 v3: replay-oracle flight fit against the RECORD STREAM.

Decoded this session (the framing that finally makes everything consistent):
- The entry tick (ball_update_entry) runs chain_top, which calls chain_mid
  TWICE:
    (a) 0x6ea1f64: w3=1 (init step on substep 0), N substeps from
        *(*(0x98dddc8)) -> the published state stream (+0x158)
    (b) 0x6ea23d4: w3=0, N=1 -> ONE PURE semi-implicit substep, result
        memcpy'd forward - the per-substep RECORDER stream
- The .rep oracle records = the recorder stream: 1 record = 1 committed
  w4=0 kernel substep at dt=1/27 (semi-implicit - matches the prior
  session's finite-difference proof and the replay's per-record
  displacements ~ v'*dt).
- Therefore the correct simulator for the oracle is a PURE w4=0 kernel
  chain from the segment-start state - NOT the entry tick's published
  stream (which re-runs the init step every tick: 2x velocity advance,
  gravity -19.61 measured).

Ladder blocker (documented, not solved):
- The kernel calls the air-curve/drag fn 0x6ea1938 (at 0x6ea0a44) every
  substep; at L1 speed |vx|+|vy| > 7.716 m/s it invokes the speed-class
  ladder 0x6ea555c, which reads 6 thresholds from the STATE +0x74..0x88
  and recurses forever if the top threshold is zero (my fabricated states
  have zeros there - the real values are installed by paramsB machinery
  not yet reconstructed).
- state+0x8c mode: 0=ladder, 1=FText, >=2=zero-return (disabled).
  We set mode 8 = air-curve layer OFF, measuring the kernel-only force
  model. The kernel's own quadratic drag (params airRegist + ball.o
  gates 10/85 km/h) and gravity -9.80665 still apply.

Experiment:
- oracle: tutorial_replay_shooting_02.rep, clean flight frames 49..66
- fit v0 (3) + spin rot (3) + airRegist (params[0]) with least squares
- state_idx sweep 0..6
- out-of-sample verification on the late flight frames
- calibration: gravity per state idx + drag at 25.5 m/s (mode 8)

Run: python scripts/rep_flight_fit.py [--idx-sweep]
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import (BallWorld, A_KERNEL, STATE_SZ, rd_state)
from unicorn.arm64_const import *   # noqa: F401

OUT = '/home/z/my-project/apk_lab/analysis/rep_flight_fit.json'
DT = 1.0 / 27.0
RADIUS = 0.1086859330534935
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')


def load_flight():
    from replay_parse import parse_rep, active_ball
    r = parse_rep(REP)
    ball = np.array([active_ball(rec)['pos'] for rec in r['records']])
    return ball


def set_air(world, air):
    world.core.uc.mem_write(world.params, struct.pack('<f', air))


def record_chain(world, p0, v0, rot, air, n_records, state_idx=0, mode=8,
                 first_init=False):
    """Pure w4=0 kernel chain = the .rep record stream semantics.

    One committed substep per record, dt=1/27, semi-implicit Euler.
    mode (state+0x8c) = 8 disables the unreconstructed air-curve ladder.
    first_init: optionally run one w4=1 init step first (kick semantics)."""
    set_air(world, air)
    core = world.core
    s = bytearray(STATE_SZ)
    struct.pack_into('<3f', s, 0x000, *p0)
    struct.pack_into('<3f', s, 0x00C, *v0)
    struct.pack_into('<3f', s, 0x018, *rot)
    s[0x90] = 1                      # phys
    s[0x91] = 6                      # sub = flight
    struct.pack_into('<i', s, 0x094, state_idx)
    struct.pack_into('<4f', s, 0x098, 1.0, 0.0, 0.0, 0.0)
    struct.pack_into('<i', s, 0x08C, mode)
    st = core.alloc(STATE_SZ, bytes(s), name='fit_state')
    world.reset_kernel_ctx()
    pts = []
    seq = ([(1, 0)] if first_init else []) + [(0, 0)] * n_records
    for (w4, w5) in seq:
        r = core.call(A_KERNEL, w0=0, w1=1, x2=st, x3=world.params,
                      s0=DT, w4=w4, w5=w5)
        if r['error']:
            raise RuntimeError(f'kernel step failed: {r}')
        b = rd_state(core, st)
        pts.append(struct.unpack_from('<3f', b, 0))
    return np.array(pts)


def forces(pts):
    """Finite-difference forces from per-record positions (dt = 1/27)."""
    v = np.diff(pts, axis=0) / DT
    a = np.diff(v, axis=0) / DT
    return a


def calibrate(world):
    """Kernel gravity per state idx + drag at v=25.5 (mode 8 chain)."""
    out = {}
    for idx in range(7):
        pts = record_chain(world, (0, 3.0, 0), (0, 0, 0), (0, 0, 0),
                           1.0, 8, state_idx=idx)
        a = forces(pts)
        out[f'gravity_idx{idx}'] = float(a[:, 1].mean())
    pts = record_chain(world, (0, 3.0, 0), (25.5, 0, 0), (0, 0, 0), 1.0, 8)
    a = forces(pts)
    out['drag_x_at_25.5_airRegist1'] = float(a[:, 0].mean())
    out['drag_y_at_25.5'] = float(a[:, 1].mean())
    return out


def fit_idx(world, seg, state_idx, max_nfev=60):
    """Fit v0(3)+rot(3)+airRegist(1) for one state_idx. Returns dict."""
    from scipy.optimize import least_squares
    p0_replay = seg[0]
    v0_replay = (seg[1] - seg[0]) / DT
    n = len(seg) - 1

    def resid(x):
        v0, rot, air = x[0:3], x[3:6], x[6]
        try:
            pts = record_chain(world, p0_replay, v0, rot, air, n,
                               state_idx=state_idx)
        except Exception:
            return np.full(3 * n, 1e3)
        return (pts - seg[1:]).flatten()

    x0 = np.array([*v0_replay, 0.0, 0.0, 0.0, 1.0])
    sol = least_squares(resid, x0,
                        bounds=([-60] * 3 + [-200] * 3 + [0.0],
                                [60] * 3 + [200] * 3 + [10.0]),
                        diff_step=0.05, max_nfev=max_nfev, verbose=0)
    rms = float(np.sqrt(2 * sol.cost / (3 * n)))
    hold = np.arange(n - 6, n)
    pts = record_chain(world, p0_replay, sol.x[0:3], sol.x[3:6], sol.x[6],
                       n, state_idx=state_idx)
    oos = float(np.abs(pts[hold] - seg[hold + 1]).max())
    return {'state_idx': state_idx, 'v0': sol.x[0:3].tolist(),
            'rot': sol.x[3:6].tolist(), 'airRegist': float(sol.x[6]),
            'resid_rms_m': rms, 'oos_max_err_m': oos, 'cost': float(sol.cost)}


def main():
    sweep = '--idx-sweep' in sys.argv
    ball = load_flight()
    seg = ball[49:67]          # clean flight (oracle)
    print(f'[oracle] flight frames 49..66, n={len(seg)}, '
          f"start={seg[0].round(3)} end={seg[-1].round(3)}")

    a_rep = forces(seg)
    print(f"[oracle] replay g_eff: {a_rep[:,1].mean():.3f}  "
          f"replay x-drag: {a_rep[:,0].mean():.3f}")

    world = BallWorld(verbose=False)
    world.construct()

    print('[calibration] record-chain probes (mode 8)')
    cal = calibrate(world)
    for k, v in cal.items():
        print(f'  {k}: {v:.4f}')

    # anomaly: kernel-only prediction with replay v0, no spin, airRegist=1
    v0_rep = (seg[1] - seg[0]) / DT
    pred = record_chain(world, seg[0], v0_rep, (0, 0, 0), 1.0, len(seg) - 1)
    a_pred = forces(pred)
    anomaly = {
        'kernel_g_eff': float(a_pred[:, 1].mean()),
        'kernel_drag_x': float(a_pred[:, 0].mean()),
        'replay_g_eff': float(a_rep[:, 1].mean()),
        'replay_drag_x': float(a_rep[:, 0].mean()),
        'raw_pred_max_pos_err_m': float(np.abs(pred[-1] - seg[-1]).max()),
    }
    print(f"[anomaly] kernel g_eff {anomaly['kernel_g_eff']:.3f} vs replay "
          f"{anomaly['replay_g_eff']:.3f}; kernel drag_x "
          f"{anomaly['kernel_drag_x']:.3f} vs replay {anomaly['replay_drag_x']:.3f}")
    print(f"[anomaly] raw kernel-only prediction: max pos error at frame 66: "
          f"{anomaly['raw_pred_max_pos_err_m']:.3f} m")

    # ---- fits ----
    print('[fit] state_idx = 0 (default flight row)')
    best = fit_idx(world, seg, 0)
    print(f"  fit: v0={np.round(best['v0'],2).tolist()} "
          f"rot={np.round(best['rot'],2).tolist()} "
          f"airRegist={best['airRegist']:.4f}")
    print(f"  resid rms: {best['resid_rms_m']:.4f} m   "
          f"oos max err: {best['oos_max_err_m']:.4f} m")
    fits = [best]

    if sweep:
        print('[fit] sweeping state_idx 1..6')
        for idx in range(1, 7):
            f = fit_idx(world, seg, idx, max_nfev=40)
            print(f"  idx={idx}: rms {f['resid_rms_m']:.4f} m  "
                  f"oos {f['oos_max_err_m']:.4f} m  "
                  f"air={f['airRegist']:.3f}")
            fits.append(f)
        best = min(fits, key=lambda f: f['resid_rms_m'])
        print(f"  BEST idx={best['state_idx']} rms={best['resid_rms_m']:.4f} m")

    res = {'simulator': 'pure w4=0 kernel chain (record-stream semantics), '
                        'mode 8 (air-curve ladder disabled)',
           'calibration': cal, 'anomaly': anomaly, 'fits': fits,
           'best_state_idx': best['state_idx'],
           'replay_g_eff': float(a_rep[:, 1].mean()),
           'replay_drag_x': float(a_rep[:, 0].mean()),
           'oracle': seg.tolist()}
    json.dump(res, open(OUT, 'w'), indent=1, default=float)
    print('JSON ->', OUT)


if __name__ == '__main__':
    main()
