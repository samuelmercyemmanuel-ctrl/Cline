#!/usr/bin/env python3
"""M10e: watch all writes to [inner+8] (the cmd id)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22
from m10_realctor import A_INNER_CTOR


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    target = inner + 8
    log = []

    def mem_write(uc, type_, address, size, value, ud):
        if address <= target < address + size:
            pc = uc.reg_read(UC_ARM64_REG_PC)
            log.append((value, pc - core.base))
            print(f'  CMD WRITE {value} at pc={pc - core.base:#x}')

    core.uc.hook_add(UC_HOOK_MEM_WRITE, mem_write)

    def mem_err(uc, type_, address, size, value, ud):
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=120,
                  max_insns=100_000_000)
    print('inner ctor err:', r['error'])
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(6):
        print(f'--- step {i} ---')
        log.clear()
        before, after, err, pc = world.step()
        replug()
        n = sum(1 for p in slots22(core, inner) if p)
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err} slots={n}')
        if not log:
            print('  (no cmd writes)')


if __name__ == '__main__':
    main()
