#!/usr/bin/env python3
"""M5.1b: map adrp-ref sites to containing functions, resolve exact string
refs (adrp page + add), and disassemble the referencing functions.
"""
import numpy as np
import json
import struct

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

from elftools.elf.elffile import ELFFile
f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
loads.sort()
data = open(SO, 'rb').read()


def va2off(vaddr):
    for va, mem, fsz, fo in loads:
        if va <= vaddr < va + mem:
            return fo + (vaddr - va)
    return None


def rd_str(va, maxlen=120):
    off = va2off(va)
    if off is None:
        return None
    end = data.find(b'\x00', off, off + maxlen)
    if end < 0:
        end = off + maxlen
    try:
        return data[off:end].decode('utf-8')
    except Exception:
        return data[off:end].hex()


import capstone
md = capstone.Cs(capstone.CS_ARCH_ARM64, capstone.CS_MODE_LITTLE_ENDIAN)
md.detail = True


def func_of(addr, entries):
    i = np.searchsorted(entries, addr, 'right') - 1
    return int(entries[i]) if i >= 0 else None


def scan_strrefs(func_start, str_vas):
    """disassemble function, resolve adrp(+add/ldr) to exact vaddr; report
    refs landing on str_vas."""
    off = va2off(func_start)
    code = data[off:off + 0x4000]
    hits = []
    adrp_reg = {}
    for ins in md.disasm(code, func_start):
        if ins.mnemonic == 'adrp':
            ops = ins.operands
            tgt_txt = ins.op_str.split(', ')[1].lstrip('#')
            adrp_reg[ops[0].reg] = (int(tgt_txt, 16), ins.address)
        elif ins.mnemonic == 'add' and len(ins.operands) == 3:
            ops = ins.operands
            if ops[1].reg in adrp_reg and ops[2].type == 2:  # imm
                page, site = adrp_reg[ops[1].reg]
                va = page + ops[2].imm
                if va in str_vas:
                    hits.append((ins.address, va))
        elif ins.mnemonic in ('ldr', 'ldrb', 'ldrh') and len(ins.operands) == 2:
            ops = ins.operands
            # ldr xN, [xM] after adrp xM, page  -> GOT-style ref, skip exact
        if ins.mnemonic in ('ret',):
            pass
    return hits


entries = np.load(f'{AN}/fgraph2.npz', allow_pickle=True)['entries']
entries.sort()
print(f'{len(entries)} function entries')

strs = json.load(open(f'{AN}/replay_strings.json'))
# build exact string-address set: only string STARTS (the filename table)
str_vas = set()
for pat, lst in strs.items():
    for va, txt in lst:
        str_vas.add(va)

# candidate sites from replay_str_refs.json
refs = json.load(open(f'{AN}/replay_str_refs.json'))
site2str = {}
for va, ms in refs.items():
    for site, tgt, kind in ms:
        site2str.setdefault(int(site, 16), []).append((int(va, 16), kind))

# for each site: find function, then precise-resolve refs in that function
seen_funcs = {}
for site in sorted(site2str):
    fs = func_of(site, entries)
    if fs is None:
        continue
    if fs in seen_funcs:
        continue
    hits = scan_strrefs(fs, str_vas)
    if hits:
        seen_funcs[fs] = hits
        print(f'\nfunc {fs:#x}: exact string refs:')
        for a, va in hits[:20]:
            print(f'   {a:#x} -> {va:#x} {rd_str(va)!r}')

json.dump({hex(k): [[hex(a), hex(v)] for a, v in vv] for k, vv in seen_funcs.items()},
          open(f'{AN}/replay_str_funcs.json', 'w'), indent=1)
print('\nJSON -> replay_str_funcs.json')
