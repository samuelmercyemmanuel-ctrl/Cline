#!/usr/bin/env python3
"""M10b: block-path trace of the cmd-4 gate after REAL inner ctor."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22
from m10_realctor import A_INNER_CTOR

GATE_LO = 0x6a0195c
GATE_HI = 0x6a02000


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    path = []

    def blk(uc, address, size, ud):
        off = address - core.base
        if GATE_LO <= off < GATE_HI:
            path.append(off)

    core.uc.hook_add(UC_HOOK_BLOCK, blk)

    faults = []

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        faults.append({'type': int(type_), 'addr': address,
                       'pc': pc - core.base})
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=120,
                  max_insns=100_000_000)
    print('inner ctor err:', r['error'])
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(5):
        before, after, err, pc = world.step()
        replug()
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err}')

    print('--- tracing step 5 (the 22-slot fill) ---')
    path.clear()
    faults.clear()
    before, after, err, pc = world.step()
    replug()
    print(f'step: cmd {before:#x} -> {after:#x} err={err}')
    if faults:
        print('faults:', faults)
    seq = []
    for b in path:
        if not seq or seq[-1] != b:
            seq.append(b)
    line = [f'{b:#x}' for b in seq]
    print('gate path (%d):' % len(seq))
    for i in range(0, len(line), 8):
        print('  ' + ' '.join(line[i:i + 8]))


if __name__ == '__main__':
    main()
