#!/usr/bin/env python3
"""M9k: dump live vtables (reloc-applied) for the hub family."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from uc_loader2 import EFootballCoreV2

VTS = {0x9787258: 'teamdata_A(3958)', 0x9787310: 'teamdata_B(39f8)',
       0x97873c8: 'teamdata_C(3a98)', 0x978cf60: 'listener(inner)',
       0x978bf38: 'listener_alt', 0x97a57e8: 'teamdb_obj',
       0x97a58b0: 'teamdb_obj2'}


def main():
    core = EFootballCoreV2(verbose=False)
    for vt, name in VTS.items():
        print(f'vtable {vt:#x} ({name}):')
        for off in range(0, 0x40, 8):
            v = core.safe_read_u64(core.base + vt + off)
            print(f'  +0x{off:02x}: {v - core.base:#x}' if v else
                  f'  +0x{off:02x}: 0')


if __name__ == '__main__':
    main()
