#!/usr/bin/env python3
"""Mine libUE4.so dynamic symbol table + dynamic tags + build string index for xref discovery.

Stage A: dump ALL dynamic tags (detect packed relocations: DT_ANDROID_RELA / DT_RELR).
Stage B: mine 34k dynsym exports for gameplay-relevant names.
Stage C: locate .rodata source-path strings (MatchOnline*.cpp, ProcessMatchMain.cpp, etc.)
         and build a string->vaddr index for later adrp/add xref scanning.

Output: /home/z/my-project/apk_lab/analysis/symbol_mine.json
"""
import json, os, re, sys
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
OUT = '/home/z/my-project/apk_lab/analysis/symbol_mine.json'
os.makedirs(os.path.dirname(OUT), exist_ok=True)

f = open(SO, 'rb')
elf = ELFFile(f)

# ---------- Stage A: all dynamic tags ----------
tags = {}
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_DYNAMIC':
        for tag in seg.iter_tags():
            k = str(tag.entry.d_tag)
            v = tag.entry.d_val
            if k in tags:
                if not isinstance(tags[k], list):
                    tags[k] = [tags[k]]
                tags[k].append(v)
            else:
                tags[k] = v
# map tag names for readability
TAGNAMES = {0: 'DT_NULL', 1: 'DT_NEEDED', 5: 'DT_STRTAB', 6: 'DT_SYMTAB', 7: 'DT_RELA',
            8: 'DT_RELASZ', 9: 'DT_RELAENT', 23: 'DT_JMPREL', 2: 'DT_PLTRELSZ', 20: 'DT_PLTREL',
            24: 'DT_BIND_NOW', 0x6ffffef5: 'DT_GNU_HASH', 0x6ffffffb: 'DT_GNU_RELRO (flags?)',
            0x6ffffff9: 'DT_RELACOUNT', 0x6fffe000: 'DT_GNU_HASH-alt',
            0x6fffffe6: 'DT_GNU_VERSYM', 0x6ffffffe: 'DT_GNU_VERNEED',
            0x6ffffff0: 'DT_VERSYM', 0x6ffffffc: 'DT_VERDEF',
            0x6000000d: 'DT_ANDROID_REL-alt', 0x6000000f: 'DT_ANDROID_RELA-alt',
            0x6fffd558: 'DT_ANDROID_RELR (experimental)'}
print('=== DYNAMIC TAGS ===')
for k, v in sorted(tags.items()):
    nm = k
    try:
        iv = int(k) if not k.startswith('DT_') else None
    except Exception:
        iv = None
    print(f'  {nm} = {v}')

# ---------- Stage B: dynsym mining ----------
dynsym = elf.get_section_by_name('.dynsym')
syms = []
for s in dynsym.iter_symbols():
    if s.name and s['st_value']:
        syms.append((s.name, s['st_value'], s['st_size'], s['st_info']['type'], s['st_info']['bind']))
print(f'\n=== DYNSYM: {len(syms)} defined, non-zero symbols ===')

KEYWORDS = ['Match', 'Ball', 'Physics', 'Online', 'Replay', 'Command', 'Controller', 'Simulation',
            'Locomot', 'Tackle', 'Pass', 'Shoot', 'Kick', 'Dribble', 'Player', 'Team', 'Random',
            'Rand', 'Step', 'Update', 'Tick']
hits = {}
for name, val, size, typ, bind in syms:
    for kw in KEYWORDS:
        if kw in name:
            hits.setdefault(kw, []).append((name, val, size))
for kw in KEYWORDS:
    if kw in hits:
        print(f'  [{kw}] {len(hits[kw])} symbols')

# focus: the most gameplay-looking names
FOCUS = re.compile(r'(MatchSim|MatchOnline|MatchMain|MatchUpdate|Match::|BallPhys|BallState|'
                   r'MoveBall|UpdateBall|StepBall|MatchCommand|OnlineCommand|MatchData|'
                   r'GameSim|Simulation|Timestep|DeltaTime|SubStep)', re.I)
focus = [(n, v, s) for n, v, s, t, b in syms if FOCUS.search(n)]
print(f'\n=== FOCUS SYMBOLS ({len(focus)}) ===')
for n, v, s in sorted(focus, key=lambda x: x[1])[:120]:
    print(f'  {v:>#12x} size={s:<8} {n}')

# ---------- Stage C: source-path strings ----------
rodata = elf.get_section_by_name('.rodata')
if rodata is None:
    for s in elf.iter_sections():
        if s.name in ('.text',):  # strings sometimes live in .text const pools
            pass
print(f"\n=== .rodata: addr {hex(rodata['sh_addr'])} size {rodata['sh_size']:,} ===")
data = rodata.data()
base = rodata['sh_addr']

TARGET_STRINGS = [b'MatchOnlineCommandController.cpp', b'MatchOnlineDataSync.cpp',
                  b'MatchOnlineNegotiator.cpp', b'MatchOnlineWatchDog.cpp',
                  b'MatchOnlineSession.cpp', b'ProcessMatchMain.cpp',
                  b'RP_RAND_SEED', b'MatchCommand', b'.rep', b'.trep', b'ball.o',
                  b'MatchSimulation', b'BallPhysics']
str_hits = {}
for t in TARGET_STRINGS:
    idx = 0
    found = []
    while True:
        i = data.find(t, idx)
        if i < 0:
            break
        found.append(base + i)
        idx = i + 1
        if len(found) > 40:
            break
    if found:
        str_hits[t.decode()] = [hex(x) for x in found]
        print(f'  STRING {t.decode()!r}: {len(found)} hits, e.g. {hex(found[0])}')

# general scan: all *.cpp paths containing Match
cpp_paths = set()
for m in re.finditer(rb'[A-Za-z0-9_/]{2,60}\.cpp', data):
    nm = m.group(0).decode()
    if re.search(r'Match|Ball|Online|Command|Replay|Player|Team', nm, re.I):
        cpp_paths.add((nm, base + m.start()))
print(f'  gameplay-related .cpp path strings: {len(cpp_paths)}')

# save
json.dump({'dynamic_tags': {str(k): str(v) for k, v in tags.items()},
           'dynsym_total': len(syms),
           'focus_symbols': [(n, hex(v), s) for n, v, s in focus],
           'keyword_hits': {kw: len(hits.get(kw, [])) for kw in KEYWORDS},
           'string_hits': str_hits,
           'cpp_paths': [(n, hex(a)) for n, a in sorted(cpp_paths, key=lambda x: x[1])][:400]},
          open(OUT, 'w'), indent=1)
print('JSON ->', OUT)
