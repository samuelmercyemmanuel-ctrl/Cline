#!/usr/bin/env python3
"""M9f: with controller replug, verify slot fill + ctor events + faults.

The cmd-0 handler releases ctrl3868 (0x68b69a8); the cmd-4 gate needs it.
Harness-side fix: replug [inner+0x3868+0x40] and [inner+0x3818+0x40]
before every dispatcher call. Then drive as far as possible.
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22, A_CONSTRUCTION, A_PLAYER_CTOR

OUT = '/home/z/my-project/apk_lab/analysis/m9f_drive.json'

TRACE_FNS = {
    0x6a0195c: 'gate',
    0x70c1c00: 'db_query',
    0x70c37f0: 'teamdb_ctor',
    0x6993afc: 'player_ctor',
    0x6a02000: 'construction_driver',
    0x6a027f8: 'player_ctor2',
    0x68cb5c4: 'teamdata_get',
    0x71e1ea8: 'extra_ctor_C0',
    0x6fbc05c: 'extra_ctor_E0',
    0x6fa6f5c: 'extra_ctor_D8',
}


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    events = []

    def hook_fn(addr, name):
        def h(uc, address, size, ud):
            events.append({'fn': name,
                           'x0': hex(uc.reg_read(UC_ARM64_REG_X0)),
                           'x1': hex(uc.reg_read(UC_ARM64_REG_X1)),
                           'x2': hex(uc.reg_read(UC_ARM64_REG_X2)),
                           'cmd': core.safe_read_u32(inner + 8)})
        return h

    for addr, name in TRACE_FNS.items():
        core.uc.hook_add(UC_HOOK_CODE, hook_fn(addr, name),
                         begin=core.base + addr, end=core.base + addr + 4)

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        events.append({'fn': 'FAULT', 'type': int(type_),
                       'addr': hex(address), 'pc': hex(pc - core.base),
                       'cmd': core.safe_read_u32(inner + 8)})
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    hist = []
    from collections import Counter
    for i in range(30):
        events.append({'fn': 'STEP', 'x0': i, 'x1': 0, 'x2': 0, 'cmd': -1})
        before, after, err, pc = world.step(timeout_s=120)
        replug()
        n = sum(1 for p in slots22(core, inner) if p)
        extras = [core.safe_read_u64(inner + 0xC0 + j * 8) for j in range(4)]
        n_ex = sum(1 for e in extras if e)
        hist.append({'step': i, 'cmd': before, 'next': after, 'err': err,
                     'slots22': n, 'extras': n_ex})
        print(f'step {i:2d}: cmd {before:#04x} -> {after:#04x} err={err} '
              f'slots={n}/22 extras={n_ex}/4')
        if err and 'PROT' in str(err) or (err and 'UNMAPPED' in str(err)):
            # dump the last fault details
            fl = [e for e in events if e['fn'] == 'FAULT']
            if fl:
                print(f'    last fault: {fl[-1]}')

    c = Counter(e['fn'] for e in events)
    print('--- call counts ---')
    for k, v in c.most_common():
        print(f'  {k:20s} {v}')
    ctor_events = [e for e in events if e['fn'] == 'player_ctor']
    print(f'player_ctor (0x6993afc) events: {len(ctor_events)}')
    for e in ctor_events[:26]:
        print('   ', e)

    json.dump({'history': hist, 'counts': dict(c),
               'events': events[-500:]}, open(OUT, 'w'),
              indent=1, default=str)
    print('JSON ->', OUT)


if __name__ == '__main__':
    main()
