#!/usr/bin/env python3
"""M10k: catch the memcpy that overwrites the queue tail."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld
from m10_realctor import A_INNER_CTOR

OWNER = 0x90000a8c600


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner

    mc = core.addr_of_stub.get('memcpy')
    mm = core.addr_of_stub.get('memmove')
    print(f'memcpy stub = {mc:#x}, memmove stub = {mm:#x}')

    def on_copy(uc, address, size, ud):
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        if x0 + x2 > OWNER + 0x100 and x0 < OWNER + 0x140:
            lr = uc.reg_read(UC_ARM64_REG_LR)
            src = core.safe_read(uc.reg_read(UC_ARM64_REG_X1), min(x2, 32))
            print(f'COPY dst={x0:#x} len={x2} lr={lr - core.base:#x} '
                  f'src[:32]={src[:32].hex()}')

    for a in (mc, mm):
        if a:
            core.uc.hook_add(UC_HOOK_CODE, on_copy,
                             begin=a, end=a + 4)

    def mem_err(uc, type_, address, size, value, ud):
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    core.uc.mem_write(core.base + 0x68a0f30, struct.pack('<I', 0xD503201F))
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=300,
                  max_insns=1_000_000_000)
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(7):
        before, after, err, pc = world.step(timeout_s=240)
        replug()


if __name__ == '__main__':
    main()
