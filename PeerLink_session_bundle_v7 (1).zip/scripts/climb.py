#!/usr/bin/env python3
"""Climb the caller tree toward the match tick + fixed string-anchor xrefs.

1. Compute TRUE string starts (walk back to preceding NUL) for anchor strings,
   then find adrp+add refs to those starts.
2. Reverse-caller BFS from key seeds upward (bounded), with function-size
   estimates (gap to next BL-target entry), to locate the top-level match update.

Output: apk_lab/analysis/climb.json + console tree.
"""
import json, os, sys
import numpy as np
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        loads.append(dict(vaddr=seg['p_vaddr'], memsz=seg['p_memsz'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], perms=('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')))

def v2o(v):
    for l in loads:
        if l['vaddr'] <= v < l['vaddr'] + l['filesz']:
            return v - l['vaddr'] + l['offset']
    return None

def o2v(o):
    for l in loads:
        if l['offset'] <= o < l['offset'] + l['filesz']:
            return o - l['offset'] + l['vaddr']
    return None

# ---- string starts ----
sym = json.load(open(f'{AN}/symbol_mine.json'))
sm = json.load(open(f'{AN}/anchors.json'))
fdata = open(SO, 'rb').read()

def string_start(vaddr):
    o = v2o(vaddr)
    if o is None:
        return vaddr
    # walk back over printable path chars to NUL
    i = o
    while i > 0 and fdata[i - 1] not in (0,) and 0x20 <= fdata[i - 1] < 0x7f:
        i -= 1
    return o2v(i)

# ---- maps ----
bl = np.load(f'{AN}/bl_map.npz')
bl_site, bl_target = bl['bl_site'], bl['bl_target']
order = np.argsort(bl_target)
blt_sorted, bls_sorted = bl_target[order], bl_site[order]
all_entries = np.unique(bl_target)
entries_sorted = np.sort(all_entries)

def callers_of(target):
    i = np.searchsorted(blt_sorted, target, 'left')
    j = np.searchsorted(blt_sorted, target, 'right')
    return bls_sorted[i:j].tolist()

ad = np.load(f'{AN}/adrp_map.npz')
ref_target, ref_site, ref_kind = ad['ref_target'], ad['ref_site'], ad['ref_kind']
aorder = np.argsort(ref_target)
rt, rs, rk = ref_target[aorder], ref_site[aorder], ref_kind[aorder]

def refs_to(target):
    i = np.searchsorted(rt, target, 'left')
    j = np.searchsorted(rt, target, 'right')
    return list(zip(rs[i:j].tolist(), rk[i:j].tolist()))

# function size estimate: entry -> next entry (upper bound) or 0x1000 default
def fsize(entry):
    i = np.searchsorted(entries_sorted, entry, 'right')
    nxt = entries_sorted[i] if i < len(entries_sorted) else TEXT_VA + TEXT_SZ
    return min(nxt - entry, 0x20000)

TEXT_VA, TEXT_SZ = loads[1]['vaddr'], loads[1]['filesz']

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)

def func_start(site, back=0x20000):
    o = v2o(site)
    lo = max(loads[1]['offset'], o - back)
    code = fdata[lo:o + 4]
    va = lo - loads[1]['offset'] + TEXT_VA
    insns = list(md.disasm(code, va))
    best = None
    for i, ins in enumerate(insns[:-1]):
        m, ops = ins.mnemonic, ins.op_str
        pro = (m == 'stp' and 'x29' in ops and 'x30' in ops) or \
              (m == 'sub' and ops.startswith('sp, sp, #')) or (m == 'pacibsp') or \
              (m == 'stp' and ops.startswith('x28'))
        if pro:
            prev = insns[i - 1] if i > 0 else None
            if prev is None or prev.mnemonic in ('ret', 'nop', 'b', 'brk', 'br', 'blr') or prev.mnemonic.startswith('b.'):
                best = ins.address
    return best

# ================= 1. fixed string anchors =================
print('=== FIXED STRING ANCHOR XREFS ===')
anchor_xrefs = {}
for name, addrs in sym['string_hits'].items():
    a = int(addrs[0], 16)
    s = string_start(a)
    o = v2o(s)
    fullstr = fdata[o:fdata.find(b'\0', o)].decode('utf-8', 'replace') if o else '?'
    rr = refs_to(s)
    funcs = sorted(set(func_start(site) for site, kind in rr if func_start(site)))
    anchor_xrefs[name] = {'hit': hex(a), 'start': hex(s), 'string': fullstr,
                          'n_refs': len(rr), 'funcs': [hex(x) for x in funcs]}
    print(f'  {name!r}: start={hex(s)} refs={len(rr)} funcs={[hex(x) for x in funcs[:10]]}')
    print(f'      full: {fullstr[:120]}')

# ================= 2. upward climb =================
def climb(seed, max_levels=6, max_fan=400):
    """Level-by-level caller expansion. Returns {func: {'callers': [...], 'size': n}}."""
    tree = {}
    frontier = [seed]
    seen = {seed}
    for lvl in range(max_levels):
        nxt = []
        for fn in frontier:
            cs = callers_of(fn)
            fs = []
            for site in cs:
                st = func_start(site)
                if st and st not in seen:
                    seen.add(st)
                    fs.append(st)
            tree[fn] = {'callers': [hex(x) for x in fs], 'size': fsize(fn), 'n_sites': len(cs)}
            for st in fs:
                if st not in tree and len(callers_of(st)) <= max_fan:
                    nxt.append(st)
                elif st not in tree:
                    tree[st] = {'callers': ['<fan-in too large>'], 'size': fsize(st),
                                'n_sites': len(callers_of(st))}
        if not nxt:
            break
        frontier = nxt
    return tree

SEEDS = {
    'ball_chain_top_caller': 0x6e938a0,     # caller of 0x6ea1e90
    'ball_kernel_direct': 0x6e92bf0,        # direct kernel caller family
    'player_replay_serializer': 0x6f45bc4,  # calls player replay writer
    'ball_replay_serializer': 0x6e94aa4,    # calls ball replay writer
    'rp_rand_seed_user': 0x7ceafc4,         # references RP_RAND_SEED
    'match_command_user': 0x7bff91c,        # references MatchCommand string
}
trees = {}
for name, seed in SEEDS.items():
    t = climb(seed, max_levels=4)
    trees[name] = {'seed': hex(seed), 'tree': {hex(k): v for k, v in t.items()}}
    print(f'\n=== CLIMB: {name} seed={hex(seed)} (size~{fsize(seed):,}) ===')
    for fn, info in sorted(t.items(), key=lambda kv: kv[0]):
        print(f'  {fn} size~{info["size"]:,} sites={info["n_sites"]} <- callers {info["callers"][:8]}')

json.dump({'anchor_xrefs': anchor_xrefs, 'climbs': trees}, open(f'{AN}/climb.json', 'w'), indent=1)
print('\nJSON ->', f'{AN}/climb.json')
