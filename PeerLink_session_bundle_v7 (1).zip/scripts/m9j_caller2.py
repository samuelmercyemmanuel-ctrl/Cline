#!/usr/bin/env python3
"""M9j: who calls teamdata_get(0x68cb5c4) with inner+0x3748 during cmd 5."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld

SUBS = {0x6a04b04: 'sub1_6a04b04', 0x6a04b0c: 'sub2_6a04b0c',
        0x6a04c54: 'sub3_6a04c54', 0x6a0527c: 'sub4_6a0527c',
        0x6a05358: 'sub5_6a05358', 0x6a055c4: 'sub6_6a055c4'}


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    state = {'sub': None}

    def sub_hook(uc, address, size, ud):
        state['sub'] = address - core.base

    for a in SUBS:
        core.uc.hook_add(UC_HOOK_CODE, sub_hook,
                         begin=core.base + a, end=core.base + a + 4)

    def tdg(uc, address, size, ud):
        lr = uc.reg_read(UC_ARM64_REG_LR)
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        off = x0 - inner
        if 0 <= off < 0x10000 and off != 0x39f8 and off != 0x3a48:
            print(f'  teamdata_get(x0=inner+{off:#x}) lr={lr - core.base:#x} '
                  f'sub={SUBS.get(state["sub"], state["sub"])}')

    core.uc.hook_add(UC_HOOK_CODE, tdg,
                     begin=core.base + 0x68cb5c4,
                     end=core.base + 0x68cb5c4 + 4)

    def mem_err(uc, type_, address, size, value, ud):
        print(f'  FAULT type={type_} addr={address:#x} '
              f'sub={SUBS.get(state["sub"], state["sub"])}')
        return False

    core.uc.hook_add(UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(6):
        before, after, err, pc = world.step()
        replug()
    print('--- cmd-5 trace ---')
    before, after, err, pc = world.step()
    replug()
    print(f'cmd {before:#x} -> {after:#x} err={err}')


if __name__ == '__main__':
    main()
