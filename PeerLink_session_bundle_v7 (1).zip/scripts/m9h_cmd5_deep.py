#!/usr/bin/env python3
"""M9h: cmd-5 fault deep dive - which sub-call, which hub, which vtable."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld

SUBS = [0x6a04b04, 0x6a04b0c, 0x6a04c54, 0x6a0527c, 0x6a05358,
        0x6a055c4, 0x6a05618, 0x68c84b8]


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    current = [None]

    def sub_hook(uc, address, size, ud):
        current[0] = address - core.base

    for a in SUBS:
        core.uc.hook_add(UC_HOOK_CODE, sub_hook,
                         begin=core.base + a, end=core.base + a + 4)

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        x19 = uc.reg_read(UC_ARM64_REG_X19)
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        x30 = uc.reg_read(UC_ARM64_REG_X30)
        info = {'type': int(type_), 'addr': address,
                'pc': pc - core.base, 'x19': x19, 'x0': x0,
                'x30': x30, 'last_sub': current[0]}
        # try reading x19's vtable
        try:
            vt = core.safe_read_u64(x19)
            info['vt'] = vt
            slots = []
            for off in range(0, 0x40, 8):
                slots.append(hex(core.safe_read_u64(vt + off)))
            info['vt_slots'] = slots
        except Exception as e:
            info['vt_err'] = str(e)
        print('FAULT DETAIL:', info)
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(6):
        before, after, err, pc = world.step()
        replug()
    print('--- cmd-5 fault deep dive ---')
    current[0] = None
    before, after, err, pc = world.step()
    replug()
    print(f'cmd {before:#x} -> {after:#x} err={err}')


if __name__ == '__main__':
    main()
