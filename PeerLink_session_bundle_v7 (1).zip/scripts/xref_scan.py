#!/usr/bin/env python3
"""Whole-binary xref scanner for eFootball libUE4.so (AArch64).

Vectorized (numpy) scans over the executable segment:
  1. BL call map          -> caller_site -> callee_entry (and reverse)
  2. ADRP+ADD / ADRP+LDR  -> code site -> materialized data/string address
  3. PLT stub decoding    -> stub_vaddr -> GOT slot -> .rela.plt symbol name
  4. Anchor xrefs         -> who references MatchOnline*.cpp / ProcessMatchMain.cpp /
                             RP_RAND_SEED / replay-writer / ball-chain functions
  5. Reverse caller chains for key functions (climb toward the match tick)

Outputs under apk_lab/analysis/:
  bl_map.npz      (bl_site, bl_target arrays)
  adrp_map.npz    (ref_site, ref_target, ref_kind arrays)
  plt_map.json    (stub -> {sym, got, internal})
  anchors.json    (anchor -> xref sites w/ function-start estimates)
"""
import json, os, struct, sys
import numpy as np
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
os.makedirs(AN, exist_ok=True)

f = open(SO, 'rb')
elf = ELFFile(f)

# ---------------- locate segments ----------------
text = None
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        perms = ('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')
        entry = dict(vaddr=seg['p_vaddr'], memsz=seg['p_memsz'], filesz=seg['p_filesz'],
                     offset=seg['p_offset'], perms=perms)
        loads.append(entry)
        if 'x' in perms:
            text = entry
assert text, 'no executable segment'
TEXT_VA, TEXT_SZ = text['vaddr'], text['filesz']
f.seek(text['offset'])
tbytes = f.read(TEXT_SZ)
W = np.frombuffer(tbytes, dtype='<u4').copy()
N = len(W)
print(f'text: vaddr={hex(TEXT_VA)} size={TEXT_SZ:,} insns={N:,}')

# ---------------- 1. BL map ----------------
bl_mask = (W & 0xFC000000) == 0x94000000
bl_idx = np.nonzero(bl_mask)[0]
imm26 = (W[bl_idx] & 0x03FFFFFF).astype(np.int64)
imm26 = np.where(imm26 >= (1 << 25), imm26 - (1 << 26), imm26)
bl_site = bl_idx.astype(np.uint64) * 4 + TEXT_VA
bl_target = (bl_idx.astype(np.int64) * 4 + TEXT_VA + imm26 * 4).astype(np.int64)
valid = (bl_target >= TEXT_VA) & (bl_target < TEXT_VA + TEXT_SZ)
bl_site, bl_target = bl_site[valid], bl_target[valid]
print(f'BL calls: {len(bl_site):,}')
np.savez_compressed(f'{AN}/bl_map.npz', bl_site=bl_site, bl_target=bl_target)

# reverse map quick-access helper (sorted by target)
order = np.argsort(bl_target)
blt_sorted = bl_target[order]
bls_sorted = bl_site[order]

def callers_of(target):
    i = np.searchsorted(blt_sorted, target, 'left')
    j = np.searchsorted(blt_sorted, target, 'right')
    return bls_sorted[i:j]

def callees_of(site_lo, site_hi):
    m = (bl_site >= site_lo) & (bl_site < site_hi)
    return bl_target[m]

# ---------------- 2. ADRP + ADD/LDR reference map ----------------
adrp_mask = (W & 0x9F000000) == 0x90000000
adrp_idx = np.nonzero(adrp_mask)[0]
print(f'ADRPs: {len(adrp_idx):,}')
w_a = W[adrp_idx].astype(np.int64)
immlo = (w_a >> 29) & 3
immhi = (w_a >> 5) & 0x7FFFF
imm21 = (immhi << 2) | immlo
imm21 = np.where(imm21 >= (1 << 20), imm21 - (1 << 21), imm21)
adrp_page = ((adrp_idx.astype(np.int64) * 4 + TEXT_VA) & ~0xFFF) + (imm21 << 12)
adrp_rd = w_a & 0x1F

ref_site, ref_target, ref_kind = [], [], []
# scan following window for ADD imm / LDR imm with matching register
MAXWIN = 8
for d in range(1, MAXWIN + 1):
    nxt = adrp_idx + d
    ok = nxt < N
    ai = adrp_idx[ok]
    ni = nxt[ok]
    wn = W[ni].astype(np.int64)
    # ADD (imm, 64-bit): sf=1 op=0 S=0 100010 sh imm12 Rn Rd
    is_add = (wn & 0x7F000000) == 0x11000000
    rn_add = (wn >> 5) & 0x1F
    rd_adrp = adrp_rd[ok]
    match_add = is_add & (rn_add == rd_adrp) & (rd_adrp != 31)
    if match_add.any():
        sh = ((wn >> 22) & 1)[match_add]
        imm12 = ((wn >> 10) & 0xFFF)[match_add]
        off = np.where(sh == 1, imm12 << 12, imm12)
        tgt = (adrp_page[ok][match_add] + off)
        ref_site.append((ni[match_add] * 4 + TEXT_VA))
        ref_target.append(tgt)
        ref_kind.append(np.full(int(match_add.sum()), ord('a')))
    # LDR (imm, unsigned offset, 64-bit) Xt, [Xn, imm]
    is_ldr64 = (wn & 0xFFC00000) == 0xF9400000
    rn_ldr = (wn >> 5) & 0x1F
    match_ldr = is_ldr64 & (rn_ldr == rd_adrp) & (rd_adrp != 31)
    if match_ldr.any():
        imm12 = ((wn >> 10) & 0xFFF)[match_ldr]
        tgt = adrp_page[ok][match_ldr] + imm12 * 8
        ref_site.append(ni[match_ldr] * 4 + TEXT_VA)
        ref_target.append(tgt)
        ref_kind.append(np.full(int(match_ldr.sum()), ord('l')))

ref_site = np.concatenate(ref_site).astype(np.uint64)
ref_target = np.concatenate(ref_target).astype(np.int64)
ref_kind = np.concatenate(ref_kind)
print(f'ADR+ADD/LDR refs: {len(ref_site):,}')
np.savez_compressed(f'{AN}/adrp_map.npz', ref_site=ref_site, ref_target=ref_target, ref_kind=ref_kind)

ref_t_sorted = ref_target[np.argsort(ref_target)]
ref_s_sorted = ref_site[np.argsort(ref_target)]
ref_k_sorted = ref_kind[np.argsort(ref_target)]

def refs_to(target, tol=0):
    i = np.searchsorted(ref_t_sorted, target - tol, 'left')
    j = np.searchsorted(ref_t_sorted, target + tol, 'right')
    return list(zip(ref_s_sorted[i:j].tolist(), ref_k_sorted[i:j].tolist()))

# ---------------- 3. PLT stub decoding ----------------
plt_sec = elf.get_section_by_name('.plt')
plt_map = {}
if plt_sec is not None:
    # .rela.plt: GOT slot -> symbol
    rela = elf.get_section_by_name('.rela.plt')
    got2sym = {}
    if rela is not None:
        linksec = elf.get_section(rela['sh_link']) if rela['sh_link'] else dynsym
        for r in rela.iter_relocations():
            si = r['r_info_sym']
            sym = linksec.get_symbol(si) if linksec is not None else None
            got2sym[r['r_offset']] = (sym.name if sym and sym.name else f'sym{si}', si)
    dynsym = elf.get_section_by_name('.dynsym')
    pdata = plt_sec.data()
    pbase = plt_sec['sh_addr']
    md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
    stubs = {}
    for off in range(0, len(pdata) - 16, 16):
        insns = list(md.disasm(pdata[off:off + 16], pbase + off))
        if len(insns) >= 4 and insns[0].mnemonic == 'adrp' and insns[1].mnemonic == 'ldr' \
           and insns[3].mnemonic in ('br', 'blr'):
            # adrp x16, page ; ldr x17, [x16, #off] ; add ; br x17
            try:
                page = int(insns[0].op_str.split('#')[1], 0)
                reg_off = insns[1].op_str
                imm = int(reg_off.split('#')[-1].rstrip(']'), 0)
                got = page + imm
                name, si = got2sym.get(got, (f'got_{hex(got)}', -1))
                internal = False
                if si >= 0 and dynsym is not None:
                    s = dynsym.get_symbol(si)
                    internal = bool(s['st_value'])
                stubs[pbase + off] = {'sym': name, 'got': got, 'internal': internal}
            except Exception:
                continue
    plt_map = {hex(k): v for k, v in stubs.items()}
    json.dump(plt_map, open(f'{AN}/plt_map.json', 'w'), indent=1)
    internal_ct = sum(1 for v in stubs.values() if v['internal'])
    print(f'PLT stubs decoded: {len(stubs)} (internal-resolvable: {internal_ct})')

# ---------------- 4. function-start estimator ----------------
md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
fdata = open(SO, 'rb').read()

def v2o(v):
    for l in loads:
        if l['vaddr'] <= v < l['vaddr'] + l['filesz']:
            return v - l['vaddr'] + l['offset']
    return None

def func_start(site, back=0x10000):
    """Walk backward to find a plausible function entry."""
    o = v2o(site)
    if o is None:
        return None
    lo = max(text['offset'], o - back)
    code = fdata[lo:o + 4]
    va = lo - text['offset'] + TEXT_VA
    insns = list(md.disasm(code, va))
    if not insns:
        return None
    # candidate entries: prologue-ish instructions
    best = None
    for i, ins in enumerate(insns[:-1]):
        m, ops = ins.mnemonic, ins.op_str
        pro = (m == 'stp' and 'x29' in ops and 'x30' in ops) or \
              (m == 'sub' and ops.startswith('sp, sp, #')) or \
              (m == 'pacibsp') or \
              (m == 'stp' and ops.startswith('x28'))
        if pro:
            prev = insns[i - 1] if i > 0 else None
            if prev is None or prev.mnemonic in ('ret', 'nop', 'b', 'brk', 'br', 'blr') or \
               prev.mnemonic.startswith('b.'):
                best = ins.address
    return best

# ---------------- 5. anchors + reverse chains ----------------
anchors_str = json.load(open(f'{AN}/symbol_mine.json'))['string_hits']
KEY_FUNCS = {
    'ball_chain_top': 0x6ea1e90, 'ball_chain_mid': 0x6ea20fc, 'ball_kernel': 0x6ea0958,
    'ball_state_ctor': 0x6d82418, 'timestep_provider': 0x6813eb8,
    'player_replay_writer': 0x728d7e0, 'ball_replay_writer': 0x728d930,
}
out = {'string_anchors': {}, 'key_func_callers': {}}

for name, addrs in anchors_str.items():
    a = int(addrs[0], 16)
    rr = refs_to(a)
    ent = []
    for site, kind in rr[:60]:
        fs = func_start(site)
        ent.append({'site': hex(site), 'kind': chr(kind), 'func': hex(fs) if fs else None})
    out['string_anchors'][name] = {'addr': hex(a), 'hits': len(rr), 'xrefs': ent}

for name, va in KEY_FUNCS.items():
    cs = callers_of(va)
    ent = []
    for site in cs.tolist()[:200]:
        fs = func_start(site)
        ent.append({'site': hex(site), 'func': hex(fs) if fs else None})
    out['key_func_callers'][name] = {'addr': hex(va), 'n_callers': int(len(cs)), 'callers': ent}

json.dump(out, open(f'{AN}/anchors.json', 'w'), indent=1)

print('\n=== ANCHOR XREFS ===')
for name, e in out['string_anchors'].items():
    print(f'  {name!r}: {e["hits"]} refs; funcs: {sorted(set(x["func"] for x in e["xrefs"] if x["func"]))[:8]}')
print('\n=== CALLER CHAINS ===')
for name, e in out['key_func_callers'].items():
    funcs = sorted(set(x['func'] for x in e['callers'] if x['func']))
    print(f'  {name} ({e["addr"]}, {e["n_callers"]} call sites): {len(funcs)} unique funcs')
    print(f'     {funcs[:14]}')
