#!/usr/bin/env python3
"""M9d: dump the live hub state at the moment the cmd-4 gate runs."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22

GATE = 0x6a0195c
LAZY_3868 = 0x68b694c
LAZY_3818 = 0x68b0408


def main():
    world = SetupWorld(verbose=True)
    core = world.core

    def dump(uc, address, size, ud, tag):
        inner = world.inner
        for reg, nm in ((0x3868, '3868'), (0x3818, '3818'),
                        (0x3b88, '3b88')):
            v8 = core.safe_read(inner + reg + 8, 1)[0]
            v40 = core.safe_read_u64(inner + reg + 0x40)
            v0 = core.safe_read_u64(inner + reg)
            print(f'  [{tag}] inner+{nm}: [0]={v0:#x} [8]={v8} '
                  f'[0x40]={v40:#x}')

    core.uc.hook_add(UC_HOOK_CODE,
                     lambda uc, a, s, u: dump(uc, a, s, u, 'gate_entry'),
                     begin=core.base + GATE, end=core.base + GATE + 4)
    core.uc.hook_add(UC_HOOK_CODE,
                     lambda uc, a, s, u: dump(uc, a, s, u, 'lazy3868'),
                     begin=core.base + LAZY_3868, end=core.base + LAZY_3868 + 4)
    core.uc.hook_add(UC_HOOK_CODE,
                     lambda uc, a, s, u: dump(uc, a, s, u, 'lazy3818'),
                     begin=core.base + LAZY_3818, end=core.base + LAZY_3818 + 4)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    print('--- before driving: hub state ---')
    inner = world.inner
    for reg, nm in ((0x3868, '3868'), (0x3818, '3818'), (0x3b88, '3b88')):
        v8 = core.safe_read(inner + reg + 8, 1)[0]
        v40 = core.safe_read_u64(inner + reg + 0x40)
        print(f'  inner+{nm}: [8]={v8} [0x40]={v40:#x}')
    print(f'  ctrl3868={world.ctrl3868:#x} ctrl3818={world.ctrl3818:#x}')

    for i in range(6):
        before, after, err, pc = world.step()
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err}')


if __name__ == '__main__':
    main()
