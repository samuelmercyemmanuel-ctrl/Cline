#!/usr/bin/env python3
"""Decode Android packed relocations (DT_ANDROID_RELA / APS2) — EXACT bionic algorithm.

Source of truth: bionic linker/linker_reloc_iterators.h for_all_packed_relocs():
  num_relocs = sleb; r_offset = sleb
  while idx < num_relocs:
    group_size, group_flags = sleb, sleb
    flags: 1=GROUPED_BY_INFO, 2=GROUPED_BY_OFFSET_DELTA, 4=GROUPED_BY_ADDEND, 8=HAS_ADDEND
    if flags&2: group_offset_delta = sleb
    if flags&1: r_info = sleb
    fa = flags & 12
    if fa == 12: r_addend += sleb            # group-level addend delta
    elif fa == 0: r_addend = 0
    # fa == 8: nothing at group level
    for i in range(group_size):
      if flags&2: r_offset += group_offset_delta
      else: r_offset += sleb
      if not flags&1: r_info = sleb
      if fa == 8: r_addend += sleb           # per-reloc addend delta
      emit(r_offset, r_info, r_addend)

Output: apk_lab/analysis/packed_relocs.npz (offset, sym, type, addend) + vtables.json
"""
import json, os
import numpy as np
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
os.makedirs(AN, exist_ok=True)

f = open(SO, 'rb')
elf = ELFFile(f)
rela_dyn = elf.get_section_by_name('.rela.dyn')
blob = rela_dyn.data()
assert blob[:4] == b'APS2', 'unexpected magic'

loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        loads.append(dict(vaddr=seg['p_vaddr'], memsz=seg['p_memsz'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], perms=('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')))
TEXT = [l for l in loads if 'x' in l['perms']][0]
TV, TSZ = TEXT['vaddr'], TEXT['filesz']
RW_LO, RW_HI = loads[2]['vaddr'], loads[-1]['vaddr'] + loads[-1]['memsz']
dynsym = elf.get_section_by_name('.dynsym')
NSYM = dynsym.num_symbols()

pos = 4
def sleb():
    global pos
    result = 0
    shift = 0
    while True:
        b = blob[pos]
        pos += 1
        result |= (b & 0x7f) << shift
        shift += 7
        if not (b & 0x80):
            break
    if shift < 64 and (blob[pos - 1] & 0x40):
        result -= (1 << shift)
    return result

F_INFO, F_DELTA, F_GADDEND, F_ADDEND = 1, 2, 4, 8

num_relocs = sleb()
r_offset = sleb()
r_info = 0
r_addend = 0
relocs = []
idx = 0
groups = 0
while idx < num_relocs and pos < len(blob):
    group_size = sleb()
    group_flags = sleb()
    groups += 1
    group_delta = 0
    if group_flags & F_DELTA:
        group_delta = sleb()
    if group_flags & F_INFO:
        r_info = sleb()
    fa = group_flags & (F_ADDEND | F_GADDEND)
    if fa == (F_ADDEND | F_GADDEND):
        r_addend += sleb()
    elif fa == 0:
        r_addend = 0
    for _ in range(group_size):
        if group_flags & F_DELTA:
            r_offset += group_delta
        else:
            r_offset += sleb()
        if not (group_flags & F_INFO):
            r_info = sleb()
        if fa == F_ADDEND:
            r_addend += sleb()
        relocs.append((r_offset, r_info >> 32 if r_info >= 0 else (r_info >> 32) & 0xFFFFFFFF,
                       r_info & 0xFFFFFFFF, r_addend))
    idx += group_size

print(f'header num_relocs={num_relocs:,}; decoded={len(relocs):,} in {groups:,} groups')
print(f'bytes consumed: {pos:,} / {len(blob):,}')

arr = np.array([(o, s, t, a) for o, s, t, a in relocs], dtype=np.int64)
off, sym, typ, ad = arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3]

types, counts = np.unique(typ, return_counts=True)
print('reloc types:', {int(t): int(c) for t, c in zip(types, counts)})
# type legend (aarch64): 1027=RELATIVE 1025=GLOB_DAT 1026=JUMP_SLOT 257=ABS64 1030=IRELATIVE
# 1028=TLS_TPREL 1029=TLSDESC 1024? 1029? TLS...

REL = typ == 1027
print(f'RELATIVE: {REL.sum():,}')
print(f'  targets in rw+8aligned: {((off[REL] >= RW_LO) & (off[REL] < RW_HI) & (off[REL] % 8 == 0)).sum():,}')
print(f'  addends in text: {((ad[REL] >= TV) & (ad[REL] < TV + TSZ)).sum():,}')
print(f'  sym==0: {(sym[REL] == 0).sum():,}')
mono = np.all(np.diff(off) >= 0)
print(f'offsets monotonic: {mono}')
sym_valid = ((sym[~REL] >= 0) & (sym[~REL] < NSYM)).sum() if (~REL).any() else 0
print(f'symbol relocs: {(~REL).sum():,}, valid sym idx: {sym_valid:,}')

# ---- vtables from RELATIVE relocs ----
ro = np.lexsort((ad, off))  # sort by offset
o_s, a_s = off[ro], ad[ro]
runs = []
i = 0
n = len(o_s)
while i < n:
    j = i
    while j + 1 < n and o_s[j + 1] == o_s[j] + 8 and TV <= a_s[j + 1] < TV + TSZ and TV <= a_s[j] < TV + TSZ:
        j += 1
    if j - i + 1 >= 4:
        runs.append((int(o_s[i]), j - i + 1, a_s[i:j + 1].astype(np.int64).tolist()))
    i = j + 1
print(f'vtable-like runs: {len(runs):,}')

KEY = {
    'process_match_main_ref': 0x802d9d0, 'ball_replay_serializer': 0x6e94aa4,
    'player_replay_serializer': 0x6f45bc4, 'ball_chain_top': 0x6ea1e90,
    'ball_update_entry': 0x6e938a0, 'match_cmd_ctrl_a': 0x6f53644,
    'match_cmd_ctrl_b': 0x6f54074, 'match_data_sync': 0x6f60c74,
    'ball_kernel': 0x6ea0958, 'timestep_provider': 0x6813eb8,
    'rp_rand_a': 0x7ceafc4, 'replay_file_loader': 0x727c9c4,
}
print('\n=== KEY FUNCTIONS IN VTABLES ===')
for name, fn in KEY.items():
    vts = [(hex(v), mm.index(fn)) for v, ln, mm in runs if fn in mm]
    print(f'  {name} ({fn:#x}): {vts[:6]}')

np.savez_compressed(f'{AN}/packed_relocs.npz', offset=off, sym=sym, rtype=typ, addend=ad)
json.dump([{'addr': v, 'n': ln, 'methods': mm} for v, ln, mm in runs],
          open(f'{AN}/vtables.json', 'w'))
print(f'\nNPZ -> {AN}/packed_relocs.npz ; vtables.json ({len(runs):,})')

# dump vtable containing process_match_main ref
for v, ln, mm in runs:
    if 0x802d9d0 in mm:
        print(f'\n=== vtable {v:#x} ({ln} methods) containing ProcessMatchMain TU function ===')
        for i, m in enumerate(mm):
            mark = ' <-- ProcessMatchMain TU' if m == 0x802d9d0 else ''
            print(f'  [{i:2d}] {m:#x}{mark}')
        break
