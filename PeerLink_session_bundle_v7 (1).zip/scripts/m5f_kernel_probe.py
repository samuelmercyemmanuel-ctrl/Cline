#!/usr/bin/env python3
"""M5f: instrument the kernel calls inside 0x6ea233c.

Watch 0x6ea0958 during a single pure-step call: dump args (x2 state, x3
params, s0 dt, w4 init, w5) and the state velocity before/after each.
"""
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import BallWorld, rd_state, STATE_SZ, A_KERNEL
from unicorn.arm64_const import *

REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_PURE_STEP = 0x6ea233c
DT = 1.0 / 27.0


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'quat': q, 'pos': (x / 256, y / 256, z / 256)}


def main():
    o48, o49 = rep_slot0(48), rep_slot0(49)
    p48 = o48['pos']
    v_imp = tuple((np.array(o49['pos']) - np.array(p48)) / DT)
    v0 = (v_imp[0], v_imp[1] + 9.80665 * DT, v_imp[2])

    world = BallWorld(verbose=True)
    world.construct()
    modA = world.ball
    core = world.core
    world.set_N(3)
    core.uc.mem_write(world.params, struct.pack('<f', 0.399))

    s = bytearray(STATE_SZ)
    struct.pack_into('<3f', s, 0x000, *p48)
    struct.pack_into('<3f', s, 0x00C, *v0)
    s[0x90] = 1
    s[0x91] = 6
    struct.pack_into('<4f', s, 0x098, *o48['quat'])
    struct.pack_into('<i', s, 0x08C, 8)
    core.uc.mem_write(modA + 0x158, bytes(s))
    core.write_u64(modA + 0x2F8, 0)
    core.write_u32(modA + 0x8, 0)

    kcalls = []

    def kcb(uc, _):
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        x3 = uc.reg_read(UC_ARM64_REG_X3)
        w4 = uc.reg_read(UC_ARM64_REG_X4) & 1
        w5 = uc.reg_read(UC_ARM64_REG_X5) & 0xFF
        s0 = struct.unpack('<f', struct.pack('<I',
                        uc.reg_read(UC_ARM64_REG_S0) & 0xFFFFFFFF))[0]
        st = rd_state(core, x2) if x2 else b''
        vel = struct.unpack_from('<3f', st, 0x0C) if st else (0, 0, 0)
        kcalls.append({'x2': hex(x2), 'x3': hex(x3), 's0': s0,
                       'w4': w4, 'w5': w5, 'vel_pre': vel})

    wk = core.watch(A_KERNEL, kcb, name='kmon')
    r = core.call(A_PURE_STEP, x0=modA + 0x158, x1=0, x2=0)
    core.unwatch(wk)
    print(f'pure-step call: error={r["error"]}')
    print(f'kernel calls inside: {len(kcalls)}')
    for i, kc in enumerate(kcalls):
        st = rd_state(core, int(kc['x2'], 16))
        vel_post = struct.unpack_from('<3f', st, 0x0C)
        print(f'  call {i}: x2={kc["x2"]} x3={kc["x3"]} s0={kc["s0"]:.6f} '
              f'w4={kc["w4"]} w5={kc["w5"]}')
        print(f'    vel pre ={tuple(round(v,3) for v in kc["vel_pre"])}')
        print(f'    vel post={tuple(round(v,3) for v in vel_post)}')

    st_after = rd_state(core, modA + 0x158)
    print('final pos:', struct.unpack_from('<3f', st_after, 0))
    print('final vel:', struct.unpack_from('<3f', st_after, 0x0C))


if __name__ == '__main__':
    main()
