#!/usr/bin/env python3
"""MILESTONE 1: execute the ORIGINAL eFootball ball physics kernel (0x6ea0958) headlessly.

Kernel signature (derived from chain_mid call sites):
    kernel(w0=0, w1=1, x2=state(296B, in/out), x3=params, s0=dt(1/27), w4=first_step, w5=flags)

State layout (validated vs disasm):
    +0x000 Vec3 pos, +0x00C Vec3 vel, +0x018 Vec3 rot, +0x028 timer,
    +0x090 phys-state byte, +0x091 substate, +0x094 state index (0..5, selects param rows),
    +0x098 orientation quaternion

Params (kernel-relative): airRegistNormal@0, dragMax@0x140, dragMin@0x144,
    grounder* @0x1F0-0x1FC, magnusRate@0x200, naturalRoll@0x238, nonSpin* @0x23C-0x244

Experiments:
  E1 pure drop      : y0=3.0, v=0        -> gravity + bounce measurement
  E2 horizontal shot: y0=1.0, vx=6       -> drag + bounce pattern
  E3 magnus curve   : vx=8, vy=2, spin   -> lateral deflection
Output: apk_lab/analysis/ball_poc.json + trajectory CSVs
"""
import json, math, struct, sys, os
import numpy as np
sys.path.insert(0, '/home/z/my-project/scripts')
from uc_loader import EFootballCore

AN = '/home/z/my-project/apk_lab/analysis'
OUT = f'{AN}/ball_poc.json'

KERN = 0x6ea0958
DT = 1.0 / 27.0
RADIUS = 0.1086859330534935   # native constant (ground contact height)

def build_params(core):
    p = bytearray(0x300)
    def f(off, v):
        struct.pack_into('<f', p, off, v)
    # pinned values (spec, grounder values corrected set)
    f(0x000, 1.0)      # airRegistNormal
    f(0x140, 7.5)      # dragSpeedMax
    f(0x144, 0.0)      # dragSpeedMin
    f(0x1F0, 35.0)     # grounderBoundYAdd
    f(0x1F4, 35.0)     # grounderCTan
    f(0x1F8, 35.0)     # grounderFrictionRate
    f(0x1FC, 35.0)     # grounderSpeed
    f(0x200, 0.7)      # magnusRate
    f(0x238, 10.0)     # naturalRoll
    f(0x23C, 10.0)     # nonSpinMax
    f(0x240, 0.1)      # nonSpinMin
    f(0x244, 3.0)      # nonSpinRate
    return core.alloc(len(p), bytes(p), name='params')

def build_state(core, pos, vel, rot=(0, 0, 0), state_idx=0, phys=0):
    s = bytearray(296)
    struct.pack_into('<3f', s, 0x000, *pos)
    struct.pack_into('<3f', s, 0x00C, *vel)
    struct.pack_into('<3f', s, 0x018, *rot)
    struct.pack_into('<f', s, 0x028, 0.0)
    s[0x90] = phys
    s[0x91] = 0
    struct.pack_into('<i', s, 0x094, state_idx)
    struct.pack_into('<4f', s, 0x098, 1.0, 0.0, 0.0, 0.0)   # quat identity
    return core.alloc(296, bytes(s), name='state')

def read_state(core, addr):
    b = bytes(core.uc.mem_read(addr, 296))
    pos = struct.unpack_from('<3f', b, 0x000)
    vel = struct.unpack_from('<3f', b, 0x00C)
    rot = struct.unpack_from('<3f', b, 0x018)
    timer = struct.unpack_from('<f', b, 0x028)[0]
    phys, sub = b[0x90], b[0x91]
    idx = struct.unpack_from('<i', b, 0x094)[0]
    quat = struct.unpack_from('<4f', b, 0x098)
    return dict(pos=pos, vel=vel, rot=rot, timer=timer, phys=phys, sub=sub, idx=idx, quat=quat)

def run(core, pos, vel, rot=(0, 0, 0), state_idx=0, phys=0, steps=270):
    params = build_params(core)
    state = build_state(core, pos, vel, rot, state_idx, phys)
    traj = []
    t = 0.0
    for i in range(steps):
        r = core.call(KERN, w0=0, w1=1, x2=state, x3=params, s0=DT,
                      w4=1 if i == 0 else 0, w5=0)
        fatal = [l for l in core._log if 'MEM FAULT' in l or 'INVALID' in l
                 or 'STACK GUARD' in l or 'abort' in l or 'unhandled import' in l]
        if r['error'] or fatal:
            return {'error': r, 'logs': list(core._log), 'traj': traj, 'params': params, 'state': state}
        t += DT
        st = read_state(core, state)
        st['t'] = t
        st['ret'] = r['x0']
        traj.append(st)
    return {'error': None, 'traj': traj, 'params': params, 'state': state,
            'imports': dict(core.import_calls)}

def analyze(traj, label):
    """Physics sanity: gravity fit on first airborne segment, bounce detection."""
    res = {'label': label}
    ys = np.array([s['pos'][1] for s in traj])
    vy = np.array([s['vel'][1] for s in traj])
    ts = np.array([s['t'] for s in traj])
    xs = np.array([s['pos'][0] for s in traj])
    vx = np.array([s['vel'][0] for s in traj])
    # airborne: y > radius*1.5 before first ground contact
    below = np.nonzero(ys <= RADIUS * 1.2)[0]
    first_land = int(below[0]) if len(below) else len(ys) - 1
    res['first_land_step'] = first_land
    res['first_land_y'] = float(ys[first_land]) if first_land < len(ys) else None
    # gravity fit on segment [0, first_land): y = y0 + vy0 t - 0.5 g t^2
    seg = slice(0, max(first_land, 3))
    A = np.stack([np.ones_like(ts[seg]), ts[seg], -0.5 * ts[seg] ** 2], axis=1)
    coef, *_ = np.linalg.lstsq(A, ys[seg], rcond=None)
    y0f, vy0f, gf = coef
    res['fit_y0'] = float(y0f)
    res['fit_vy0'] = float(vy0f)
    res['fit_g'] = float(gf)
    res['g_err_pct'] = abs(gf - 9.806650161743164) / 9.806650161743164 * 100.0
    # bounce: vy sign change after landing
    if first_land < len(vy) - 1 and first_land > 0:
        after = vy[first_land + 1: first_land + 8]
        res['vy_after_land'] = [float(v) for v in after[:5]]
        res['bounce'] = bool(any(v > 0 for v in after)) if len(after) else False
    # drag: vx decay while airborne
    if first_land > 4:
        res['vx_start'] = float(vx[1])
        res['vx_before_land'] = float(vx[max(first_land - 1, 0)])
    # states seen
    res['phys_states'] = sorted(set((s['phys'], s['idx']) for s in traj))
    res['max_y'] = float(ys.max())
    res['range_x'] = float(xs[-1])
    return res

if __name__ == '__main__':
    core = EFootballCore(verbose=True)
    # fabricate the global context singleton the kernel reads (bss 0xa465d88 -> G+0x5a0 chain)
    core.fabricate_global(0xa465d88, size=0x40000)
    results = {}
    
    # ---- E1: pure drop ----
    r1 = run(core, pos=(0, 3.0, 0), vel=(0, 0, 0), steps=270)
    if r1['error'] or r1.get('logs'):
        print('E1 ERROR:', r1['error'], r1.get('logs', [])[:8])
    else:
        results['E1_drop'] = analyze(r1['traj'], 'drop y0=3')
        print('\n=== E1 pure drop (y0=3.0) ===')
        for k, v in results['E1_drop'].items():
            print(f'  {k}: {v}')
        for s in r1['traj'][:8]:
            print(f"  t={s['t']:.4f} y={s['pos'][1]:.4f} vy={s['vel'][1]:.4f} phys={s['phys']} idx={s['idx']}")
    
    # ---- E2: horizontal shot ----
    r2 = run(core, pos=(0, 1.0, 0), vel=(6.0, 0, 0), steps=270)
    if r2['error'] or r2.get('logs'):
        print('E2 ERROR:', r2['error'], r2.get('logs', [])[:8])
    else:
        results['E2_shot'] = analyze(r2['traj'], 'shot vx=6')
        print('\n=== E2 horizontal shot (vx=6, y0=1) ===')
        for k, v in results['E2_shot'].items():
            print(f'  {k}: {v}')
    
    # ---- E3: magnus ----
    r3 = run(core, pos=(0, 1.0, 0), vel=(8.0, 2.0, 0), rot=(0, 0, 40.0), steps=270)
    if r3['error'] or r3.get('logs'):
        print('E3 ERROR:', r3['error'], r3.get('logs', [])[:8])
    else:
        z_before = 0.0
        z_after = r3['traj'][-1]['pos'][2] if r3['traj'] else 0
        results['E3_magnus'] = analyze(r3['traj'], 'magnus spin=40')
        results['E3_magnus']['z_end'] = float(z_after)
        print('\n=== E3 magnus (vx=8, spin z=40) ===')
        for k, v in results['E3_magnus'].items():
            print(f'  {k}: {v}')
    
    results['imports_used'] = dict(core.import_calls)
    results['E1_traj'] = [(s['t'], *s['pos'], *s['vel'], s['phys'], s['idx']) for s in r1.get('traj', [])[:300]]
    results['E2_traj'] = [(s['t'], *s['pos'], *s['vel'], s['phys'], s['idx']) for s in r2.get('traj', [])[:300]]
    results['E3_traj'] = [(s['t'], *s['pos'], *s['vel'], s['phys'], s['idx']) for s in r3.get('traj', [])[:300]]
    json.dump(results, open(OUT, 'w'), indent=1, default=float)
    print('\nJSON ->', OUT)
    print('imports used:', core.import_calls)
    print('logs:', core._log[:10])
