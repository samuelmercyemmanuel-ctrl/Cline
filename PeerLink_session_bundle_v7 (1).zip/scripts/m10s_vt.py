#!/usr/bin/env python3
"""M10s: the cmd-5 vtable-with-heap-pointer fault - find the blr site."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld
from m10_realctor import A_INNER_CTOR

INIT_FNS = [0x68a7a5c, 0x66fb250]


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner

    def mem_err(uc, type_, address, size, value, ud):
        if type_ in (UC_MEM_FETCH_UNMAPPED, UC_MEM_FETCH_PROT,
                     UC_MEM_FETCH_PROT if 'PROT' in str(type_) else 0):
            pass
        t = int(type_)
        if t in (21, 22, 23, 24):   # fetch-ish
            lr = uc.reg_read(UC_ARM64_REG_LR)
            x8 = uc.reg_read(UC_ARM64_REG_X8)
            x0 = uc.reg_read(UC_ARM64_REG_X0)
            x19 = uc.reg_read(UC_ARM64_REG_X19)
            print(f'FETCH FAULT: addr={address:#x} lr={lr:#x} '
                  f'x8={x8:#x} x0={x0:#x} x19={x19:#x}')
            if address > 0x90000000000:
                # x8 might be the vtable slot content; dump the source vt
                print(f'  (heap ptr in a fn slot)')
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    core.uc.mem_write(core.base + 0x68a0f30, struct.pack('<I', 0xD503201F))
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for fn in INIT_FNS:
        r = core.call(fn, timeout_s=120, max_insns=500_000_000)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)
    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=300,
                  max_insns=1_000_000_000)
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(9):
        before, after, err, pc = world.step(timeout_s=240)
        replug()
    print('--- step 9 fault detail ---')
    before, after, err, pc = world.step(timeout_s=240)
    replug()
    print(f'step: cmd {before:#x} -> {after:#x} err={err}')


if __name__ == '__main__':
    main()
