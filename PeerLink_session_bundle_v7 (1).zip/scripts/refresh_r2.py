#!/usr/bin/env python3
"""Re-scrape a fresh signed R2 URL for the eFootball 11.0.1 .apks from
APKCombo's old-versions page, and update scripts/r2_url.txt."""
import re
import subprocess
import sys

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36'
URL_FILE = '/home/z/my-project/scripts/r2_url.txt'

PAGES = [
    'https://apkcombo.com/jp.konami.pesam/old-versions/',
    'https://apkcombo.com/jp.konami.pesam/download/11.0.1',
    'https://apkcombo.com/not-found/jp.konami.pesam/old-versions/',
]


def curl(url, extra=None):
    cmd = ['curl', '-s', '-m', '60', '-A', UA, '-L', url]
    if extra:
        cmd += extra
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout


def main():
    html = curl(PAGES[0])
    if len(html) < 5000:
        print('old-versions page empty, trying alternates', len(html))
        for p in PAGES[1:]:
            html = curl(p)
            if len(html) >= 5000:
                break
    # find rows for 11.0.1 -> the /r2?u= link or a download link
    links = re.findall(r'href="(/r2\?u=[^"]+)"', html)
    print('found /r2 links:', len(links))
    if not links:
        # maybe direct r2 cloudflarestorage URLs
        links = re.findall(r'(https://[a-z0-9]+\.r2\.cloudflarestorage\.com[^"\']+)', html)
        print('found r2 storage links:', len(links))
        # or version rows
        rows = re.findall(r'href="([^"]*11\.0\.1[^"]*)"', html)
        print('11.0.1 rows:', rows[:5])
        sys.exit(1)
    for l in links[:3]:
        print('  ', l[:200])
    full = 'https://apkcombo.com' + links[0]
    # verify the target responds 200/206
    r = subprocess.run(['curl', '-s', '-m', '60', '-A', UA, '-L', '-r', '0-0',
                        full, '-o', '/dev/null', '-D', '-'],
                       capture_output=True, text=True)
    print('HEAD probe:')
    print(r.stdout[:500])
    open(URL_FILE, 'w').write(full)
    print('r2_url.txt updated:', full[:120])


if __name__ == '__main__':
    main()
