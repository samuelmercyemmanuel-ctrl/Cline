#!/usr/bin/env python3
"""M9b: instrument the cmd-4 gate — which functions actually run?

Hooks: 0x6a0195c (gate), 0x70c1c00 (db query), 0x70c37f0 (team-db ctor),
0x6993afc (player ctor kick), 0x6a02000 (construction driver),
0x68cb5c4 (team-data getter), 0x7220b0c / 0x724cc10 (variant bits),
0x71e1ea8 / 0x6fbc05c / 0x6fa6f5c (extra-slot ctors).
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22, A_DISPATCH

OUT = '/home/z/my-project/apk_lab/analysis/m9b_gate_trace.json'

TRACE_FNS = {
    0x6a0195c: 'gate',
    0x70c1c00: 'db_query',
    0x70c37f0: 'teamdb_ctor',
    0x70c1c50: 'teamdb_release',
    0x6993afc: 'player_ctor',
    0x6a02000: 'construction_driver',
    0x68cb5c4: 'teamdata_get',
    0x7220b0c: 'variant_bit_7220b0c',
    0x724cc10: 'variant_bit_724cc10',
    0x71e1ea8: 'extra_ctor_C0',
    0x6fbc05c: 'extra_ctor_E0',
    0x6fa6f5c: 'extra_ctor_D8',
    0x6837104: 'side_next',
    0x6837a60: 'slot_next',
    0x8b35260: 'op_new_plt',
}


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    events = []

    def hook_fn(addr, name):
        def h(uc, address, size, ud):
            x0 = uc.reg_read(UC_ARM64_REG_X0)
            x1 = uc.reg_read(UC_ARM64_REG_X1)
            x2 = uc.reg_read(UC_ARM64_REG_X2)
            events.append({'fn': name, 'pc': hex(addr), 'x0': hex(x0),
                           'x1': hex(x1), 'x2': hex(x2),
                           'cmd': core.safe_read_u32(world.inner + 8)})
        return h

    for addr, name in TRACE_FNS.items():
        core.uc.hook_add(UC_HOOK_CODE, hook_fn(addr, name),
                         begin=core.base + addr, end=core.base + addr + 4)

    # run the same bootstrap as M9
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    # drive 6 steps (matching the m9 stall record)
    core._log.clear()
    events.clear()
    hist = []
    for i in range(6):
        events.append({'fn': 'STEP', 'pc': 'step', 'x0': i, 'x1': 0,
                       'x2': 0, 'cmd': -1})
        before, after, err, pc = world.step()
        n_filled = sum(1 for p in slots22(core, world.inner) if p)
        hist.append({'step': i, 'cmd': before, 'next': after, 'err': err,
                     'slots22': n_filled})
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err} '
              f'slots={n_filled}')

    # summarize fn calls during cmd 4 (steps 4-5)
    from collections import Counter
    c = Counter(e['fn'] for e in events)
    print('function call counts across all 6 steps:')
    for k, v in c.most_common():
        print(f'  {k:24s} {v}')

    # gate-relevant register values at the variant decisions
    res = {'history': hist, 'counts': dict(c),
           'events_during_cmd4': [e for e in events if e['cmd'] == 4][:400]}
    json.dump(res, open(OUT, 'w'), indent=1, default=str)
    print('JSON ->', OUT)
    return world, res


if __name__ == '__main__':
    main()
