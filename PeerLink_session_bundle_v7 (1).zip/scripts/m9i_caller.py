#!/usr/bin/env python3
"""M9i: find WHO calls 0x68c84b8 (the vtable-create) during cmd 5."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner

    def at_create(uc, address, size, ud):
        lr = uc.reg_read(UC_ARM64_REG_LR)
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        print(f'  68c84b8 entered: lr={lr - core.base:#x} '
              f'x0={x0:#x} (inner+{x0 - inner:#x})')

    core.uc.hook_add(UC_HOOK_CODE, at_create,
                     begin=core.base + 0x68c84b8,
                     end=core.base + 0x68c84b8 + 4)

    def mem_err(uc, type_, address, size, value, ud):
        print(f'  FAULT type={type_} addr={address:#x}')
        return False

    core.uc.hook_add(UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(6):
        before, after, err, pc = world.step()
        replug()
    print('--- cmd-5: 68c84b8 entries ---')
    before, after, err, pc = world.step()
    replug()
    print(f'cmd {before:#x} -> {after:#x} err={err}')


if __name__ == '__main__':
    main()
