#!/usr/bin/env python3
"""M6-analysis: what did the MatchMain playing frame actually EXECUTE and TOUCH?

Runs the SM frame with:
- function-level coverage (blocks -> containing functions via fgraph entries)
- write watchpoints on team/player regions of the match object
- ball module state before/after
- which of the 0x98d0500 module-manifest functions ran
"""
import sys
import os
import struct
import json

sys.path.insert(0, '/home/z/my-project/scripts')
import numpy as np
from matchmain_run import MatchMainWorld, A_SM, MATCH_SIZE
from unicorn import *
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/matchmain_exec.json'

# region watch: (match offset, size, name)
REGIONS = [
    (0x227D0, 2 * 0x2B8, 'team_sides_2x2B8'),
    (0x26B60, 0x200, 'team_region_26B60'),
    (0x265B0, 0x200, 'controller_hub_265B0'),
    (0x26830, 0x200, 'slot_mgr_26830'),
]


def func_of_block(block, entries_sorted):
    """Binary search: containing function start."""
    import bisect
    i = bisect.bisect_right(entries_sorted, block) - 1
    if i >= 0:
        return entries_sorted[i]
    return None


def main():
    world = MatchMainWorld(verbose=False)
    core = world.core

    # coverage + write tracing
    blocks = []
    core.uc.hook_add(UC_HOOK_BLOCK, lambda uc, a, s, u: blocks.append(a - core.base))

    writes = {name: [] for _, _, name in REGIONS}

    def make_w(region_off, region_size, name):
        def cb(uc, access, address, size, value, ud):
            rel = address - core.base - world.match
            if 0 <= rel - region_off < region_size:
                writes[name].append((rel, size))
                return True
            # outside: demand-zero behavior for scratch
            return True
        return cb

    # mem write hooks on match regions (Unicorn doesn't have per-region write
    # hooks; use a global write hook and filter)
    def wh(uc, access, address, size, value, ud):
        rel = address - world.match
        if 0 <= rel < MATCH_SIZE:
            for region_off, region_size, name in REGIONS:
                if region_off <= rel < region_off + region_size:
                    writes[name].append((rel, size, value))
                    break

    # record ball state before
    ball_before = core.safe_read(world.modA + 0x158, 296)
    match_before = core.safe_read(world.match, MATCH_SIZE)

    r = core.call(A_SM, x0=world.match, timeout_s=180, max_insns=800_000_000)
    print('SM error:', r['error'], 'blocks:', len(blocks))

    ball_after = core.safe_read(world.modA + 0x158, 296)
    match_after = core.safe_read(world.match, MATCH_SIZE)

    # ball diffs
    bd = sum(a != b for a, b in zip(ball_before, ball_after))
    print('ball +0x158 byte diffs:', bd)

    # match object diffs (excluding the regions already known)
    md = {}
    for i, (a, b) in enumerate(zip(match_before, match_after)):
        if a != b:
            md[i] = (a, b)
    print('match object bytes changed:', len(md))
    # summarize by 0x100 buckets
    buckets = {}
    for off, (a, b) in md.items():
        bk = off & ~0xFF
        buckets[bk] = buckets.get(bk, 0) + 1
    for bk in sorted(buckets):
        print(f'  match+{bk:#08x}: {buckets[bk]} bytes changed')

    # function coverage
    fg = np.load('/home/z/my-project/apk_lab/analysis/fgraph2.npz', allow_pickle=True)
    entries = np.unique(fg['entries'])
    entries_sorted = entries.tolist()
    funcs = set()
    for b in blocks:
        f = func_of_block(b, entries_sorted)
        if f is not None:
            funcs.add(int(f))
    print('distinct functions executed:', len(funcs))

    # how many are in the module manifest (0x98d0500 region)?
    # manifest functions from FINDINGS: 0x6a33ba8..0x6a9c430
    manifest_funcs = [f for f in funcs if 0x6a33000 <= f <= 0x6aa0000]
    print('module-manifest-range functions executed:', len(manifest_funcs))

    # player-module region: 0x6f40000-0x7300000 (player update machinery)
    player_funcs = [f for f in funcs if 0x6f40000 <= f <= 0x7300000]
    print('player-range functions executed:', len(player_funcs))

    res = {
        'sm_error': r['error'],
        'n_blocks': len(blocks),
        'n_functions': len(funcs),
        'ball_158_diffs': bd,
        'match_bytes_changed': len(md),
        'match_buckets': {hex(k): v for k, v in sorted(buckets.items())},
        'manifest_funcs': len(manifest_funcs),
        'player_range_funcs': len(player_funcs),
        'funcs_sample': sorted(hex(f) for f in list(funcs)[:400]),
        'region_writes': {k: len(v) for k, v in writes.items()},
    }
    json.dump(res, open(OUT, 'w'), indent=1)
    print('JSON ->', OUT)

    # save the full function list for the closure analysis
    np.save('/home/z/my-project/apk_lab/analysis/mm_exec_funcs.npy',
            np.array(sorted(funcs), dtype=np.int64))
    print('funcs saved -> mm_exec_funcs.npy')


if __name__ == '__main__':
    main()
