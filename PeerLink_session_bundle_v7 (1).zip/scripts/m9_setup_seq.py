#!/usr/bin/env python3
"""MILESTONE 9: drive the REAL match-setup command sequencer headlessly.

THE DISCOVERY (this session): 0x6a00e50 — the input-bank message
dispatcher (vtable slot +0x10 of listener vtables 0x978bf38 / 0x978cf60) —
is a SELF-DRIVING 109-command sequencer that constructs the entire match:

    dispatcher 0x6a00e50(match_core, msg)
      cmd id = [match_core+8]           (jump table 0xc6bdcc, 0x6d entries)
      handler executes
      handler stores NEXT cmd id at [match_core+8]   (0x6a01924)
      ...

Decoded chain head:
  cmd 0 -> 0x6a0093c  (main init: named subsystems, singleton 0xa417108)
        -> 1
  cmd 1 -> 0x6a00cd4 check -> 2
  cmd 2 -> *(0xa417111) gate + 0x66d032c(garr, str) -> [core+0x3CA0] -> 3
  cmd 3 -> (guard 0xa if gate) -> 4
  cmd 4 -> 0x6a0195c(core) gate -> 0x6a02000(core) = CONSTRUCTION DRIVER
           (2 sides x 11 slots from core+0x10 = THE 22 PLAYER MODULES
            + 3 more at core+0xC0 + [core+0xD8]) -> 5
  cmd 5 -> guards -> 0x6a027b0 -> 6
  ... cmd 0x40.. -> 0x6a027f8(core, side, slot) per-player constructions
  ... 109 commands total = the full match setup protocol.

Object architecture (two objects):
  OUTER match  (0x69917d8 world): state +0x139, +0x2DB, +0x2F8 -> inner,
               input hub +0x265B0, team region +0x26B60
  INNER core   (dispatcher world): cmd id +8, 22-player table +0x10..0xB8,
               hub +0x3818, context +0x3C40, mgrs +0x3C88/+0x3C98,
               team data +0x3958/+0x39F8, +0x3CA0/0x3CA4 flags

This harness drives the sequencer with [core+8] starting at 0 and watches
the 22 slots fill with Konami's own construction code.
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from uc_loader2 import EFootballCoreV2
from ball_object_run import BallWorld
from matchmain_run import MatchMainWorld
from unicorn import *
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m9_setup_seq.json'

A_DISPATCH = 0x6a00e50      # the command sequencer
A_REPLY = 0x68a3eb4         # outward notification (presentation layer)
A_CONSTRUCTION = 0x6a02000  # cmd 4: 22-module registration
A_PLAYER_CTOR = 0x6a027f8   # cmd 0x40+: per-player construction
A_JNI_ONLOAD = 0x2830374    # the REAL library entry point (Android order)
INIT_ARRAY = 0x98bd898      # 11,829 static initializers (reloc-filled)

G_GARR = 0xa409788          # guard array singleton

EXEC_BASE = 0xA4000000000
JNI_EXEC = 0xA4100000000    # separate RWX arena for JNI stubs


def slots22(core, inner):
    """The 22 player-module slots (2 sides x 11, stride 0x58)."""
    out = []
    for side in range(2):
        for slot in range(11):
            p = core.safe_read_u64(inner + 0x10 + side * 0x58 + slot * 8)
            out.append(p)
    return out


class SetupWorld(MatchMainWorld):
    """MatchMainWorld + the inner-core sequencer driving surface."""

    def __init__(self, verbose=True):
        super().__init__(verbose=verbose)
        core = self.core
        # -- inner core object (the dispatcher's world) ----------------------
        # reuse M6's inner_core (already linked at [outer+0x2F8], ball mgr at
        # +0x3C98); extend: cmd id at +8, 22-player table at +0x10..0xB8.
        self.inner = self.inner_core
        core.write_u32(self.inner + 8, 0)          # cmd = 0 (start)
        core.write_u64(self.inner, 0)              # vtable slot (filled by ctor)

        # ---- M9 RUNTIME PLUG SET (all data-only; see FINDINGS §16) --------
        # 1. locale facet-insert neutralization: the .bss locale statics are
        #    partially built headlessly; their facet-list insert targets
        #    garbage. nop the single store (documented DROP-class patch).
        core.uc.mem_write(core.base + 0x8130a20,
                          struct.pack('<I', 0xD503201F))
        # 2. one-shot gate *(0xa417111): 'cmd-2 string check done' -> set.
        core.write_u8(core.base + 0xa417111, 1)
        # 3. lazy-getter hub plugs (valid byte [X+8]=1, source NULL).
        for region in (0x3818, 0x3868, 0x3b88, 0x3b90, 0x3b98, 0x3ba0,
                       0x3958, 0x39a8, 0x39f8, 0x3a48,   # per-side team hubs
                       0x128, 0x3bd8, 0x3c40, 0x3c88):
            core.write_u8(self.inner + region + 8, 1)
        # 4. the two controllers (the hubs' cached [+0x40] objects):
        #    ctrl3868 (x26 in the cmd-4 gate) needs the readiness bytes;
        #    ctrl3818 (the construction driver's controller).
        self.ctrl3868 = core.alloc(0x4300, b'\0' * 0x4300, name='ctrl3868')
        for off, val, sz in [(0x14, 1, 1), (0x16, 1, 1), (0xCA, 1, 1),
                             (0xA0, 1, 1), (0x98, 1000, 4), (0x9C, 0, 4)]:
            if sz == 1:
                core.write_u8(self.ctrl3868 + off, val)
            else:
                core.write_u32(self.ctrl3868 + off, val)
        self.ctrl3818 = core.alloc(0x4300, b'\0' * 0x4300, name='ctrl3818')
        core.write_u64(self.inner + 0x3868 + 0x40, self.ctrl3868)
        core.write_u64(self.inner + 0x3818 + 0x40, self.ctrl3818)

        # -- minimal message object (x1): non-NULL, reply path neutralized ---
        self.msg = core.alloc(0x200, b'\0' * 0x200, name='msg')

        # -- fabricate the allocator plugin at [0x9e7b260] -------------------
        # 0x421eabc (18,629 call sites) dispatches to *(0x98d5148)->plugin
        # vt[0x28](plugin, size, flags). The game's own factory (0x41b4d38)
        # depends on exact mmap-growth math; instead we install a plugin
        # whose alloc routes to the REAL malloc PLT (our managed heap).
        self.plugin = core.alloc(0x100, b'\0' * 0x100, name='alloc_plugin')
        self.plugin_vt = core.alloc(0x200, b'\0' * 0x200, name='alloc_plugin_vt')
        core.write_u64(self.plugin, self.plugin_vt)
        # bare-ret filler for every slot
        try:
            core.uc.mem_map(JNI_EXEC, 0x100000, UC_PROT_ALL)
        except UcError:
            pass
        if not hasattr(self, '_jni_next'):
            self._jni_next = JNI_EXEC
        pret = self._jni_emit(struct.pack('<I', 0xD65F03C0))
        for off in range(0, 0x200, 8):
            core.write_u64(self.plugin_vt + off, pret)
        # vt[0x28] = alloc(this, size, flags): mov w0, w1; b malloc(PLT)
        malloc_stub = None
        for a, n in core.stub_of.items():
            if n == 'malloc':
                malloc_stub = a
                break
        assert malloc_stub, 'malloc stub not found'
        try:
            core.uc.mem_map(JNI_EXEC, 0x100000, UC_PROT_ALL)
        except UcError:
            pass
        self._jni_next = self._jni_next if hasattr(self, '_jni_next') else JNI_EXEC
        a0 = self._jni_next
        self._jni_next = a0 + 0x100
        delta = (malloc_stub - a0) >> 2
        core.uc.mem_write(a0, struct.pack('<2I', 0x2A0103E0,
                                          0x14000000 | (delta & 0x3FFFFFF)))
        core.write_u64(self.plugin_vt + 0x28, a0)
        # install: [0x9e7b260] = plugin ; guard done
        core.write_u64(core.base + 0x9e7b260, self.plugin)
        core.write_u8(core.base + 0x9e54210, 1)

        # -- empty-list invariant for the .bss std::list at 0xa40ff50 -------
        # 0x691be14 (cmd-0 guard) walks [*(0xa40ff50)] .. sentinel +0x8.
        # With bss zeros, begin(NULL) != end(0xa40ff58) -> infinite walk.
        # Game state: empty list => begin == &head+8.
        core.write_u64(core.base + 0xa40ff50, core.base + 0xa40ff58)


        # -- neutralize the outward reply sender (presentation layer) --------
        core.uc.mem_write(core.base + A_REPLY,
                          struct.pack('<II', 0x52800020, 0xD65F03C0))  # w0=1; ret

        # -- tracers -----------------------------------------------------------
        self.cmd_log = []       # (step, cmd_before, cmd_after, error)
        self.covered = set()
        core.uc.hook_add(UC_HOOK_BLOCK, self._blk)

        self.w_construction = core.watch(
            A_CONSTRUCTION, self._ev_construction, 'construction_driver')
        self.w_pctor = core.watch(
            A_PLAYER_CTOR, self._ev_pctor, 'player_ctor')

    def _blk(self, uc, addr, size, ud):
        self.covered.add(addr - self.core.base)

    def _ev_construction(self, uc, core):
        self.cmd_log.append(('CONSTRUCTION', uc.reg_read(UC_ARM64_REG_X0)))

    def _ev_pctor(self, uc, core):
        self.cmd_log.append(
            ('PLAYER_CTOR', uc.reg_read(UC_ARM64_REG_X1),
             uc.reg_read(UC_ARM64_REG_X2)))

    # ---------------------------------------------------------------- bootstrap
    def bootstrap_game(self, run_init_array=True, max_init=None):
        """The REAL Android library bootstrap, in the REAL order:
        1. JNI_OnLoad(vm)          - core singletons (TLS mgr 0x9e05260, ...)
        2. .init_array entries     - 11,829 TU-level static initializers
        Platform surface (JavaVM/JNIEnv vtables) = STUB class.
        Returns a dict of stats.
        """
        core = self.core
        stats = {'onload_err': None, 'init_ok': 0, 'init_fail': 0,
                 'init_fails': []}

        # -- fabricate the JNI surface ----------------------------------------
        if not hasattr(core, '_jni_vm'):
            uc = core.uc
            if not any(r.start <= JNI_EXEC < r.end for r in ()):
                pass
            try:
                uc.mem_map(JNI_EXEC, 0x100000, UC_PROT_ALL)
            except UcError:
                pass                    # already mapped
            self._jni_next = JNI_EXEC
            ret0 = self._jni_emit(struct.pack('<II', 0xD65F03C0 & 0xFFFFFFFF
                                              or 0xD65F03C0, 0)) if False else None
            # bare ret
            ret0 = self._jni_emit(struct.pack('<I', 0xD65F03C0))

            jvm_vt = core.alloc(0x400, b'\0' * 0x400, name='jvm_vt')
            env_vt = core.alloc(0x1000, b'\0' * 0x1000, name='env_vt')
            self.jvm = core.alloc(0x100, b'\0' * 0x100, name='jvm')
            self.jenv = core.alloc(0x100, b'\0' * 0x100, name='jenv')
            core.write_u64(self.jvm, jvm_vt)
            core.write_u64(self.jenv, env_vt)
            # JNIEnv: every slot -> bare ret (platform STUB)
            for off in range(0, 0x1000, 8):
                core.write_u64(env_vt + off, ret0)
            # JavaVM: GetEnv (vt+0x30): [x1] = jenv, w0 = 0 (JNI_OK)
            env_addr = self.jenv
            code = b''
            # movz x8, #(env & 0xFFFF); movk x8, #.., lsl 16/32/48; str x8,[x1]; mov w0,#0; ret
            for sh in (0, 16, 32, 48):
                part = (env_addr >> sh) & 0xFFFF
                if sh == 0:
                    w = 0xD2800008 | (part << 5)       # movz x8, part
                else:
                    w = 0xF2800008 | (part << 5) | ((sh // 16) << 21)  # movk x8, lsl sh
                code += struct.pack('<I', w)
            code += struct.pack('<I', 0xF9000408)     # str x8, [x1]  hmm wrong
            # correct encoding: str x8, [x1] = 0xF9000428? compute: STR Xt,[Xn,#0]
            # F9 00 00 00 | (imm12=0 <<10) | (Rn=1 <<5) | Rt=8 => 0xF9000028
            code = code[:-4] + struct.pack('<I', 0xF9000028)
            code += struct.pack('<II', 0x52800000, 0xD65F03C0)  # w0=0; ret
            getenv = self._jni_emit(code)
            for off in range(0, 0x400, 8):
                core.write_u64(jvm_vt + off, ret0)
            core.write_u64(jvm_vt + 0x30, getenv)
            core._jni_vm = self.jvm

        # -- 1. JNI_OnLoad -----------------------------------------------------
        r = core.call(A_JNI_ONLOAD, x0=core._jni_vm, timeout_s=300,
                      max_insns=400_000_000)
        stats['onload_err'] = r['error']
        print('[bootstrap] JNI_OnLoad:', r['error'])
        if r['error']:
            fatal = [l for l in core._log if 'FAULT' in l or 'INVALID' in l]
            for f in fatal[-6:]:
                print('    FATAL:', f)

        if not run_init_array:
            return stats

        # -- 2. init_array -----------------------------------------------------
        arr = core.base + INIT_ARRAY
        n = 94632 // 8
        data = core.safe_read(arr, 94632)
        vals = [v for v in struct.unpack(f'<{n}Q', data)
                if v and core.base < v < core.base + 0xA0000000]
        if max_init:
            vals = vals[:max_init]
        for i, v in enumerate(vals):
            fn = v - core.base
            r = core.call(fn, timeout_s=30, max_insns=30_000_000)
            if r['error']:
                stats['init_fail'] += 1
                if len(stats['init_fails']) < 60:
                    stats['init_fails'].append(
                        (i, hex(fn), str(r['error'])[:48]))
            else:
                stats['init_ok'] += 1
            if (i + 1) % 2000 == 0:
                print(f'  [init_array] {i+1}/{len(vals)} '
                      f'ok={stats["init_ok"]} fail={stats["init_fail"]}')
        print(f'[bootstrap] init_array: {stats["init_ok"]} ok, '
              f'{stats["init_fail"]} fail / {len(vals)}')
        return stats

    def _jni_emit(self, code):
        core = self.core
        a = self._jni_next
        self._jni_next = (a + max(len(code), 16) + 0xFF) & ~0xFF
        assert self._jni_next < JNI_EXEC + 0x100000
        core.uc.mem_write(a, code)
        return a

    # ---------------------------------------------------------------- drive
    def step(self, timeout_s=90):
        """One dispatcher call. Returns (cmd_before, cmd_after, error)."""
        core = self.core
        before = core.safe_read_u32(self.inner + 8)
        r = core.call(A_DISPATCH, x0=self.inner, x1=self.msg,
                      timeout_s=timeout_s, max_insns=80_000_000)
        after = core.safe_read_u32(self.inner + 8)
        return before, after, r['error'], r['pc']

    def drive(self, max_steps=200, stall_limit=3):
        """Drive the sequencer until it stalls or completes."""
        history = []
        stall = 0
        for i in range(max_steps):
            before, after, err, pc = self.step()
            n_filled = sum(1 for p in slots22(self.core, self.inner) if p)
            history.append({'step': i, 'cmd': before, 'next': after,
                            'err': err, 'pc': hex(pc), 'slots22': n_filled})
            print(f'  step {i:3d}  cmd {before:#04x} -> {after:#04x}  '
                  f'err={err}  slots22={n_filled}/22')
            if err:
                fatal = [l for l in self.core._log
                         if 'FAULT' in l or 'INVALID' in l]
                for f in fatal[-8:]:
                    print('    FATAL:', f)
                break
            if before == after:
                stall += 1
                if stall >= stall_limit:
                    print(f'  stalled at cmd {before:#x} for {stall} steps')
                    break
            else:
                stall = 0
        return history


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    res = {}

    print('=== M9: the match-setup command sequencer 0x6a00e50 ===')

    # -- stage 1: mini-bootstrap (JNI_OnLoad + the 15 clean init entries) --
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    res['bootstrap'] = {'ok': bs['init_ok'], 'fail': bs['init_fail'],
                        'onload_err': bs['onload_err']}

    # -- stage 2: construct the module registry via the game's lazy getter --
    r = core.call(0x6a09418, timeout_s=60)
    reg = core.safe_read_u64(core.base + 0xa417250)
    res['registry'] = {'error': r['error'], 'addr': hex(reg)}
    print('[M9] registry *(0xa417250) =', hex(reg))

    # -- stage 3: clean the guard array (bootstrap writes partial guards) --
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    # -- stage 4: DRIVE THE SEQUENCER ----------------------------------------
    core._log.clear()
    print('--- driving ---')
    hist = world.drive(max_steps=150)

    print('--- final state ---')
    n = sum(1 for p in slots22(core, world.inner) if p)
    print('  22 slots filled =', n, '/22')
    extras = [hex(core.safe_read_u64(world.inner + 0xC0 + i * 8))
              for i in range(4)]
    print('  extra slots +0xC0..0xD8:', [e for e in extras if e != '0x0'])
    print('  coverage blocks:', len(world.covered))

    faults = [l for l in core._log
              if 'FAULT' in l or 'INVALID' in l]
    print('  faults:', len(faults))
    for f in faults[:8]:
        print('   ', f)

    res['history'] = hist
    res['slots22_final'] = n
    res['cmd_path'] = [h['cmd'] for h in hist]
    res['player_ctor_events'] = [e for e in world.cmd_log
                                 if e[0] == 'PLAYER_CTOR'][:60]
    res['construction_events'] = [e for e in world.cmd_log
                                  if e[0] == 'CONSTRUCTION'][:10]
    res['n_blocks'] = len(world.covered)
    res['faults'] = faults[:20]

    json.dump(res, open(OUT, 'w'), indent=1, default=str)
    print('JSON ->', OUT)
    return world, res


if __name__ == '__main__':
    main()
