#!/usr/bin/env python3
"""M7 phase 1: construct the REAL input bank headlessly and decode its layout.

The input bank singleton *(0xa417188):
  ctor      0x6a06b60   (0x1C070 bytes)
  factory   0x6a07120   (creates + installs the singleton)
  getter    0x6a067b8   (returns *(0xa417188))
  alloc     0x6a067c4+  (command-header pool: nodes at +0x110F88, 0x18 each)
  refcount  0x6a07190   (release path w/ [0x1BFFC] counter)
  pump      0x6a075b8   (message queue -> per-entity command states)

Milestone M7a: run 0x6a06b60 on a fabricated buffer, verify it completes
without faults, then dump the resulting object layout (what the ctor wrote).
"""
import json
import sys
import os
import struct

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from matchmain_run import MatchMainWorld, A_SM
from unicorn import *
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/inputbank_run.json'

A_BANK_CTOR = 0x6a06b60
A_BANK_FACTORY = 0x6a07120
A_BANK_GET = 0x6a067b8
A_PUMP = 0x6a075b8
G_BANK = 0xa417188


def main():
    world = MatchMainWorld(verbose=False)
    core = world.core
    res = {}

    # -- M7a: construct the input bank with the game's own ctor --------------
    print('=== M7a: input bank ctor 0x6a06b60 ===')
    bank = core.alloc(0x1C070, b'\0' * 0x1C070, name='input_bank')
    trail = []
    core.uc.hook_add(UC_HOOK_BLOCK, lambda uc, a, s, u: trail.append(a - core.base))
    r = core.call(A_BANK_CTOR, x0=bank, timeout_s=120)
    print('ctor result:', {'error': r['error'], 'pc': hex(r['pc'])})
    res['M7a'] = {'error': r['error'], 'n_blocks': len(trail)}

    faults = [l for l in core._log if 'FAULT' in l or 'INVALID' in l]
    print('faults:', len(faults))
    for f in faults[:8]:
        print('  ', f)
    res['M7a']['faults'] = faults[:8]

    # dump what the ctor wrote: nonzero regions
    data = core.safe_read(bank, 0x1C070)
    nonzero = [(i, data[i]) for i in range(0x1C070) if data[i]]
    print('nonzero bytes after ctor:', len(nonzero))
    res['M7a']['nonzero_bytes'] = len(nonzero)

    # summarize by 0x100 buckets
    buckets = {}
    for i, v in nonzero:
        bk = i & ~0xFF
        buckets.setdefault(bk, []).append((i - bk, v))
    print('buckets:', len(buckets))
    for bk in sorted(buckets):
        vals = buckets[bk]
        # compact print: first 6 offsets
        offs = [hex(o) for o, _ in vals[:6]]
        print(f'  bank+{bk:#07x}: {len(vals):3d} nonzero at {offs}')
    res['M7a']['buckets'] = {hex(k): len(v) for k, v in buckets.items()}

    json.dump(res, open(OUT, 'w'), indent=1, default=str)
    print('JSON ->', OUT)


if __name__ == '__main__':
    main()
