#!/usr/bin/env python3
"""M9e: find WHO clears [inner+0x3868+0x40] / [inner+0x3818+0x40]."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner

    targets = {
        inner + 0x3868 + 0x40: 'ctrl3868_ptr',
        inner + 0x3818 + 0x40: 'ctrl3818_ptr',
        inner + 0x3b88 + 0x40: 'ctrl3b88_ptr',
    }

    def mem_write(uc, type_, address, size, value, ud):
        if address in targets:
            pc = uc.reg_read(UC_ARM64_REG_PC)
            cmd = core.safe_read_u32(inner + 8)
            print(f'  WRITE {targets[address]} @ {address:#x} = {value:#x} '
                  f'pc={pc - core.base:#x} cmd={cmd:#x}')

    core.uc.hook_add(UC_HOOK_MEM_WRITE, mem_write)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)
    print('--- replug controllers ---')
    core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
    core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    for i in range(7):
        before, after, err, pc = world.step()
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err}')
        # replug after every step (harness-side fix to test the loop)
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)


if __name__ == '__main__':
    main()
