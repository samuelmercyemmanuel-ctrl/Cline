#!/usr/bin/env python3
"""Dump the object layout read/written by 0x69919e0 (playing-state update).

Offsets from static analysis of the disassembly. Output: for each address,
size, and match-relative offset, the current byte value (all zero after
fabrication). This is the layout map for instrumenting the first real run.
"""
LAYOUT = [
    # (match offset, size, role)
    (0x139, 1, 'MatchMain state byte (state 1 = PLAYING)'),
    (0x142, 2, 'playing scratch (cleared per frame)'),
    (0x144, 1, 'playing scratch (cleared per frame)'),
    (0x146, 1, 'branch: skip-team vs with-team orchestrator'),
    (0x14c, 1, '0x8160680 gate + 0x68034d0 arg (0x146? no: 0x14c)'),
    (0x164, 1, 'team orchestrator branch'),
    (0x27c, 4, 'playing scratch (cleared)'),
    (0x2db, 1, 'gate: ball via 0x6a059b0 (else 0x69920f0)'),
    (0x2f8, 8, 'PTR inner match-core object (module managers at +0x3C98)'),
    (0x308, 0, 'virtual arg [x20]+0x288 (state-2 transition)'),
    (0x265B0, 0x100, 'input collector region: 0x68b0408(+0x265B0) ctrl storage'),
    (0x26830, 0x200, 'slot manager: 0x720edb0(match+0x26840, ctrl), 3x0x50 slots'),
    (0x26B60, 0x100, 'team orchestrator region (0x68b335c)'),
    (0x227D0, 2 * 0x2B8, 'team orchestrator 2 sides, 0x2B8 stride'),
    (0x3C98, 8, 'PTR ball module manager (in INNER core object, not match)'),
]

for off, size, role in LAYOUT:
    print(f'match+{off:#08x}  size={size:#06x}  {role}')
