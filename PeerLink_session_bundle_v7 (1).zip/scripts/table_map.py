#!/usr/bin/env python3
"""M4: the module table + the full per-frame call chain.

1. Find the true bounds of the function-pointer table around 0x98d0500
   (contiguous reloc-slot runs) — the MODULE MANIFEST.
2. Find code that references the table base (the ITERATOR = match tick).
3. Reconstruct the exact call chain from the message entry (0x69c3e98)
   down to ball_update_entry (0x6e938a0).
4. Dump signatures/structure of key chain nodes.
"""
import json
import numpy as np

AN = '/home/z/my-project/apk_lab/analysis'

pr = np.load(f'{AN}/packed_relocs.npz')
roff, radd = pr['offset'].astype(np.int64), pr['addend'].astype(np.int64)
oorder = np.argsort(roff)
ro_s, ra_s = roff[oorder], radd[oorder]

fg = np.load(f'{AN}/fgraph2.npz')
ent = np.sort(fg['entries'].astype(np.int64))
src = fg['src'].astype(np.int64)
dst = fg['dst'].astype(np.int64)
order = np.argsort(dst)
d_sorted, s_sorted = dst[order], src[order]
forder = np.argsort(src)
f_sorted, t_sorted = src[forder], dst[forder]


def callers_of(f):
    i, j = np.searchsorted(d_sorted, f, 'left'), np.searchsorted(d_sorted, f, 'right')
    return np.unique(s_sorted[i:j]).tolist()


def callees_of(f):
    i, j = np.searchsorted(f_sorted, f, 'left'), np.searchsorted(f_sorted, f, 'right')
    return np.unique(t_sorted[i:j]).tolist()


# ---------- 1. table bounds around 0x98d0500 ----------
print('=== MODULE TABLE BOUNDS ===')
lo, hi = np.searchsorted(ro_s, 0x98cc000, 'left'), np.searchsorted(ro_s, 0x98d2000, 'right')
seg_offs = ro_s[lo:hi].tolist()
seg_adds = ra_s[lo:hi].tolist()
# contiguous runs (gap > 0x10 starts a new run)
runs = []
start = 0
for i in range(1, len(seg_offs) + 1):
    if i == len(seg_offs) or seg_offs[i] - seg_offs[i - 1] > 0x10:
        runs.append((seg_offs[start], seg_offs[i - 1], i - start))
        start = i
for r0, r1, n in runs:
    if n >= 8:
        print(f'  run {r0:#x}..{r1:#x} ({n} slots)')

# the module manifest: the run containing 0x98d0500
big = max(runs, key=lambda r: r[2])
print(f'\nLargest run: {big[0]:#x}..{big[1]:#x} ({big[2]} slots)')
mlo, mhi = np.searchsorted(ro_s, big[0], 'left'), np.searchsorted(ro_s, big[1], 'right')
mod_entries = [(o, a) for o, a in zip(ro_s[mlo:mhi].tolist(), ra_s[mlo:mhi].tolist())]
print('MODULE MANIFEST:')
for idx, (o, a) in enumerate(mod_entries):
    print(f'  [{idx:3d}] slot {o:#x}: {a:#x}  (size~{0})')

# ---------- 2. who references the table ----------
ad = np.load(f'{AN}/adrp_map.npz')
rt = ad['ref_target'].astype(np.int64)
rs = ad['ref_site'].astype(np.int64)
aorder = np.argsort(rt)
rt_s, rs_s = rt[aorder], rs[aorder]


def refs_to(t):
    i, j = np.searchsorted(rt_s, t, 'left'), np.searchsorted(rt_s, t, 'right')
    return rs_s[i:j].tolist()


def func_of(site):
    i = np.searchsorted(ent, site, 'right') - 1
    return int(ent[i]) if i >= 0 else None


print('\n=== REFERENCES TO TABLE REGION ===')
tab_lo, tab_hi = big[0], big[1]
for t in range(tab_lo - 0x20, tab_hi + 0x20, 0x8):
    rr = refs_to(t)
    if rr:
        fs = sorted(set(func_of(x) for x in rr if func_of(x)))
        print(f'  ref to {t:#x}: {[hex(x) for x in fs[:10]]}')

# ---------- 3. full chain 0x69c3e98 -> ball_update_entry ----------
print('\n=== CALL CHAIN: message entry -> ball_update_entry ===')
# BFS down from top, record path to goal
from collections import deque

TOP, GOAL = 0x69c3e98, 0x6e938a0
prev = {TOP: None}
q = deque([TOP])
found = False
while q and not found:
    f = q.popleft()
    for c in callees_of(f):
        if c not in prev:
            prev[c] = f
            if c == GOAL:
                found = True
                break
            q.append(c)
if found:
    path = [GOAL]
    while path[-1] is not None:
        path.append(prev[path[-1]])
    path = [p for p in path if p is not None]
    path.reverse()
    print(f'path ({len(path)} nodes):')
    for p in path:
        cs = callers_of(p)
        print(f'  {p:#x}  (callers: {[hex(c) for c in cs[:4]]})')
else:
    print('  no path found via BL/B')

json.dump({'module_manifest': [(hex(o), hex(a)) for o, a in mod_entries],
           'table_run': [hex(big[0]), hex(big[1])]},
          open(f'{AN}/module_manifest.json', 'w'), indent=1)
print('\nJSON ->', f'{AN}/module_manifest.json')
