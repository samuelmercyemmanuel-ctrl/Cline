#!/usr/bin/env python3
"""M10m: dump fault context for the 0x66fd970 read."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22
from m10_realctor import A_INNER_CTOR


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        if pc - core.base in (0x66fd970,):
            x21 = uc.reg_read(UC_ARM64_REG_X21)
            x19 = uc.reg_read(UC_ARM64_REG_X19)
            lr = uc.reg_read(UC_ARM64_REG_LR)
            w22 = uc.reg_read(UC_ARM64_REG_W22)
            print(f'FAULT@0x66fd970: addr={address:#x} x21={x21:#x} '
                  f'x19={x19:#x} w22={w22} lr={lr - core.base:#x}')
            try:
                head = core.safe_read_u64(x21 + 0x60)
                print(f'  [x21+0x60] head = {head:#x}')
                print(f'  [head] = {core.safe_read_u64(head):#x} '
                      f'[head+8]={core.safe_read_u64(head+8):#x} '
                      f'[head+0x1c]... w={core.safe_read(head+0x1c,4).hex()}')
                # x21's vtable
                print(f'  [x21] vt = {core.safe_read_u64(x21):#x}')
            except Exception as e:
                print('  dump err', e)
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    core.uc.mem_write(core.base + 0x68a0f30, struct.pack('<I', 0xD503201F))
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    r = core.call(0x68a7a5c, timeout_s=120, max_insns=200_000_000)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)
    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=300,
                  max_insns=1_000_000_000)
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(10):
        before, after, err, pc = world.step(timeout_s=240)
        replug()
        n = sum(1 for p in slots22(core, inner) if p)
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err} slots={n}')


if __name__ == '__main__':
    main()
