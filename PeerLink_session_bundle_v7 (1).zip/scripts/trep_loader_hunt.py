#!/usr/bin/env python3
"""M5.1: find the replay loader — strings -> adrp refs -> containing functions.

The game must parse .trep (input stream) and .rep (record stream) files.
Scan the binary for replay-related ASCII/UTF-16 strings, then locate code
(adrp+add materializations) that references those string addresses.
"""
import numpy as np
import struct
import json

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

data = open(SO, 'rb').read()

# --- ELF vaddr mapping ---
from elftools.elf.elffile import ELFFile
f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
loads.sort()


def off2va(off):
    for va, mem, fsz, fo in loads:
        if fo <= off < fo + fsz:
            return va + (off - fo)
    return None


def va2off(vaddr):
    for va, mem, fsz, fo in loads:
        if va <= vaddr < va + mem:
            return fo + (vaddr - va)
    return None


# --- string scan ---
patterns = [b'.trep', b'.rep\x00', b'.erep', b'tutorial_replay', b'TutorialReplay',
            b'trep\x00', b'erep\x00', b'ReplayFile', b'replay_data', b'ReplayData',
            b'mob_replay', b'PadRecord', b'pad_record', b'InputRecord', b'input_record']

hits = {}
for pat in patterns:
    start = 0
    while True:
        i = data.find(pat, start)
        if i < 0:
            break
        start = i + 1
        # require printable-ish context (string blob, not code)
        va = off2va(i)
        if va is None:
            continue
        # capture up to 64 bytes of the surrounding C string
        end = data.find(b'\x00', i, i + 96)
        s = data[i:min(end if end > 0 else i + 64, i + 96)]
        try:
            txt = s.decode('ascii')
        except Exception:
            txt = s.hex()
        hits.setdefault(pat, []).append((va, txt))
        if len(hits[pat]) > 60:
            break

for pat, lst in hits.items():
    print(f'pattern {pat!r}: {len(lst)} hits')
    for va, txt in lst[:12]:
        print(f'   {va:#x}  {txt[:80]!r}')

json.dump({p.decode(): [(hex(v), t) for v, t in l] for p, l in hits.items()},
          open(f'{AN}/replay_strings.json', 'w'), indent=1)

# --- adrp refs to string addresses ---
adrp = np.load(f'{AN}/adrp_map.npz', allow_pickle=True)
site, tgt, kind = adrp['ref_site'], adrp['ref_target'], adrp['ref_kind']
print('\nadrp kinds:', np.unique(kind, return_counts=True))

# map: target -> list of sites (adrp pages; the +add lands on the string)
target2sites = {}
order = np.argsort(tgt)
tgt_s, site_s, kind_s = tgt[order], site[order], kind[order]

all_vas = []
for pat, lst in hits.items():
    all_vas += [v for v, _ in lst]

print(f'\nsearching adrp refs for {len(all_vas)} string addrs...')
refs = {}
for va in set(all_vas):
    # adrp targets are page-aligned; string ref = adrp page + add
    page = va & ~0xFFF
    lo = np.searchsorted(tgt_s, page, 'left')
    hi = np.searchsorted(tgt_s, page, 'right')
    matches = []
    for k in range(lo, hi):
        # ref_kind: assume 0=page only, 1/2 = page+imm; check actual add
        matches.append((int(site_s[k]), int(tgt_s[k]), int(kind_s[k])))
    if matches:
        refs[hex(va)] = matches

for va, ms in list(refs.items())[:30]:
    print(f'string {va}: {len(ms)} adrp-page refs, sites: {[hex(m[0]) for m in ms[:8]]}')

json.dump({k: [(hex(a), hex(b), c) for a, b, c in v] for k, v in refs.items()},
          open(f'{AN}/replay_str_refs.json', 'w'), indent=1)
print('\nJSON -> replay_strings.json / replay_str_refs.json')
