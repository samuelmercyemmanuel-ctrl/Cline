#!/usr/bin/env python3
"""CRI CPK extractor for eFootball data archives.

Ported from CriPakTools (esperknight/CriPakTools, CPK.cs) — authoritative logic:
- ReadUTFData: after 4-char tag: u32 LE pad, u64 LE size, packet[size]
- DecryptUTF: LCG stream: m = 0x655f; per byte: XOR (m & 0xff); m = (m * 0x4115) & 0xffffffff
- @UTF table (big endian): magic, u32 table_size, u32 rows_off, u32 strings_off, u32 data_off,
  u32 table_name_off, u16 num_columns, u16 row_width, u32 num_rows,
  schema: per column { u8 flags (0 -> 3 pad bytes + re-read), s32 name_off },
  then CONSTANT values in schema order (typed widths),
  rows area (row_width per row, PERROW columns only), strings area, data area
- TOC: FileOffset relative to min(ContentOffset, TocOffset) (add_offset)
- CRILAYLA-compressed files: decompress to ExtractSize

Usage:
  python3 cpk_extract.py list   <cpk>
  python3 cpk_extract.py extract <cpk> <outdir> [name-filter]
"""
import struct, sys, os, io


def decrypt_utf(packet, m=0x655f, t=0x4115):
    out = bytearray(len(packet))
    mm = m
    for i, b in enumerate(packet):
        out[i] = b ^ (mm & 0xFF)
        mm = (mm * t) & 0xFFFFFFFF
    return bytes(out)


class UTFTable:
    BASE = 8   # rows/strings/data offsets are relative to packet+8 (after magic+size)

    def __init__(self, packet):
        assert packet[:4] == b'@UTF', 'not a @UTF packet'
        (self.table_size, self.rows_off, self.strings_off, self.data_off,
         self.table_name_off) = struct.unpack_from('>5I', packet, 4)
        self.num_columns, self.row_width = struct.unpack_from('>HH', packet, 0x18)
        (self.num_rows,) = struct.unpack_from('>I', packet, 0x1c)
        self.columns = []
        pos = 0x20
        for i in range(self.num_columns):
            flags = packet[pos]
            pos += 1
            if flags == 0:
                pos += 3
                flags = packet[pos]
                pos += 1
            (name_off,) = struct.unpack_from('>i', packet, pos)
            pos += 4
            name = self._cstr(packet, self.BASE + self.strings_off + name_off)
            self.columns.append({'flags': flags, 'name': name})
        # constant values (schema order)
        for col in self.columns:
            st = col['flags'] & 0xF0
            if st == 0x30:
                ty = col['flags'] & 0x0F
                col['const'] = self._read_typed(packet, pos, ty)
                pos += self._type_size(ty)
            else:
                col['const'] = None
        # rows
        self.rows = []
        rpos = self.BASE + self.rows_off
        for r in range(self.num_rows):
            row = {}
            for col in self.columns:
                st = col['flags'] & 0xF0
                ty = col['flags'] & 0x0F
                if st == 0x00:
                    row[col['name']] = None
                elif st == 0x10:
                    row[col['name']] = 0
                elif st == 0x30:
                    row[col['name']] = col['const']
                else:  # 0x50 PERROW
                    val, sz = self._read_typed_at(packet, rpos, ty)
                    if ty == 0x0A:  # string: value is offset
                        row[col['name']] = self._cstr(packet, self.BASE + self.strings_off + val)
                    elif ty == 0x0B:  # data: (offset, size)
                        off = val
                        (dsz,) = struct.unpack_from('>I', packet, rpos + 4)
                        row[col['name']] = (self.BASE + self.data_off + off, dsz)
                    else:
                        row[col['name']] = val
                    rpos += self._type_size(ty) if ty != 0x0B else 8
            self.rows.append(row)
            assert rpos <= self.BASE + self.strings_off + self.num_columns, 'row overflow'

    @staticmethod
    def _cstr(packet, off):
        end = packet.find(b'\0', off)
        return packet[off:end].decode('utf-8', 'replace')

    @staticmethod
    def _type_size(ty):
        return {0: 1, 1: 1, 2: 2, 3: 2, 4: 4, 5: 4, 6: 8, 7: 8, 8: 4, 0xA: 4, 0xB: 8}.get(ty, 4)

    def _read_typed(self, packet, pos, ty):
        v, _ = self._read_typed_at(packet, pos, ty)
        return v

    @staticmethod
    def _read_typed_at(packet, pos, ty):
        if ty in (0, 1):
            return packet[pos], 1
        if ty in (2, 3):
            return struct.unpack_from('>H', packet, pos)[0], 2
        if ty in (4, 5):
            return struct.unpack_from('>I', packet, pos)[0], 4
        if ty in (6, 7):
            return struct.unpack_from('>Q', packet, pos)[0], 8
        if ty == 8:
            return struct.unpack_from('>f', packet, pos)[0], 4
        if ty == 0xA:
            return struct.unpack_from('>i', packet, pos)[0], 4
        if ty == 0xB:
            return struct.unpack_from('>i', packet, pos)[0], 8
        raise ValueError(f'bad type {ty}')


class CPK:
    def __init__(self, path):
        self.f = open(path, 'rb')
        self.entries = []
        self.parse()

    def _read_table_after_tag(self, tagpos):
        self.f.seek(tagpos + 4)
        unk = struct.unpack('<I', self.f.read(4))[0]
        size = struct.unpack('<Q', self.f.read(8))[0]
        packet = self.f.read(size)
        enc = False
        if packet[:4] != b'@UTF':
            packet = decrypt_utf(packet)
            enc = True
            assert packet[:4] == b'@UTF', f'UTF decrypt failed at {tagpos:#x}'
        return UTFTable(packet), enc

    def parse(self):
        f = self.f
        f.seek(0)
        assert f.read(4) == b'CPK ', 'not a CPK'
        main, _ = self._read_table_after_tag(0)
        hdr = main.rows[0]
        self.hdr = hdr
        toc_off = hdr.get('TocOffset', 0xFFFFFFFFFFFFFFFF)
        etoc_off = hdr.get('EtocOffset', 0xFFFFFFFFFFFFFFFF)
        itoc_off = hdr.get('ItocOffset', 0xFFFFFFFFFFFFFFFF)
        content_off = hdr.get('ContentOffset', 0xFFFFFFFFFFFFFFFF)
        self.align = hdr.get('Align', 2048) or 2048
        print(f'[cpk] Toc={toc_off:#x} Etoc={etoc_off:#x} Itoc={itoc_off:#x} '
              f'Content={content_off:#x} Files={hdr.get("Files")} Align={self.align}')
        add_offset = min(x for x in (content_off, toc_off)
                         if x != 0xFFFFFFFFFFFFFFFF) if toc_off != 0xFFFFFFFFFFFFFFFF or content_off != 0xFFFFFFFFFFFFFFFF else 0
        if toc_off != 0xFFFFFFFFFFFFFFFF:
            toc, enc = self._read_table_after_tag(toc_off)
            print(f'[cpk] TOC rows: {toc.num_rows} (encrypted={enc})')
            for row in toc.rows:
                fo = row.get('FileOffset')
                if fo is not None and fo != 0xFFFFFFFFFFFFFFFF:
                    fo += add_offset
                self.entries.append({
                    'DirName': row.get('DirName') or '',
                    'FileName': row.get('FileName') or '',
                    'FileSize': row.get('FileSize') or 0,
                    'ExtractSize': row.get('ExtractSize') or 0,
                    'FileOffset': fo,
                    'ID': row.get('ID'),
                    'compressed': (row.get('ExtractSize') or 0) > (row.get('FileSize') or 0) + 16,
                })
        if itoc_off != 0xFFFFFFFFFFFFFFFF and not self.entries:
            itoc, _ = self._read_table_after_tag(itoc_off)
            print('[cpk] ITOC present (id-only layout), rows:', itoc.num_rows)

    def list(self):
        for e in self.entries:
            path = (e['DirName'] + '/' if e['DirName'] else '') + e['FileName']
            print(f"{e['ID'] if e['ID'] is not None else -1:>6} {e['FileSize']:>12,} "
                  f"{e['ExtractSize']:>12,} {e['FileOffset']:#012x} {path}")

    def extract_all(self, outdir, name_filter=None):
        os.makedirs(outdir, exist_ok=True)
        n = 0
        for e in self.entries:
            path = (e['DirName'] + '/' if e['DirName'] else '') + e['FileName']
            if name_filter and name_filter.lower() not in path.lower():
                continue
            if e['FileOffset'] is None or e['FileOffset'] == 0xFFFFFFFFFFFFFFFF:
                continue
            self.f.seek(e['FileOffset'])
            data = self.f.read(e['FileSize'])
            if data[:8] == b'CRILAYLA':
                data = decompress_crilayla(data)
            dst = os.path.join(outdir, path.replace('/', os.sep))
            os.makedirs(os.path.dirname(dst) or outdir, exist_ok=True)
            open(dst, 'wb').write(data)
            n += 1
        print(f'[cpk] extracted {n} files -> {outdir}')
        return n


def decompress_crilayla(input_bytes):
    """CRILAYLA decompress — exact port of CriPakTools CPK.cs (bit-accurate)."""
    uncompressed_size = struct.unpack_from('<I', input_bytes, 8)[0]
    uncompressed_header_offset = struct.unpack_from('<I', input_bytes, 12)[0]
    result = bytearray(uncompressed_size + 0x100)
    result[0:0x100] = input_bytes[uncompressed_header_offset + 0x10:
                                  uncompressed_header_offset + 0x10 + 0x100]
    input_offset = len(input_bytes) - 0x100 - 1
    output_end = 0x100 + uncompressed_size - 1
    state = {'bit_pool': 0, 'bits_left': 0, 'input_offset': input_offset}
    vle_lens = [2, 3, 5, 8]

    def get_bits(n):
        out = 0
        produced = 0
        while produced < n:
            if state['bits_left'] == 0:
                state['bit_pool'] = input_bytes[state['input_offset']]
                state['bits_left'] = 8
                state['input_offset'] -= 1
            take = state['bits_left'] if state['bits_left'] <= (n - produced) else (n - produced)
            out = (out << take) | ((state['bit_pool'] >> (state['bits_left'] - take)) & ((1 << take) - 1))
            state['bits_left'] -= take
            produced += take
        return out

    bytes_output = 0
    while bytes_output < uncompressed_size:
        if get_bits(1) > 0:
            writepos = output_end - bytes_output
            backref = writepos + get_bits(13) + 3
            length = 3
            for level in range(4):
                this_level = get_bits(vle_lens[level])
                length += this_level
                if this_level != (1 << vle_lens[level]) - 1:
                    break
            else:
                while True:
                    this_level = get_bits(8)
                    length += this_level
                    if this_level != 255:
                        break
            for _ in range(length):
                result[output_end - bytes_output] = result[backref]
                backref -= 1
                bytes_output += 1
        else:
            result[output_end - bytes_output] = get_bits(8)
            bytes_output += 1

    return bytes(result)


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'list'
    cpk = CPK(sys.argv[2] if len(sys.argv) > 2 else '/home/z/my-project/apk_lab/cpk/assets/dt270_mobile_all.cpk')
    if mode == 'list':
        cpk.list()
    elif mode == 'extract':
        flt = sys.argv[4] if len(sys.argv) > 4 else None
        cpk.extract_all(sys.argv[3], flt)
