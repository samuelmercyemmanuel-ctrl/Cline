#!/usr/bin/env python3
"""Replay oracle parser + validation for eFootball tutorial .rep/.trep.

.rep (native-proven): 44,400-byte header + 1,200 x 10,976-byte state records.
Record = 808 bytes global/special state + 31 x 328-byte entity blocks.
First 22 entity blocks = the 22 football players.
Player block: +0xB6/+0xB8/+0xBA signed int16 XYZ (value/256); 2nd vector +0xC4/+0xC6/+0xC8.
Ball: three 28-byte slots at global+0x2D4/+0x2F0/+0x30C:
   +0x00..0x0F quaternion, +0x10/12/14 int16 XYZ (/256), +0x16 slot/type, +0x17 player ref, +0x18 flags.
.trep: 12-byte header + 1,200 x 844-byte samples.

Output: apk_lab/analysis/replay_tracks.json
"""
import json, struct, sys
import numpy as np

BASE = '/home/z/my-project/apk_lab/cpk/dt270_out/common/match'
HDR = 44400
REC = 10976
NREC = 1200
GLOB = 808
ENT = 328
NENT = 31
BALL_SLOTS = (0x2D4, 0x2F0, 0x30C)


def parse_rep(path):
    d = open(path, 'rb').read()
    ident = (len(d) == HDR + NREC * REC)
    recs = []
    for i in range(NREC):
        base = HDR + i * REC
        g = d[base:base + GLOB]
        players = []
        for e in range(NENT):
            eb = d[base + GLOB + e * ENT: base + GLOB + (e + 1) * ENT]
            x, y, z = struct.unpack_from('<hhh', eb, 0xB6)
            x2, y2, z2 = struct.unpack_from('<hhh', eb, 0xC4)
            players.append({'pos': (x / 256, y / 256, z / 256), 'vec2': (x2 / 256, y2 / 256, z2 / 256)})
        balls = []
        for so in BALL_SLOTS:
            q = struct.unpack_from('<4h', g, so)          # maybe quat as int16?
            bx, by, bz = struct.unpack_from('<hhh', g, so + 0x10)
            slot_type = g[so + 0x16]
            player_ref = g[so + 0x17]
            flags = struct.unpack_from('<H', g, so + 0x18)[0]
            balls.append({'quat_raw': q, 'pos': (bx / 256, by / 256, bz / 256),
                          'slot': slot_type, 'pref': player_ref, 'flags': flags})
        recs.append({'players': players, 'balls': balls})
    return {'file': path, 'size_identity': ident, 'size': len(d), 'records': recs}


def active_ball(rec):
    """Pick the active ball slot (nonzero position)."""
    for b in rec['balls']:
        if any(abs(c) > 1e-6 for c in b['pos']):
            return b
    return rec['balls'][0]


def main():
    out = {}
    rep_path = f'{BASE}/tutorial_replay/tutorial_replay_shooting_01.rep'
    trep_path = f'{BASE}/tutorial_replay/tutorial_replay_shooting_01.trep'
    r = parse_rep(rep_path)
    print(f'{rep_path}')
    print(f'  size {r["size"]:,} identity={r["size_identity"]} (44,400 + 1,200*10,976 = {44400 + 1200 * 10976:,})')

    # .trep check
    td = open(trep_path, 'rb').read()
    print(f'  .trep size {len(td):,} identity={len(td) == 12 + 1200 * 844} (12 + 1,200*844 = {12 + 1200 * 844:,})')
    print(f'  .trep header: {td[:12].hex(" ")}')

    # ball track
    ball_pos = np.array([active_ball(rec)['pos'] for rec in r['records']])
    ball_pref = [active_ball(rec)['pref'] for rec in r['records']]
    ball_slot = [active_ball(rec)['slot'] for rec in r['records']]
    # find first 30 frames with movement
    moving = np.nonzero((np.abs(np.diff(ball_pos[:, 0])) + np.abs(np.diff(ball_pos[:, 1]))) > 0)[0]
    print(f'\n  ball track: n={len(ball_pos)}, moving frames from {moving[0] if len(moving) else -1}')
    print(f'  ball x range: {ball_pos[:,0].min():.2f}..{ball_pos[:,0].max():.2f}  '
          f'y: {ball_pos[:,1].min():.2f}..{ball_pos[:,1].max():.2f}  z: {ball_pos[:,2].min():.2f}..{ball_pos[:,2].max():.2f}')
    print(f'  ball slot types seen: {sorted(set(ball_slot))[:10]}  player refs seen: {sorted(set(ball_pref))[:10]}')
    # print the moving window
    w0 = max(0, (moving[0] if len(moving) else 0) - 3)
    for i in range(w0, min(w0 + 40, NREC)):
        b = active_ball(r['records'][i])
        print(f'   frame {i:4d}: pos=({b["pos"][0]:8.3f},{b["pos"][1]:8.3f},{b["pos"][2]:8.3f}) '
              f'slot={b["slot"]:3d} pref={b["pref"]:3d} quat={b["quat_raw"]}')

    # player 0 track around the action
    p0 = np.array([rec['players'][0]['pos'] for rec in r['records']])
    print(f'\n  player[0] track: x {p0[:,0].min():.2f}..{p0[:,0].max():.2f}  y {p0[:,1].min():.2f}..{p0[:,1].max():.2f}  z {p0[:,2].min():.2f}..{p0[:,2].max():.2f}')

    out['shooting_01'] = {
        'size_identity': r['size_identity'],
        'trep_identity': len(td) == 12 + 1200 * 844,
        'ball_track': ball_pos.tolist(),
        'ball_pref': ball_pref,
        'ball_slot': ball_slot,
        'player0': p0.tolist(),
    }
    # all identities across corpus
    import glob, os
    ident = {}
    for p in sorted(glob.glob(f'{BASE}/tutorial_replay/*.rep')):
        sz = os.path.getsize(p)
        ident[os.path.basename(p)] = (sz == 13215600)
    out['all_rep_identity'] = ident
    print(f'\n  all .rep files 13,215,600 bytes: {sum(ident.values())}/{len(ident)}')

    json.dump(out, open('/home/z/my-project/apk_lab/analysis/replay_tracks.json', 'w'), indent=1)
    print('JSON -> apk_lab/analysis/replay_tracks.json')


if __name__ == '__main__':
    main()
