#!/usr/bin/env python3
"""Deep .trep decode: map the 844-byte samples onto the command system.

Known (FINDINGS):
  12B header {id, 12, 828} + 1200 x 844B (16B sample hdr + 828 payload)
  shot charge = bits at bytes 196/216 with event bursts in u32 lanes 110-159
  during frames 42-49 (shooting_02); angle lane at byte 156 (0-358 deg)
  command dispatcher 0x6a00e50: [cmd+8] = id 0..0x6c jump table
  message header: +0x68 id u32, class byte +4, kind byte +7
  24 controller slots x 0xB4 = 180B each

This probe:
  1. statistical structure of the 828B payload (which u16 lanes vary)
  2. the 16B sample header decode
  3. correlation with the .rep player/ball activity timeline
  4. candidate command-id fields (small ints at fixed offsets)
"""
import struct
import sys

import numpy as np

BASE = '/home/z/my-project/apk_lab/cpk/dt270_out/common/match/tutorial_replay'


def load_trep(name):
    data = open(f'{BASE}/{name}.trep', 'rb').read()
    hdr = struct.unpack_from('<III', data, 0)
    assert hdr[1] == 12, hdr
    n = (len(data) - 12) // 844
    samples = np.frombuffer(data, dtype=np.uint8, count=n * 844, offset=12)
    samples = samples.reshape(n, 844)
    return hdr, samples


def load_rep(name):
    data = open(f'{BASE}/{name}.rep', 'rb').read()
    n = (len(data) - 44400) // 10976
    recs = np.frombuffer(data, dtype=np.uint8, count=n * 10976, offset=44400)
    return recs.reshape(n, 10976)


def analyze(name):
    print(f'===== {name} =====')
    hdr, samples = load_trep(name)
    print(f'header: id={hdr[0]}, rec_size_field={hdr[2]}, n={len(samples)}')

    # 16B sample header: decode as u32s and u16s
    sh = samples[:, :16]
    u32s = sh.view('<u4').reshape(len(sh), 4)
    print('sample hdr u32[0] first 8:', u32s[:8, 0].tolist())
    print('sample hdr u32[1] first 8:', u32s[:8, 1].tolist())
    print('sample hdr u32[2] first 8:', u32s[:8, 2].tolist())
    print('sample hdr u32[3] first 8:', u32s[:8, 3].tolist())

    # payload lane variance (u16)
    payload = samples[:, 16:]
    u16 = payload.view('<u2').reshape(len(payload), 414)
    const_lanes = np.where(u16.max(0) == u16.min(0))[0]
    var_lanes = np.where(u16.max(0) != u16.min(0))[0]
    print(f'u16 lanes: {len(const_lanes)} constant, {len(var_lanes)} varying')
    print('varying lane indices (byte offsets):',
          [f'{i*2}#{int(u16[0, i])}' for i in var_lanes[:40]])

    # for each varying lane: value range + first change frame
    print('lane detail (offset: min..max, first-change@):')
    for i in var_lanes[:40]:
        col = u16[:, i]
        nz = np.where(col != col[0])[0]
        fc = int(nz[0]) if len(nz) else -1
        print(f'  byte {i*2:3d}: {col.min():5d}..{col.max():5d} '
              f'first_change@{fc:4d} n_changes={len(nz):4d}')

    # byte-level: small ints (command ids are 0..0x6c)
    b = payload
    small_int_lanes = []
    for off in range(0, 828, 1):
        col = b[:, off]
        if col.max() <= 0x70 and col.min() >= 0 and len(np.where(col != col[0])[0]) > 0:
            small_int_lanes.append(off)
    print('small-int (0..0x70) varying byte offsets:', small_int_lanes[:30])
    return samples


def correlate(name, samples):
    """.rep activity timeline: when does the ball start moving?"""
    recs = load_rep(name)
    n = min(len(recs), len(samples))
    # ball slots at global+0x2D4 (28B): pos i16 at +0x10
    ballpos = []
    for i in range(n):
        g = recs[i, :808]
        slot0 = g[0x2D4:0x2D4 + 28]
        x, y, z = struct.unpack_from('<3h', slot0, 0x10)
        ballpos.append((x / 256, y / 256, z / 256))
    ballpos = np.array(ballpos)
    d = np.linalg.norm(np.diff(ballpos, axis=0), axis=1)
    moving = np.where(d > 0.02)[0]
    print(f'.rep ball motion: first moving frame {moving[0] if len(moving) else None}, '
          f'frames moving: {len(moving)}')
    if len(moving):
        print('  motion timeline sample:', [(int(f), round(d[f], 3)) for f in moving[:12]])
    return ballpos, d


if __name__ == '__main__':
    name = 'tutorial_replay_shooting_02'
    s = analyze(name)
    correlate(name, s)
