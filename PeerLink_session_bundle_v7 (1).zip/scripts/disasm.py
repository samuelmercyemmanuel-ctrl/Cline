#!/usr/bin/env python3
"""Capstone-based function dumper for the recovered libUE4.so.

Usage:
  python disasm.py <vaddr> [n_insns]     — linear dump
  python disasm.py -f <vaddr>             — dump until ret-ish tail (heuristic)
Resolves adrp/ldr page globals and bl targets using analysis DBs when available.
"""
import sys
import capstone
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'


class Bin:
    def __init__(self):
        self.f = open(SO, 'rb')
        self.elf = ELFFile(self.f)
        loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
                 for s in self.elf.iter_segments() if s['p_type'] == 'PT_LOAD']
        self.loads = sorted(loads, key=lambda t: t[0])
        self.data = open(SO, 'rb').read()
        self.md = capstone.Cs(capstone.CS_ARCH_ARM64, capstone.CS_MODE_LITTLE_ENDIAN)
        self.md.detail = False

    def read(self, vaddr, n):
        for va, mem, fsz, off in self.loads:
            if va <= vaddr < va + mem:
                fo = off + (vaddr - va)
                return self.data[fo:fo + n]
        raise ValueError(f'unmapped vaddr {vaddr:#x}')

    def dump(self, vaddr, n_insns, resolve=True):
        code = self.read(vaddr, n_insns * 4)
        out = []
        import json, os
        plt = {}
        if resolve and os.path.exists(f'{AN}/plt_map.json'):
            plt = {int(k, 16): v['sym'] for k, v in json.load(open(f'{AN}/plt_map.json')).items()}
        for ins in self.md.disasm(code, vaddr):
            line = f'{ins.address:x}: {ins.mnemonic} {ins.op_str}'.rstrip()
            if resolve:
                # annotate bl targets
                if ins.mnemonic in ('bl', 'b') and ins.op_str.startswith('#'):
                    tgt = int(ins.op_str[1:], 16)
                    if tgt in plt:
                        line += f'   ; PLT {plt[tgt]}'
                # annotate adrp+add/ldr
                if ins.mnemonic == 'adrp':
                    pass
            out.append(line)
        return out


if __name__ == '__main__':
    args = sys.argv[1:]
    b = Bin()
    if args[0] == '-f':
        va = int(args[1], 16)
        n = int(args[2]) if len(args) > 2 else 400
    else:
        va = int(args[0], 16)
        n = int(args[1]) if len(args) > 1 else 120
    for line in b.dump(va, n):
        print(line)
