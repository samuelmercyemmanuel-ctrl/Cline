#!/usr/bin/env python3
"""Vectorized ADRP reference scanner: find all code refs to a target page.

Usage: python adrp_scan2.py <page_hex> [max_hits]
"""
import struct
import sys
import time

import numpy as np

LIB = '/home/z/my-project/apk_lab/libUE4.so'
TEXT_LO = 0x6000000
TEXT_HI = 0x9000000


def scan_page(page):
    t0 = time.time()
    with open(LIB, 'rb') as f:
        blob = f.read()
    text = np.frombuffer(blob[TEXT_LO:TEXT_HI], dtype='<u4').astype(np.uint64)
    pcs = np.arange(TEXT_LO, TEXT_HI, 4, dtype=np.uint64)
    is_adrp = (text & np.uint64(0x9F000000)) == np.uint64(0x90000000)
    imm = ((text >> np.uint64(29)) & np.uint64(3)) | \
          (((text >> np.uint64(5)) & np.uint64(0x7FFFF)) << np.uint64(2))
    imm = np.where(imm & np.uint64(0x100000), imm - np.uint64(0x200000), imm)
    pages = (pcs + (imm << np.uint64(12))) & np.uint64(0xFFFFFFFFFFFFF000)
    sel = is_adrp & (pages == np.uint64(page))
    return pcs[sel].tolist(), time.time() - t0


def main():
    page = int(sys.argv[1], 16)
    hits, dt = scan_page(page)
    print(f'refs to page {page:#x}: {len(hits)}  (scan {dt:.1f}s)')
    blob = open(LIB, 'rb').read()
    for pc in hits:
        ins = []
        for k in range(4):
            i = struct.unpack_from('<I', blob, pc + 4 * k)[0]
            ins.append('%08x' % i)
        print('  %#x: %s' % (pc, ' '.join(ins)))


if __name__ == '__main__':
    main()
