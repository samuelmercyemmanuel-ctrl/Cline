#!/usr/bin/env python3
"""M9c: trace the exact block path through the cmd-4 gate 0x6a0195c."""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22

OUT = '/home/z/my-project/apk_lab/analysis/m9c_gate_path.json'

GATE_LO = 0x6a0195c
GATE_HI = 0x6a02000


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    path = []

    def blk(uc, address, size, ud):
        off = address - core.base
        if GATE_LO <= off < GATE_HI:
            path.append(off)

    core.uc.hook_add(UC_HOOK_BLOCK, blk)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    core._log.clear()
    path.clear()
    before, after, err, pc = world.step()   # step 0: cmd 0
    path.clear()
    for i in range(4):
        before, after, err, pc = world.step()  # cmds 1..4
    # now at cmd 4: trace the NEXT dispatcher call in detail
    path.clear()
    print('--- tracing cmd-4 gate path ---')
    before, after, err, pc = world.step()
    print(f'step: cmd {before:#x} -> {after:#x} err={err}')

    # compress consecutive blocks
    seq = []
    for b in path:
        if not seq or seq[-1] != b:
            seq.append(b)
    print('gate block path (%d blocks):' % len(seq))
    line = []
    for b in seq:
        line.append(f'{b:#x}')
    # print in rows of 8
    for i in range(0, len(line), 8):
        print('  ' + ' '.join(line[i:i + 8]))

    json.dump({'seq': [hex(b) for b in seq], 'cmd_after': after},
              open(OUT, 'w'), indent=1)
    print('JSON ->', OUT)
    return world


if __name__ == '__main__':
    main()
