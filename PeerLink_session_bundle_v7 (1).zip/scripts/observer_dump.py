#!/usr/bin/env python3
"""Dump the observer objects: hook the observer pre-hook (0x6e942c0, called
from observer[0]'s pre-hook) and the observer finish (0x6ea4ca0) to learn the
observer object addresses, then dump their contents - looking for the drag
profile (6 thresholds + 6x12B class table) that feeds the kernel working
state's ladder region."""
import struct
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
from ball_object_run import BallWorld
from unicorn.arm64_const import UC_ARM64_REG_X0

A_PRE = 0x6e942c0
A_FINISH = 0x6ea4ca0


def main():
    world = BallWorld(verbose=False)
    world.construct()
    core = world.core
    seen = {}

    def pre_cb(uc, core_):
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        if x0 not in seen:
            seen[x0] = 'pre 0x6e942c0'

    def fin_cb(uc, core_):
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        if x0 not in seen:
            seen[x0] = 'finish 0x6ea4ca0'

    w1 = core.watch(A_PRE, pre_cb, name='obs_pre')
    w2 = core.watch(A_FINISH, fin_cb, name='obs_fin')
    world.set_N(2)
    world.set_state((0, 3.0, 0), vel=(2.0, 0, 0), phys=1, sub=6)
    world.reset_kernel_ctx()
    world.tick_feedback()
    core.unwatch(w1)
    core.unwatch(w2)

    print(f'observer-ish objects seen: {len(seen)}')
    for addr, how in sorted(seen.items()):
        b = bytes(core.safe_read(addr, 0x130))
        print(f'\n=== {hex(addr)} ({how}) first 0x130 bytes ===')
        for off in range(0, 0x130, 16):
            row = b[off:off+16]
            fl = []
            for i in range(0, 16, 4):
                v = struct.unpack_from('<f', row, i)[0]
                fl.append(f'{v:9.4f}' if v == v and abs(v) < 1e7 else '     .   ')
            print(f'  +{off:03x}: ' + ' '.join(fl))


if __name__ == '__main__':
    main()
