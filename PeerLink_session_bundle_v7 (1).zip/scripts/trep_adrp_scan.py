#!/usr/bin/env python3
"""M5.1e: binary-wide adrp+add decode (numpy) -> exact refs to the 73
replay-path string starts -> containing functions.
"""
import numpy as np
import json

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
data = open(SO, 'rb').read()

from elftools.elf.elffile import ELFFile
f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
loads.sort()

starts = {int(k, 16): v for k, v in json.load(open(f'{AN}/replay_path_strings.json')).items()}
vaset = set(starts)
print(f'{len(vaset)} target strings')

# executable segment(s)
results = []
for va, mem, fsz, fo in loads:
    seg = data[fo:fo + fsz]
    if len(seg) < 0x100000:
        continue
    # quick code sanity: first word should decode as arm64 (skip if data)
    words = np.frombuffer(seg, dtype='<u4')
    # ADRP mask: bits31=1, bits28-24=10000 -> 0x90000000 mask 0x9F000000
    is_adrp = (words & 0x9F000000) == 0x90000000
    print(f'segment {va:#x} size {len(seg)/1e6:.1f}MB adrp={is_adrp.sum()}')
    idxs = np.nonzero(is_adrp)[0]
    for wi in idxs:
        w = int(words[wi])
        rd = w & 0x1F
        immlo = (w >> 29) & 3
        immhi = (w >> 5) & 0x7FFFF
        imm = (immhi << 2) | immlo
        if imm & 0x100000:  # sign bit (21-bit)
            imm -= 1 << 21
        pc = va + wi * 4
        page = (pc & ~0xFFF) + (imm << 12)
        # next word: ADD X(rd), X(rd), #imm12 (sf=1)
        if wi + 1 >= len(words):
            continue
        w2 = int(words[wi + 1])
        if (w2 & 0xFF800000) == 0x91000000:
            rd2 = w2 & 0x1F
            rn = (w2 >> 5) & 0x1F
            imm12 = (w2 >> 10) & 0xFFF
            shift = (w2 >> 22) & 3
            if rn == rd:  # add x?, x(rd), #imm — base feeds from adrp
                target = page + (imm12 << (12 if shift else 0))
                if target in vaset:
                    print(f'  REF {pc:#x} -> {target:#x} {starts[target]!r}')
                    results.append({'site': hex(pc), 'target': hex(target),
                                    'str': starts[target]})
print('done')
json.dump(results, open(f'{AN}/replay_adrp_refs.json', 'w'), indent=1)
print(f'{len(results)} refs -> replay_adrp_refs.json')
