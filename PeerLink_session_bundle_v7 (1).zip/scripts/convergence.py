#!/usr/bin/env python3
"""Function-level call graph + convergence analysis to locate the match tick.

Builds:
  - function entry list (BL targets ∪ vectorized prologue scan)
  - function-level edges (func -> callee)
  - reverse reachability from gameplay seeds
  - tick candidates = functions that call timestep provider (27.0) AND
    transitively reach the ball update chain AND the replay serializers

Output: apk_lab/analysis/fgraph.npz + tick_candidates.json
"""
import json, os
import numpy as np
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'], offset=seg['p_offset'],
                          perms=('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')))
TEXT = [l for l in loads if 'x' in l['perms']][0]
TEXT_VA, TEXT_SZ = TEXT['vaddr'], TEXT['filesz']
f.seek(TEXT['offset'])
W = np.frombuffer(f.read(TEXT_SZ), dtype='<u4')
N = len(W)
pc = (np.arange(N, dtype=np.uint64) * 4 + TEXT_VA)

# ---- prologue scan (vectorized) ----
stp_x29x30 = (W & 0xFFC07FFF) == 0xA9807BFD     # stp x29, x30, [sp, #imm]!
sub_sp     = (W & 0xFF00FFFF) == 0xD10003FF     # sub sp, sp, #imm
prev_ret   = np.zeros(N, dtype=bool)
if N > 1:
    prev_ret[1:] = np.isin(W[:-1], (0xD65F03C0, 0xD503201F)) | ((W[:-1] & 0xFC000000) == 0x14000000)
cand = (stp_x29x30 | sub_sp) & prev_ret
prologue_entries = pc[cand]
print(f'prologue candidates: {len(prologue_entries):,}')

# ---- BL edges ----
bl = np.load(f'{AN}/bl_map.npz')
bl_site, bl_target = bl['bl_site'], bl['bl_target']
blt_entries = np.unique(bl_target)
print(f'BL target entries: {len(blt_entries):,}')

entries = np.union1d(np.sort(prologue_entries), np.sort(blt_entries))
print(f'combined entries: {len(entries):,}')

# ---- attribute BL sites to functions (searchsorted) ----
fi = np.searchsorted(entries, bl_site, 'right') - 1
valid = fi >= 0
src_func = entries[fi[valid]]
callee = bl_target[valid]
# dedupe edges
edges = np.unique(np.stack([src_func, callee]), axis=1) if len(src_func) else np.zeros((0, 2))
print(f'function-level edges: {edges.shape[1]:,}')
np.savez_compressed(f'{AN}/fgraph.npz', entries=entries, src=edges[0], dst=edges[1])

# ---- graph helpers (CSR) ----
src, dst = edges[0], edges[1]
o = np.argsort(src, kind='stable')
src_s, dst_s = src[o], dst[o]
indptr = np.searchsorted(src_s, entries, 'right') - np.searchsorted(src_s, entries, 'left')

def callees(fn):
    i = np.searchsorted(entries, fn)
    lo = np.searchsorted(src_s, fn, 'left')
    hi = np.searchsorted(src_s, fn, 'right')
    return set(dst_s[lo:hi].tolist())

# reverse edges
o2 = np.argsort(dst, kind='stable')
dst_t, src_t = dst[o2], src[o2]

def callers(fn):
    lo = np.searchsorted(dst_t, fn, 'left')
    hi = np.searchsorted(dst_t, fn, 'right')
    return set(src_t[lo:hi].tolist())

def reverse_closure(seed_set, max_nodes=200000):
    """All functions that can reach any seed (following call edges backward from seeds' callers... actually
    forward-closure from X to seeds == reverse BFS from seeds along caller edges)."""
    seen = set(seed_set)
    frontier = list(seed_set)
    while frontier and len(seen) < max_nodes:
        nxt = []
        for fn in frontier:
            for c in callers(fn):
                if c not in seen:
                    seen.add(c)
                    nxt.append(c)
                    if len(seen) >= max_nodes:
                        break
        frontier = nxt
    return seen

# ---- seeds ----
SEEDS_BALL = {0x6ea1e90, 0x6ea20fc, 0x6ea0958, 0x6e938a0}      # ball update chain
SEEDS_REPLAY = {0x6f45bc4, 0x6e94aa4, 0x728d7e0, 0x728d930}    # replay serializers
TS = 0x6813eb8

R_ball = reverse_closure(SEEDS_BALL)
R_replay = reverse_closure(SEEDS_REPLAY)
R_ts = reverse_closure({TS})
print(f'reverse closure sizes: ball={len(R_ball):,} replay={len(R_replay):,} ts={len(R_ts):,}')

common = R_ball & R_replay & R_ts
print(f'CONVERGENCE (ball ∩ replay ∩ ts): {len(common):,} functions')

# rank by: number of seeds' descendants called + few callers (top of loop) + size
scored = []
for fn in common:
    cs = callers(fn)
    scored.append((len(cs), fn))
scored.sort()
print('\n=== TICK CANDIDATES (fewest callers first = top of loop) ===')
for n_callers, fn in scored[:40]:
    i = np.searchsorted(entries, fn)
    nxt = entries[i + 1] if i + 1 < len(entries) else TEXT_VA + TEXT_SZ
    sz = min(nxt - fn, 0x20000)
    cl = callees(fn)
    hits_ball = bool(cl & {0x6e938a0, 0x6ea1e90, 0x6ea20fc, 0x6ea0958, 0x6e92bf0})
    hits_replay = bool(cl & {0x6f45bc4, 0x6e94aa4, 0x728d7e0, 0x728d930})
    hits_ts = TS in cl
    print(f'  {fn:#x} callers={n_callers:<3} size~{sz:<7,} callees={len(cl):<4} '
          f'ball={hits_ball} replay={hits_replay} ts={hits_ts} '
          f'callers={[hex(c) for c in list(cs)[:5]]}')

json.dump({'common': [int(x) for x in common],
           'ranked': [{'func': int(fn), 'n_callers': int(nc)} for nc, fn in scored[:200]]},
          open(f'{AN}/tick_candidates.json', 'w'), indent=1)
print('\nJSON ->', f'{AN}/tick_candidates.json')
