#!/usr/bin/env python3
"""M5g: install the SPIN from .rep quaternion derivative + airRegist at
params+8 (the game's real offset), then run the clean flight window.

The .rep quat per frame gives the ball's orientation; the per-frame
rotation delta = angular displacement -> angular velocity (state+0x18).
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import BallWorld, rd_state, state_vec, STATE_SZ
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m5g_flight_spin.json'
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_CONT_TICK = 0x6e92ce8
A_RECORDER_WRITE = 0x6a6b604
F_FIRST, F_CLEAN_END = 48, 80


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'quat': np.array(q), 'pos': (x / 256, y / 256, z / 256)}


def quat_to_rot(q0, q1, dt):
    """angular velocity from q0 -> q1 (w,x,y,z order assumed from file)."""
    q0c = q0 / np.linalg.norm(q0)
    q1c = q1 / np.linalg.norm(q1)
    # relative rotation dq = q1 * conj(q0)
    w0, x0, y0, z0 = q0c
    w1, x1, y1, z1 = q1c
    # conj(q0)
    qc = np.array([w0, -x0, -y0, -z0])
    # q1 * qc (hamilton product)
    w, x, y, z = q1c
    qw, qx, qy, qz = qc
    dq = np.array([
        w * qw - x * qx - y * qy - z * qz,
        w * qx + x * qw + y * qz - z * qy,
        w * qy - x * qz + y * qw + z * qx,
        w * qz + x * qy - y * qx + z * qw,
    ])
    if dq[0] < 0:
        dq = -dq
    angle = 2 * np.arccos(np.clip(dq[0], -1, 1))
    if angle < 1e-9:
        return np.zeros(3)
    axis = dq[1:] / np.sin(angle / 2)
    return axis * (angle / dt)


def main():
    oracle = {f: rep_slot0(f) for f in range(F_FIRST, F_CLEAN_END + 2)}
    o48 = oracle[F_FIRST]
    p48 = o48['pos']
    p49 = oracle[F_FIRST + 1]['pos']
    v_imp = tuple((np.array(p49) - np.array(p48)) * 27.0)
    v0 = (v_imp[0], v_imp[1] + 9.80665 / 27.0, v_imp[2])
    rot0 = quat_to_rot(o48['quat'], oracle[F_FIRST + 1]['quat'], 1 / 27.0)
    print(f'v0={tuple(round(v,2) for v in v0)}')
    print(f'rot0 (from quat derivative) = {tuple(round(r,2) for r in rot0)} '
          f'rad/s, |w|={np.linalg.norm(rot0):.1f}')

    world = BallWorld(verbose=True)
    world.construct()
    modA = world.ball
    core = world.core
    world.set_N(3)

    def install(V0, ROT, mode, air):
        s = bytearray(STATE_SZ)
        struct.pack_into('<3f', s, 0x000, *p48)
        struct.pack_into('<3f', s, 0x00C, *V0)
        struct.pack_into('<3f', s, 0x018, *ROT)
        s[0x90] = 1
        s[0x91] = 6
        struct.pack_into('<4f', s, 0x098, *o48['quat'])
        struct.pack_into('<i', s, 0x08C, mode)
        core.uc.mem_write(modA + 0x158, bytes(s))
        core.write_u64(modA + 0x2F8, 0)
        core.write_u32(modA + 0x8, 0)
        core.uc.mem_write(world.params + 8, struct.pack('<f', air))

    recs = []

    def wcb(uc, _):
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        src = core.safe_read(x2, 0x1C) if x2 else b''
        recs.append(src)

    n = F_CLEAN_END - F_FIRST
    variants = []
    # sweep small airRegist adjustments around 0.399 (spin changes drag)
    for name, air in [('air0.399', 0.399), ('air0.35', 0.35),
                      ('air0.45', 0.45), ('air0.30', 0.30)]:
        install(v0, rot0, 8, air)
        recs.clear()
        wk = core.watch(A_RECORDER_WRITE, wcb, name='rec')
        rows = []
        for k in range(n):
            r = core.call(A_CONT_TICK, x0=modA, s0=1.0, w1=0)
            assert not r['error'], r
            rows.append(state_vec(rd_state(core, modA + 0x158)))
        core.unwatch(wk)
        errs = np.array([np.array(rows[i]) -
                         np.array(oracle[F_FIRST + 1 + i]['pos'])
                         for i in range(n)])
        rms = float(np.sqrt((errs ** 2).sum(axis=1).mean()))
        maxe = float(np.abs(errs).max())
        nq = sum(1 for i in range(n)
                 if [int(round(v * 256)) for v in rows[i]] ==
                 [int(round(v * 256)) for v in oracle[F_FIRST + 1 + i]['pos']])
        variants.append({'name': name, 'air': air, 'rms_m': rms,
                         'max_err_m': maxe, 'exact_i16': nq})
        print(f'[{name}] rms={rms*100:.2f}cm max={maxe*100:.1f}cm '
              f'exact16={nq}/{n}')
        for fi in (1, 5, 10, 20, 31):
            if fi < n:
                e = errs[fi]
                print(f'   f{F_FIRST+1+fi}: err=({e[0]:+.3f},{e[1]:+.3f},{e[2]:+.3f})')

    json.dump({'variants': variants, 'v0': v0, 'rot0': rot0.tolist()},
              open(OUT, 'w'), indent=1, default=float)
    print(f'JSON -> {OUT}')


if __name__ == '__main__':
    main()
