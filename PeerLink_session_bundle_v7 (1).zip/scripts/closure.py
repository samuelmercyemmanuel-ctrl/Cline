#!/usr/bin/env python3
"""Transitive dependency closure of the ball kernel 0x6ea0958 (and chain_mid).

BFS over BL edges from the seed; classify:
  - internal functions reached (KEEP)
  - PLT stubs called (IMPORT list with names from plt_map.json)
  - indirect BLR sites inside the closure (needs runtime resolution)
  - data refs (globals) touched

Output: apk_lab/analysis/kernel_closure.json
"""
import json, os
import numpy as np
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], perms=('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')))
TEXT = [l for l in loads if 'x' in l['perms']][0]
TV, TSZ = TEXT['vaddr'], TEXT['filesz']
PLT = elf.get_section_by_name('.plt')
PLT_LO, PLT_HI = PLT['sh_addr'], PLT['sh_addr'] + PLT['sh_size']
print(f'PLT range: {PLT_LO:#x}-{PLT_HI:#x}')

bl = np.load(f'{AN}/bl_map.npz')
bl_site, bl_target = bl['bl_site'], bl['bl_target']
entries = np.sort(np.unique(bl_target))

# function-level edges
fi = np.searchsorted(entries, bl_site, 'right') - 1
ok = fi >= 0
srcf = entries[fi[ok]]
callee = bl_target[ok]
edge = np.unique(np.stack([srcf, callee]), axis=1)
src_s, dst_s = edge[0], edge[1]
os_ = np.argsort(src_s)
src_sorted, dst_sorted = src_s[os_], dst_s[os_]

def func_callees(fn):
    lo = np.searchsorted(src_sorted, fn, 'left')
    hi = np.searchsorted(src_sorted, fn, 'right')
    return dst_sorted[lo:hi]

plt_map = {int(k, 16): v for k, v in json.load(open(f'{AN}/plt_map.json')).items()}

def closure(seed):
    seen = set([seed])
    frontier = [seed]
    imports = {}
    while frontier:
        nxt = []
        for fn in frontier:
            for c in func_callees(fn).tolist():
                if PLT_LO <= c < PLT_HI:
                    info = plt_map.get(c, {'sym': f'stub_{c:#x}', 'internal': False})
                    imports.setdefault(c, info)
                elif c not in seen:
                    seen.add(c)
                    nxt.append(c)
        frontier = nxt
    return seen, imports

for name, seed in [('ball_kernel', 0x6ea0958), ('ball_chain_mid', 0x6ea20fc)]:
    fns, imports = closure(seed)
    sizes = []
    for fn in fns:
        i = np.searchsorted(entries, fn)
        nxt = entries[i + 1] if i + 1 < len(entries) else TV + TSZ
        sizes.append(min(nxt - fn, 0x20000))
    total = sum(sizes)
    print(f'\n=== {name} closure: {len(fns):,} functions, ~{total:,} bytes of code ===')
    print(f'imports (PLT): {len(imports)}')
    for a, info in sorted(imports.items()):
        tag = 'INTERNAL' if info.get('internal') else 'IMPORT  '
        print(f'  {a:#x} {tag} {info["sym"]}')
    json.dump({'seed': hex(seed), 'n_funcs': len(fns),
               'functions': [hex(x) for x in sorted(fns)],
               'code_bytes': int(total),
               'imports': {hex(a): i for a, i in sorted(imports.items())}},
              open(f'{AN}/closure_{name}.json', 'w'), indent=1)

print('\nJSONs ->', AN)
