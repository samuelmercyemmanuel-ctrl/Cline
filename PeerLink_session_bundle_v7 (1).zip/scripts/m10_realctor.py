#!/usr/bin/env python3
"""MILESTONE 10: REAL inner-core construction + full sequencer drive.

THE DISCOVERY (this session):
  0x69ff76c = Konami's REAL inner-core constructor (called from the outer
  match ctor at 0x6992ee0). It installs:
    [core] = 0x978cf60  (the listener vtable: vt[+0x10] = the dispatcher
                          0x6a00e50 itself!)
    0x69ffc80(core+8)              cmd state
    0x71f8614(core+0x128)          the team-data base (hubs at
                                   +0x3620 + side*0x50)
    0x68aea7c..0x68d3464           all ctrl/team hubs WITH REAL VTABLES
    the 22-slot table + 0x3bd8 readiness + 0x101 ids

  The cmd-4 gate bail (M9's real blocker): the cmd-0 handler RELEASES
  [inner+0x3868+0x40] (0x68b69a8 from 0x68b69c8) before cmd 4 ever runs.
  Harness fix: re-plug the ctrl pointers before each dispatcher call.

  cmd 5's blocker: teamdata_get(inner+0x3748) with [X]=0 (no vtable) ->
  create path crashes. THE REAL FIX: 0x69ff76c installs the vtables.

This harness:
  1. bootstrap (JNI_OnLoad + init_array 15 + registry + guard array)
  2. CALL THE REAL 0x69ff76c(inner, 0)
  3. cmd = 0, drive the sequencer (ctrl replug + fault logging)
  4. watch 0x6a027f8 (per-player constructions, cmds 8+)
"""
import json
import os
import struct
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22

OUT = '/home/z/my-project/apk_lab/analysis/m10_realctor.json'

A_INNER_CTOR = 0x69ff76c
A_DISPATCH = 0x6a00e50
A_PLAYER_CTOR2 = 0x6a027f8
A_CONSTRUCTION = 0x6a02000

TRACE_FNS = {
    0x69ff76c: 'inner_ctor',
    0x6a0195c: 'gate',
    0x70c1c00: 'db_query',
    0x70c37f0: 'teamdb_ctor',
    0x6993afc: 'player_ctor',
    0x6a02000: 'construction_driver',
    0x6a027f8: 'player_ctor2',
    0x71e1ea8: 'extra_ctor_C0',
    0x6fbc05c: 'extra_ctor_E0',
    0x6fa6f5c: 'extra_ctor_D8',
}


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    events = []

    def hook_fn(addr, name):
        def h(uc, address, size, ud):
            events.append({'fn': name,
                           'x0': hex(uc.reg_read(UC_ARM64_REG_X0)),
                           'x1': hex(uc.reg_read(UC_ARM64_REG_X1)),
                           'x2': hex(uc.reg_read(UC_ARM64_REG_X2)),
                           'cmd': core.safe_read_u32(inner + 8)})
        return h

    for addr, name in TRACE_FNS.items():
        core.uc.hook_add(UC_HOOK_CODE, hook_fn(addr, name),
                         begin=core.base + addr, end=core.base + addr + 4)

    faults = []

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        faults.append({'type': int(type_), 'addr': address,
                       'pc': pc - core.base,
                       'cmd': core.safe_read_u32(inner + 8),
                       'x0': uc.reg_read(UC_ARM64_REG_X0),
                       'lr': uc.reg_read(UC_ARM64_REG_LR) - core.base})
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    # -- bootstrap ---------------------------------------------------------
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    # -- THE REAL INNER-CORE CONSTRUCTOR -----------------------------------
    print('--- calling REAL inner ctor 0x69ff76c ---')
    events.clear()
    faults.clear()
    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=120,
                  max_insns=100_000_000)
    print('inner ctor err:', r['error'], 'pc:', r['pc'])
    vt = core.safe_read_u64(inner)
    print(f'[inner] vtable = {vt:#x}  (expect {core.base + 0x978cf60:#x})')
    vt10 = core.safe_read_u64(vt + 0x10) if vt else 0
    print(f'[inner] vt[+0x10] = {vt10 - core.base:#x} '
          f'(expect 0x6a00e50 = the dispatcher)')
    for off in (0x3818, 0x3868, 0x3958, 0x39a8, 0x39f8, 0x3a48, 0x3a98,
                0x3b88):
        v = core.safe_read_u64(inner + off)
        v8 = core.safe_read(inner + off + 8, 1)[0]
        v40 = core.safe_read_u64(inner + off + 0x40)
        print(f'  inner+{off:#x}: vt={v - core.base:#x} '
              f'valid={v8} cached={v40:#x}')
    # team-data hubs inside +0x128 base
    for side in (0, 1):
        X = inner + 0x128 + 0x3620 + side * 0x50
        v = core.safe_read_u64(X)
        print(f'  teamdata hub side{side} (inner+{0x128+0x3620+side*0x50:#x}): '
              f'vt={v - core.base:#x}' if v else
              f'  teamdata hub side{side}: vt=0')

    # -- restart the command at 0 ------------------------------------------
    core.write_u32(inner + 8, 0)

    def replug():
        # cmd-0's handler releases these; the gate needs them non-NULL
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    # -- DRIVE ---------------------------------------------------------------
    replug()
    hist = []
    print('--- driving the sequencer ---')
    for i in range(40):
        events.append({'fn': 'STEP', 'x0': i, 'x1': 0, 'x2': 0, 'cmd': -1})
        faults.clear()
        before, after, err, pc = world.step(timeout_s=120)
        replug()
        n = sum(1 for p in slots22(core, inner) if p)
        extras = [core.safe_read_u64(inner + 0xC0 + j * 8) for j in range(4)]
        n_ex = sum(1 for e in extras if e)
        hist.append({'step': i, 'cmd': before, 'next': after, 'err': err,
                     'slots22': n, 'extras': n_ex,
                     'faults': list(faults[-3:])})
        print(f'step {i:2d}: cmd {before:#04x} -> {after:#04x} err={err} '
              f'slots={n}/22 extras={n_ex}/4'
              + (f' fault={faults[-1]}' if faults else ''))

    c = Counter(e['fn'] for e in events)
    print('--- call counts ---')
    for k, v in c.most_common():
        print(f'  {k:20s} {v}')
    pc2 = [e for e in events if e['fn'] == 'player_ctor2']
    print(f'player_ctor2 (0x6a027f8) events: {len(pc2)}')
    for e in pc2[:30]:
        print('   ', e['x0'], 'side=', e['x1'], 'slot=', e['x2'])

    json.dump({'inner_ctor': {'err': r['error'], 'vt': hex(vt)},
               'history': hist, 'counts': dict(c),
               'player_ctor2': pc2[:100], 'events': events[-800:]},
              open(OUT, 'w'), indent=1, default=str)
    print('JSON ->', OUT)
    return world


if __name__ == '__main__':
    main()
