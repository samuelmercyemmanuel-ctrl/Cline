#!/usr/bin/env python3
"""M10o: trace the cmd-5 fault: who is the NULL subscriber?"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22
from m10_realctor import A_INNER_CTOR

SUBS = [0x6a04b04, 0x6a04b0c, 0x6a04c54, 0x6a0527c, 0x6a05358, 0x6a055c4]


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    state = {'sub': None, 'path': []}

    def sub_hook(uc, address, size, ud):
        state['sub'] = address - core.base

    for a in SUBS:
        core.uc.hook_add(UC_HOOK_CODE, sub_hook,
                         begin=core.base + a, end=core.base + a + 4)

    def at_938(uc, address, size, ud):
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        m18 = core.safe_read_u64(x0 + 0x18)
        vt = core.safe_read_u64(x0)
        if not m18:
            print(f'0x66fd938 entry: x0={x0:#x} vt={vt - core.base:#x} '
                  f'[x0+0x18]=NULL sub={state["sub"]:#x}')

    core.uc.hook_add(UC_HOOK_CODE, at_938,
                     begin=core.base + 0x66fd938, end=core.base + 0x66fd938 + 4)

    def blk(uc, address, size, ud):
        off = address - core.base
        if 0x66fe600 <= off <= 0x66fe800:
            state['path'].append(off)

    core.uc.hook_add(UC_HOOK_BLOCK, blk)

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        print(f'  FAULT type={type_} addr={address:#x} pc={pc-core.base:#x}')
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    core.uc.mem_write(core.base + 0x68a0f30, struct.pack('<I', 0xD503201F))
    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    r = core.call(0x68a7a5c, timeout_s=120, max_insns=200_000_000)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)
    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=300,
                  max_insns=1_000_000_000)
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(9):
        before, after, err, pc = world.step(timeout_s=240)
        replug()
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err}')
        if i == 8:
            state['path'].clear()
    # one more step at cmd 5 with path
    before, after, err, pc = world.step(timeout_s=240)
    replug()
    print(f'step: cmd {before:#x} -> {after:#x} err={err}')
    print('router path:', ' '.join(hex(b) for b in state['path'][-20:]))


if __name__ == '__main__':
    main()
