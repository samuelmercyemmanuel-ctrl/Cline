#!/usr/bin/env python3
"""M10g: find WHERE the construction driver unwinds to RET_TRAP."""
import os
import sys
from collections import deque

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22
from m10_realctor import A_INNER_CTOR, A_DISPATCH


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    last_blocks = deque(maxlen=40)

    def blk(uc, address, size, ud):
        last_blocks.append(address - core.base)

    core.uc.hook_add(UC_HOOK_BLOCK, blk)

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        print(f'  FAULT type={type_} addr={address:#x} pc={pc-core.base:#x}')
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    r = core.call(A_INNER_CTOR, x0=inner, w1=0, timeout_s=300,
                  max_insns=1_000_000_000)
    print('inner ctor err:', r['error'], 'stop pc:', r['pc'] - core.base
          if r['pc'] else None)
    core.write_u32(inner + 8, 0)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(5):
        before, after, err, pc = world.step(timeout_s=120)
        replug()
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err} '
              f'stop_pc={(pc - core.base) if pc else None}')

    print('--- step 5: capture stop ---')
    last_blocks.clear()
    r = core.call(A_DISPATCH, x0=inner, x1=world.msg,
                  timeout_s=300, max_insns=1_000_000_000)
    replug()
    print(f'stop pc = {r["pc"]:#x} (off {r["pc"]-core.base:#x}) err={r["error"]}')
    print('last blocks:')
    print('  ' + ' '.join(f'{b:#x}' for b in last_blocks))


if __name__ == '__main__':
    main()
