#!/usr/bin/env python3
"""Add B (unconditional branch) tail-call edges to the function graph.

ARM64 compilers emit `b target` as a tail call; the BL-only graph is missing
these. Also validates reloc-addend semantics against known ctor addresses.

Builds fgraph2.npz: entries + BL edges + B edges (target must be a known
entry, source must be a DIFFERENT function => inter-function tail call).
"""
import numpy as np
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

f = open(SO, 'rb')
elf = ELFFile(f)
TEXT = None
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD' and (seg['p_flags'] & 1):
        TEXT = seg
TEXT_VA, TEXT_SZ, TEXT_OFF = TEXT['p_vaddr'], TEXT['p_filesz'], TEXT['p_offset']
f.seek(TEXT_OFF)
W = np.frombuffer(f.read(TEXT_SZ), dtype='<u4').copy()
N = len(W)
pc = (np.arange(N, dtype=np.int64) * 4 + TEXT_VA)

# ---- unconditional B: 000101 imm26 ----
b_mask = (W & 0x7C000000) == 0x14000000
b_idx = np.nonzero(b_mask)[0]
imm26 = (W[b_idx] & 0x03FFFFFF).astype(np.int64)
imm26 = np.where(imm26 >= (1 << 25), imm26 - (1 << 26), imm26)
b_target = (pc[b_idx] + imm26 * 4).astype(np.int64)
valid = (b_target >= TEXT_VA) & (b_target < TEXT_VA + TEXT_SZ)
b_site, b_target = pc[b_idx][valid], b_target[valid]
print(f'B (unconditional): {len(b_site):,} (in-range {len(b_site):,})')

fg = np.load(f'{AN}/fgraph.npz')
entries = np.sort(fg['entries'].astype(np.int64))
bl_edges_src = fg['src'].astype(np.int64)
bl_edges_dst = fg['dst'].astype(np.int64)

# attribute B sites to functions
fi = np.searchsorted(entries, b_site, 'right') - 1
ok = fi >= 0
b_src_func = entries[fi[ok]]
b_callee = b_target[ok]
# inter-function only: callee != containing function
inter = b_callee != b_src_func
# callee must be a known entry
is_entry = entries[np.searchsorted(entries, b_callee[inter])] == b_callee[inter]
b_src_func, b_callee = b_src_func[inter][is_entry], b_callee[inter][is_entry]
print(f'B tail-call edges (inter-function, entry-target): {len(b_src_func):,}')

# merge
src = np.concatenate([bl_edges_src, b_src_func])
dst = np.concatenate([bl_edges_dst, b_callee])
edges = np.unique(np.stack([src, dst]), axis=1)
print(f'combined edges: {edges.shape[1]:,} (was BL-only {len(bl_edges_src):,})')
np.savez_compressed(f'{AN}/fgraph2.npz', entries=entries, src=edges[0], dst=edges[1])

# ---- quick queries: did the wall break? ----
order = np.argsort(dst)
d_sorted, s_sorted = dst[order], src[order]


def callers_of(fn):
    i, j = np.searchsorted(d_sorted, fn, 'left'), np.searchsorted(d_sorted, fn, 'right')
    return np.unique(s_sorted[i:j])


print('\n=== NEW CALLERS (BL+B) ===')
for name, va in [('ball_update_entry', 0x6e938a0), ('driven_driver', 0x6a35688),
                 ('driver_A', 0x6a35978), ('driver_B', 0x6a359f4),
                 ('driver_C', 0x6a36a64), ('driver_D', 0x6a37c7c),
                 ('ball_construction', 0x6a35434), ('player_replay_writer', 0x728d7e0)]:
    cs = callers_of(va)
    print(f'  {name} {va:#x}: {[hex(c) for c in cs.tolist()[:15]]}')

# ---- validate reloc addend semantics ----
pr = np.load(f'{AN}/packed_relocs.npz')
radd = pr['addend'].astype(np.int64)


def slots_for(fn):
    return np.nonzero(radd == fn)[0]


for name, va in [('ball_base_ctor 6e92768', 0x6e92768), ('ball_module_ctor 6e91da8', 0x6e91da8),
                 ('ball_ctor_6e91de4', 0x6e91de4), ('kernel 6ea0958', 0x6ea0958),
                 ('timestep_provider 6813eb8', 0x6813eb8)]:
    print(f'reloc slots for {name}: {len(slots_for(va))}')
