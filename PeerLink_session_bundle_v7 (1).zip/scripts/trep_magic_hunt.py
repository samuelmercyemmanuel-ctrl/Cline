#!/usr/bin/env python3
"""M5.1g: hunt the .erep/.trep parser by magic + header-constant patterns.
- 'DSSM' magic (0x4453534d)
- header fields: u32[1]==12, u32[2]==828 (0x33c) near each other
- also 0x34c (844) / 0x4b0 (1200) near 0x33c
"""
import numpy as np
import json

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
data = open(SO, 'rb').read()

from elftools.elf.elffile import ELFFile
f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
loads.sort()

entries = np.load(f'{AN}/fgraph2.npz', allow_pickle=True)['entries']
entries.sort()


def func_of(a):
    i = np.searchsorted(entries, a, 'right') - 1
    return int(entries[i])


hits = {0x4453534D: [], 12: [], 0x33C: [], 0x34C: []}
for va, mem, fsz, fo in loads:
    seg = data[fo:fo + fsz]
    if len(seg) < 0x100000:
        continue
    words = np.frombuffer(seg, dtype='<u4')
    pc_base = va
    # movz/movk pairs and cmp imm12 with the magic
    # 1) cmp w, #0x33c  (subs imm, rd=xzr)
    cmpw = (words & 0xFF000000) == 0x71000000
    cmp_imm = (words >> 10) & 0xFFF
    cmp_rd = words & 0x1F
    for tgt in (12, 0x33C, 0x34C, 0x4B0):
        m = cmpw & (cmp_imm == tgt) & (cmp_rd == 0x1F)
        for wi in np.nonzero(m)[0]:
            hits.setdefault(tgt, []).append(pc_base + int(wi) * 4)
    # 2) movz w, #0x4453534d? too big for imm16; movk+movz combos — search
    #    'DSSM' bytes as literal data too
    # 3) literal pool: search for 4d 53 53 44 in .text (literal constants)
    lit = np.frombuffer(seg, dtype='<u4')
    m = lit == 0x4453534D
    for wi in np.nonzero(m)[0]:
        hits[0x4453534D].append(pc_base + int(wi) * 4)

# combine: functions with BOTH a #12 cmp and #0x33c cmp
f12 = {func_of(p) for p in hits[12]}
f33c = {func_of(p) for p in hits[0x33C]}
f34c = {func_of(p) for p in hits[0x34C]}
f4b0 = {func_of(p) for p in hits.get(0x4B0, [])}
fmagic = {func_of(p) for p in hits[0x4453534D]}

print(f'cmp#12: {len(f12)} fns; cmp#0x33c: {len(f33c)} fns; cmp#0x34c: {len(f34c)} fns; cmp#0x4b0: {len(f4b0)} fns')
print(f'DSSM literals: {len(hits[0x4453534D])} sites in fns {sorted(hex(f) for f in fmagic)[:10]}')

both = f12 & f33c
print(f'\nfunctions with BOTH cmp#12 and cmp#0x33c: {sorted(hex(f) for f in both)}')
both2 = f33c & f34c
print(f'functions with cmp#0x33c AND cmp#0x34c: {sorted(hex(f) for f in both2)}')
both3 = f33c & f4b0
print(f'functions with cmp#0x33c AND cmp#0x4b0: {sorted(hex(f) for f in both3)}')

json.dump({hex(k): [hex(p) for p in v] for k, v in hits.items()},
          open(f'{AN}/trep_parser_hits.json', 'w'), indent=1)
print('\nJSON -> trep_parser_hits.json')
