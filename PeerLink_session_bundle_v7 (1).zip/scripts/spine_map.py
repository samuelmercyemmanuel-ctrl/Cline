#!/usr/bin/env python3
"""M4: enumerate the playing-state handler's module updates + closure funnel.

0x69919e0 = the 'playing' state handler (the per-frame match update).
1. Dump its full callee structure (BL+B, levels).
2. Find sibling 'update module' wrappers (ldr x0,[x0,#off]; cbz; bl driver).
3. Compute downward closure from the spine top (0x69917d8) — funnel numbers:
   total functions, code bytes, PLT imports (render/audio/UI share).
"""
import json
import numpy as np
from collections import deque

AN = '/home/z/my-project/apk_lab/analysis'
fg = np.load(f'{AN}/fgraph2.npz')
ent = np.sort(fg['entries'].astype(np.int64))
src = fg['src'].astype(np.int64)
dst = fg['dst'].astype(np.int64)
order = np.argsort(src)
f_sorted, t_sorted = src[order], dst[order]
o2 = np.argsort(dst)
d_sorted, s_sorted = dst[o2], src[o2]


def callees_of(f):
    i, j = np.searchsorted(f_sorted, f, 'left'), np.searchsorted(f_sorted, f, 'right')
    return np.unique(t_sorted[i:j]).tolist()


def callers_of(f):
    i, j = np.searchsorted(d_sorted, f, 'left'), np.searchsorted(d_sorted, f, 'right')
    return np.unique(s_sorted[i:j]).tolist()


# ---- 1. callees of the playing-state handler ----
print('=== CALLEES OF 0x69919e0 (playing state handler) ===')
L1 = callees_of(0x69919e0)
print(f'{len(L1)} direct callees:')
for c in sorted(L1):
    i = np.searchsorted(ent, c)
    nxt = ent[i + 1] if i + 1 < len(ent) and ent[i] == c else (ent[i] if i < len(ent) else 0)
    size = nxt - c if nxt > c else 0
    print(f'  {c:#x}  size~{size:,}')

# ---- 2. sibling module-update wrappers: pattern ldr x0,[x0,#off]; cbz; bl ----
# find all functions that call the module-driver region 0x6a30000..0x6aa0000
print('\n=== MODULE-UPDATE WRAPPERS (callers of 0x6a30..0x6aa0 region drivers) ===')
mlo, mhi = 0x6a30000, 0x6aa0000
in_mod = (t_sorted >= mlo) & (t_sorted < mhi)
wrapper_funcs = sorted(set(int(x) for x in f_sorted[in_mod]))
print(f'{len(wrapper_funcs)} functions call into the module-driver region')

# ---- 3. downward closure from spine top ----
print('\n=== DOWNWARD CLOSURE from 0x69917d8 (MatchMain state machine) ===')


def closure(roots, max_nodes=300000):
    seen = set()
    q = deque(roots)
    while q and len(seen) < max_nodes:
        f = q.popleft()
        if f in seen:
            continue
        seen.add(f)
        for c in callees_of(f):
            if c not in seen:
                q.append(c)
    return seen


def func_size(f):
    i = np.searchsorted(ent, f)
    if i < len(ent) and ent[i] == f:
        nxt = ent[i + 1] if i + 1 < len(ent) else f + 0x100
        return min(nxt - f, 0x20000)
    return 0x100


TEXT_VA, TEXT_SZ = 0x28293c0, 0x6347d80
for root in (0x69917d8, 0x69919e0):
    cl = closure([root])
    in_text = [f for f in cl if TEXT_VA <= f < TEXT_VA + TEXT_SZ]
    total_bytes = sum(func_size(f) for f in in_text)
    print(f'  root {root:#x}: {len(cl):,} functions, {total_bytes / 1024:.1f} KB code '
          f'({len(in_text):,} in .text)')

# PLT imports in closure
plt = json.load(open(f'{AN}/plt_map.json'))
plt_map = {int(k, 16): v['sym'] for k, v in plt.items()}
cl = closure([0x69917d8])
imports = sorted(plt_map[f] for f in cl if f in plt_map)
print(f'\n  PLT imports needed: {len(imports)}')
print('  ', imports[:50])

# ---- 4. match-object module offsets (from callers pattern scan) ----
# wrappers: 0x6a059b0 pattern — find similar: functions in 0x6a0xxxx calling module region
print('\n=== MODULE OFFSET MAP (wrapper -> driver) ===')
for w in wrapper_funcs:
    cl_w = callees_of(w)
    drivers = [c for c in cl_w if mlo <= c < mhi]
    if drivers and 0x6a00000 <= w < 0x6a20000:
        print(f'  wrapper {w:#x}: drivers {[hex(d) for d in sorted(drivers)[:6]]}')

json.dump({
    'playing_state_callees': [hex(c) for c in L1],
    'module_wrappers': [hex(w) for w in wrapper_funcs],
}, open(f'{AN}/playing_state.json', 'w'), indent=1)
print('\nJSON ->', f'{AN}/playing_state.json')
