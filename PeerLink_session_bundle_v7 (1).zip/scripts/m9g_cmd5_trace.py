#!/usr/bin/env python3
"""M9g: trace the cmd-5 handler's block path to find the NULL call."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.arm64_const import *
from m9_setup_seq import SetupWorld, slots22

PC_LO = 0x6a01000
PC_HI = 0x6a02800


def main():
    world = SetupWorld(verbose=True)
    core = world.core
    inner = world.inner
    path = []

    def blk(uc, address, size, ud):
        off = address - core.base
        if PC_LO <= off < PC_HI:
            path.append(off)

    core.uc.hook_add(UC_HOOK_BLOCK, blk)

    last_fault = {}

    def mem_err(uc, type_, address, size, value, ud):
        pc = uc.reg_read(UC_ARM64_REG_PC)
        last_fault.update({'type': int(type_), 'addr': address,
                           'pc_off': pc - core.base,
                           'x0': uc.reg_read(UC_ARM64_REG_X0),
                           'x1': uc.reg_read(UC_ARM64_REG_X1),
                           'x30': uc.reg_read(UC_ARM64_REG_X30) - core.base
                           if uc.reg_read(UC_ARM64_REG_X30) > 0x1000 else 0})
        print(f'  FAULT type={type_} addr={address:#x} '
              f'pc={pc - core.base:#x}')
        return False

    core.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                     | UC_HOOK_MEM_FETCH_UNMAPPED | UC_HOOK_MEM_FETCH_PROT,
                     mem_err)

    bs = world.bootstrap_game(run_init_array=True, max_init=15)
    r = core.call(0x6a09418, timeout_s=60)
    for i in range(16):
        core.write_u64(world.garr + i * 8, 0)
    core.write_u64(world.garr + 9 * 8, world.gobj)
    core.write_u64(world.garr + 10 * 8, world.gobj)

    def replug():
        core.write_u64(inner + 0x3868 + 0x40, world.ctrl3868)
        core.write_u64(inner + 0x3818 + 0x40, world.ctrl3818)

    replug()
    for i in range(6):   # reach cmd 5
        before, after, err, pc = world.step()
        replug()
        print(f'step {i}: cmd {before:#x} -> {after:#x} err={err}')

    # now trace cmd 5 in detail
    path.clear()
    print('--- tracing cmd-5 ---')
    before, after, err, pc = world.step()
    replug()
    print(f'step: cmd {before:#x} -> {after:#x} err={err}')
    print(f'fault: {last_fault}')
    seq = []
    for b in path:
        if not seq or seq[-1] != b:
            seq.append(b)
    print('block path (%d):' % len(seq))
    line = [f'{b:#x}' for b in seq]
    for i in range(0, len(line), 8):
        print('  ' + ' '.join(line[i:i + 8]))


if __name__ == '__main__':
    main()
