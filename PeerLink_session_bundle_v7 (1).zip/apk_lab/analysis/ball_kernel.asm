6ea0958: sub sp, sp, #0x1b0
6ea095c: stp d15, d14, [sp, #0x110]
6ea0960: stp d13, d12, [sp, #0x120]
6ea0964: stp d11, d10, [sp, #0x130]
6ea0968: stp d9, d8, [sp, #0x140]
6ea096c: stp x29, x30, [sp, #0x150]
6ea0970: stp x28, x27, [sp, #0x160]
6ea0974: stp x26, x25, [sp, #0x170]
6ea0978: stp x24, x23, [sp, #0x180]
6ea097c: stp x22, x21, [sp, #0x190]
6ea0980: stp x20, x19, [sp, #0x1a0]
6ea0984: add x29, sp, #0x150
6ea0988: str w5, [sp, #0x1c]
6ea098c: mrs x27, tpidr_el0
6ea0990: ldr x8, [x27, #0x28]
6ea0994: mov x20, x2
6ea0998: mov w25, w0
6ea099c: mov w23, w4
6ea09a0: mov x19, x2
6ea09a4: mov x24, x3
6ea09a8: stur x8, [x29, #-0x50]
6ea09ac: mov w26, w1
6ea09b0: ldr x9, [x2]
6ea09b4: fmov s8, s0
6ea09b8: ldr w8, [x2, #0x94]
6ea09bc: ldr x11, [x20, #0xc]!
6ea09c0: add x21, x20, #0xc
6ea09c4: ldr w10, [x2, #8]
6ea09c8: stur x9, [x29, #-0x80]
6ea09cc: ldr w9, [x20, #8]
6ea09d0: mov x0, x21
6ea09d4: cmp w8, #5
6ea09d8: csinc w28, w8, wzr, ls
6ea09dc: stur w10, [x29, #-0x78]
6ea09e0: stur x11, [x29, #-0x90]
6ea09e4: stur w9, [x29, #-0x88]
6ea09e8: bl #0x6ea0898
6ea09ec: sub x0, x29, #0xa0
6ea09f0: stp s0, s1, [x29, #-0xa0]
6ea09f4: stur s2, [x29, #-0x98]
6ea09f8: bl #0x6a18b5c
6ea09fc: fmov s9, s0
6ea0a00: fcmp s0, #0.0
6ea0a04: b.gt #0x6ea0a30
6ea0a08: mov w8, #0x96bb
6ea0a0c: ldur s0, [x20, #-8]
6ea0a10: movk w8, #0x3dde, lsl #16
6ea0a14: fmov s1, w8
6ea0a18: fcmp s0, s1
6ea0a1c: b.gt #0x6ea0a30
6ea0a20: sub x0, x29, #0x90
6ea0a24: bl #0x6a18b5c
6ea0a28: fcmp s0, #0.0
6ea0a2c: b.le #0x6ea0b38
6ea0a30: fmov s0, s8
6ea0a34: and w0, w25, #1
6ea0a38: sub x2, x29, #0xa0
6ea0a3c: mov x1, x19
6ea0a40: mov x3, x24
6ea0a44: bl #0x6ea1938
6ea0a48: stp s0, s1, [x29, #-0x60]
6ea0a4c: fmov s0, s8
6ea0a50: sub x0, x29, #0x60
6ea0a54: stur s2, [x29, #-0x58]
6ea0a58: bl #0x684b5dc
6ea0a5c: sub x1, x29, #0x70
6ea0a60: mov x0, x20
6ea0a64: stp s0, s1, [x29, #-0x70]
6ea0a68: stur s2, [x29, #-0x68]
6ea0a6c: bl #0x693a33c
6ea0a70: fmov s0, s8
6ea0a74: mov x0, x20
6ea0a78: bl #0x684b5dc
6ea0a7c: sub x1, x29, #0x70
6ea0a80: mov x0, x19
6ea0a84: stp s0, s1, [x29, #-0x70]
6ea0a88: stur s2, [x29, #-0x68]
6ea0a8c: bl #0x693a33c
6ea0a90: mov w22, #1
6ea0a94: tbz w26, #0, #0x6ea0b40
6ea0a98: sub x0, x29, #0x60
6ea0a9c: bl #0x684b500
6ea0aa0: ldur q0, [x19, #0x98]
6ea0aa4: add x26, x19, #0x98
6ea0aa8: stur q0, [x29, #-0x70]
6ea0aac: fmov s0, s9
6ea0ab0: bl #0x6a16f64
6ea0ab4: ldur x8, [x29, #-0xa0]
6ea0ab8: fmov s10, s0
6ea0abc: ldur w9, [x29, #-0x98]
6ea0ac0: fmul s9, s0, s8
6ea0ac4: str x8, [sp, #0xa0]
6ea0ac8: str w9, [sp, #0xa8]
6ea0acc: bl #0x684c680
6ea0ad0: movi v1.2s, #0x34, lsl #24
6ea0ad4: fcmp s0, s1
6ea0ad8: b.le #0x6ea0ae8
6ea0adc: fmov s0, s10
6ea0ae0: add x0, sp, #0xa0
6ea0ae4: bl #0x6a3865c
6ea0ae8: fmov s0, s9
6ea0aec: sub x0, x29, #0x60
6ea0af0: add x1, sp, #0xa0
6ea0af4: bl #0x729bc7c
6ea0af8: sub x0, x29, #0x60
6ea0afc: sub x1, x29, #0x70
6ea0b00: bl #0x729ba50
6ea0b04: sub x0, x29, #0x70
6ea0b08: stp s0, s1, [x29, #-0x70]
6ea0b0c: stp s2, s3, [x29, #-0x68]
6ea0b10: bl #0x729bae0
6ea0b14: ldur q0, [x29, #-0x70]
6ea0b18: str q0, [x26]
6ea0b1c: bl #0x68c8c14
6ea0b20: bl #0x68ce104
6ea0b24: bl #0x68b5d30
6ea0b28: and w8, w0, #0xffff
6ea0b2c: cmp w8, #0xa
6ea0b30: b.ne #0x6ea0bb0
6ea0b34: b #0x6ea0b58
6ea0b38: mov w22, wzr
6ea0b3c: tbnz w26, #0, #0x6ea0a98
6ea0b40: bl #0x68c8c14
6ea0b44: bl #0x68ce104
6ea0b48: bl #0x68b5d30
6ea0b4c: and w8, w0, #0xffff
6ea0b50: cmp w8, #0xa
6ea0b54: b.ne #0x6ea0bb0
6ea0b58: ldr s0, [x19]
6ea0b5c: bl #0x684c680
6ea0b60: mov w8, #0x42700000
6ea0b64: fmov s1, w8
6ea0b68: fcmp s0, s1
6ea0b6c: b.gt #0x6ea0b8c
6ea0b70: ldr s0, [x19, #8]
6ea0b74: bl #0x684c680
6ea0b78: mov w8, #0xcccd
6ea0b7c: movk w8, #0x421e, lsl #16
6ea0b80: fmov s1, w8
6ea0b84: fcmp s0, s1
6ea0b88: b.le #0x6ea0bb0
6ea0b8c: mov w8, #0x3e7d
6ea0b90: movk w8, #0xc01c, lsl #16
6ea0b94: fmov s10, w8
6ea0b98: ldr s0, [x19, #4]
6ea0b9c: fcmp s0, s10
6ea0ba0: csel w8, wzr, w22, pl
6ea0ba4: cmp w8, #1
6ea0ba8: b.eq #0x6ea0bd0
6ea0bac: b #0x6ea0c10
6ea0bb0: mov w8, #0x96bb
6ea0bb4: movk w8, #0x3dde, lsl #16
6ea0bb8: fmov s10, w8
6ea0bbc: ldr s0, [x19, #4]
6ea0bc0: fcmp s0, s10
6ea0bc4: csel w8, wzr, w22, pl
6ea0bc8: cmp w8, #1
6ea0bcc: b.ne #0x6ea0c10
6ea0bd0: ldrb w9, [x19, #0x90]
6ea0bd4: cbz w9, #0x6ea0c10
6ea0bd8: ldrb w9, [x19, #0x91]
6ea0bdc: cmp w9, #6
6ea0be0: b.ne #0x6ea0c10
6ea0be4: mov w8, #0xcccd
6ea0be8: ldr s0, [x19, #0x10]
6ea0bec: movk w8, #0xbf4c, lsl #16
6ea0bf0: fmov s1, w8
6ea0bf4: mov w8, #0x96bb
6ea0bf8: movk w8, #0x3dde, lsl #16
6ea0bfc: fmul s0, s0, s1
6ea0c00: str w8, [x19, #4]
6ea0c04: str s0, [x19, #0x10]
6ea0c08: tbnz w23, #0, #0x6ea14b8
6ea0c0c: b #0x6ea1518
6ea0c10: cbz w8, #0x6ea0c84
6ea0c14: sub x0, x29, #0x90
6ea0c18: bl #0x6a2e658
6ea0c1c: fmov s9, s0
6ea0c20: movi d0, #0000000000000000
6ea0c24: movi d2, #0000000000000000
6ea0c28: sub x0, x29, #0x60
6ea0c2c: fmov s1, #1.00000000
6ea0c30: strb wzr, [x19, #0x90]
6ea0c34: str s10, [x19, #4]
6ea0c38: bl #0x684bf44
6ea0c3c: ldur s0, [x29, #-0x7c]
6ea0c40: fsub s0, s0, s10
6ea0c44: bl #0x684c680
6ea0c48: movi v1.2s, #0x34, lsl #24
6ea0c4c: mov w26, wzr
6ea0c50: fcmp s0, s1
6ea0c54: b.pl #0x6ea0cb8
6ea0c58: ldr s0, [x19, #4]
6ea0c5c: fsub s0, s0, s10
6ea0c60: bl #0x684c680
6ea0c64: movi v1.2s, #0x34, lsl #24
6ea0c68: fcmp s0, s1
6ea0c6c: b.pl #0x6ea0cb4
6ea0c70: fmov s0, #8.00000000
6ea0c74: bl #0x6ea093c
6ea0c78: fcmp s9, s0
6ea0c7c: cset w26, mi
6ea0c80: b #0x6ea0cb8
6ea0c84: sub x1, x29, #0x80
6ea0c88: mov x0, x19
6ea0c8c: bl #0x684b570
6ea0c90: stp s0, s1, [x29, #-0x60]
6ea0c94: fmov s0, s8
6ea0c98: sub x0, x29, #0x60
6ea0c9c: stur s2, [x29, #-0x58]
6ea0ca0: bl #0x684b658
6ea0ca4: stp s0, s1, [x19, #0xc]
6ea0ca8: str s2, [x19, #0x14]
6ea0cac: tbnz w23, #0, #0x6ea14b8
6ea0cb0: b #0x6ea1518
6ea0cb4: mov w26, wzr
6ea0cb8: movi d0, #0000000000000000
6ea0cbc: movi d2, #0000000000000000
6ea0cc0: ldr s1, [x19, #0x10]
6ea0cc4: sub x0, x29, #0x70
6ea0cc8: bl #0x684bf44
6ea0ccc: ldr s0, [x19, #0x10]
6ea0cd0: bl #0x684c680
6ea0cd4: bl #0x6ea1be8
6ea0cd8: add x22, x24, w28, uxtw #2
6ea0cdc: movi d1, #0000000000000000
6ea0ce0: fmov s13, s0
6ea0ce4: ldr s0, [x19, #0xc]
6ea0ce8: ldr s2, [x19, #0x14]
6ea0cec: add x0, sp, #0xa0
6ea0cf0: ldr s10, [x22, #0x50]
6ea0cf4: bl #0x684bf44
6ea0cf8: add x0, sp, #0xa0
6ea0cfc: bl #0x6a0dfa0
6ea0d00: bl #0x6ea1be8
6ea0d04: ldr s3, [x22, #0x1a8]
6ea0d08: add x22, x24, x28, lsl #2
6ea0d0c: fcmp s0, s3
6ea0d10: b.le #0x6ea0d2c
6ea0d14: fmov s1, s3
6ea0d18: ldr s2, [x22, #0x190]
6ea0d1c: bl #0x68ce72c
6ea0d20: ldr s1, [x22, #0x148]
6ea0d24: add x8, x22, #0x160
6ea0d28: b #0x6ea0d40
6ea0d2c: fmov s2, s3
6ea0d30: ldr s1, [x22, #0x1c0]
6ea0d34: bl #0x68ce72c
6ea0d38: ldr s1, [x22, #0x160]
6ea0d3c: add x8, x22, #0x178
6ea0d40: fmul s1, s0, s1
6ea0d44: fmov s12, #1.00000000
6ea0d48: ldr s2, [x8]
6ea0d4c: fsub s0, s12, s0
6ea0d50: fmul s0, s0, s2
6ea0d54: fadd s11, s1, s0
6ea0d58: fmov s0, s9
6ea0d5c: bl #0x6ea1be8
6ea0d60: ldr s1, [x24, #0x1fc]
6ea0d64: fcmp s0, s1
6ea0d68: b.lt #0x6ea0e38
6ea0d6c: ldur s0, [x29, #-0x8c]
6ea0d70: bl #0x684c680
6ea0d74: movi v1.2s, #0x34, lsl #24
6ea0d78: fcmp s0, s1
6ea0d7c: b.le #0x6ea0d98
6ea0d80: ldur s0, [x29, #-0x8c]
6ea0d84: ldr s1, [x24, #0x1f4]
6ea0d88: fneg s0, s0
6ea0d8c: fdiv s0, s9, s0
6ea0d90: fcmp s0, s1
6ea0d94: b.le #0x6ea0e38
6ea0d98: mov w8, #0x447a0000
6ea0d9c: ldur s0, [x29, #-0x80]
6ea0da0: fmov s1, w8
6ea0da4: add x8, x24, x28, lsl #2
6ea0da8: fmul s0, s0, s1
6ea0dac: ldr w8, [x8, #0x1d8]
6ea0db0: fcvtzs w9, s0
6ea0db4: sdiv w10, w9, w8
6ea0db8: msub w8, w10, w8, w9
6ea0dbc: cbnz w8, #0x6ea0e38
6ea0dc0: ldur s0, [x29, #-0x78]
6ea0dc4: bl #0x684c680
6ea0dc8: mov w8, #0x447a0000
6ea0dcc: fmov s14, w8
6ea0dd0: fmul s15, s0, s14
6ea0dd4: ldur s0, [x29, #-0x78]
6ea0dd8: bl #0x684c680
6ea0ddc: fmul s0, s0, s14
6ea0de0: mov w8, #0x999a
6ea0de4: movk w8, #0x3f19, lsl #16
6ea0de8: fcvtzs s0, s0
6ea0dec: fmov s1, w8
6ea0df0: mov w8, #0x42c80000
6ea0df4: scvtf s0, s0
6ea0df8: fsub s0, s15, s0
6ea0dfc: fmov s15, #1.00000000
6ea0e00: fmul s14, s0, s1
6ea0e04: fmov s0, w8
6ea0e08: fmov s1, #1.00000000
6ea0e0c: fmul s2, s14, s0
6ea0e10: ldr s0, [x24, #0x1f8]
6ea0e14: bl #0x6a17138
6ea0e18: ldr s1, [x24, #0x1f0]
6ea0e1c: fsub s2, s15, s14
6ea0e20: fmul s11, s11, s0
6ea0e24: fmul s1, s9, s1
6ea0e28: fmul s1, s1, s2
6ea0e2c: ldur s2, [x29, #-0x6c]
6ea0e30: fsub s1, s2, s1
6ea0e34: stur s1, [x29, #-0x6c]
6ea0e38: add x0, sp, #0x90
6ea0e3c: bl #0x68352cc
6ea0e40: tbnz w25, #0, #0x6ea1410
6ea0e44: ldp s2, s1, [x24, #0x48]
6ea0e48: fmov s0, s13
6ea0e4c: bl #0x68ce72c
6ea0e50: add x22, x24, x28, lsl #2
6ea0e54: mov w8, #0x42c80000
6ea0e58: fmov s14, #1.00000000
6ea0e5c: ldr s1, [x22, #0x2c]
6ea0e60: fmov s12, w8
6ea0e64: fdiv s1, s1, s12
6ea0e68: fmul s0, s0, s1
6ea0e6c: ldp s2, s1, [x24, #0xc]
6ea0e70: fsub s0, s14, s0
6ea0e74: fmul s11, s11, s0
6ea0e78: fmov s0, s13
6ea0e7c: bl #0x6a182e4
6ea0e80: ldr s1, [x22, #0x14]
6ea0e84: fdiv s1, s1, s12
6ea0e88: fmul s0, s0, s1
6ea0e8c: ldp s2, s1, [x24, #0x6c]
6ea0e90: fadd s15, s0, s14
6ea0e94: fmov s0, s13
6ea0e98: bl #0x68ce72c
6ea0e9c: ldr s1, [x24, #0x44]
6ea0ea0: sub x0, x29, #0x60
6ea0ea4: add x1, sp, #0xa0
6ea0ea8: scvtf s1, s1
6ea0eac: fdiv s1, s1, s12
6ea0eb0: fmul s13, s0, s1
6ea0eb4: bl #0x6a39818
6ea0eb8: mov w8, #0x96bb
6ea0ebc: stp s0, s1, [sp, #0x70]
6ea0ec0: movk w8, #0x3dde, lsl #16
6ea0ec4: add x0, sp, #0x70
6ea0ec8: str s2, [sp, #0x78]
6ea0ecc: fmov s3, w8
6ea0ed0: fdiv s3, s11, s3
6ea0ed4: fmov s0, s3
6ea0ed8: bl #0x684b5dc
6ea0edc: stp s0, s1, [sp, #0x80]
6ea0ee0: str s2, [sp, #0x88]
6ea0ee4: cbz w26, #0x6ea0f44
6ea0ee8: add x0, sp, #0x80
6ea0eec: bl #0x6ea088c
6ea0ef0: add x0, sp, #0x70
6ea0ef4: mov x1, x21
6ea0ef8: stp s0, s1, [sp, #0x70]
6ea0efc: str s2, [sp, #0x78]
6ea0f00: bl #0x684b570
6ea0f04: add x0, sp, #0x60
6ea0f08: stp s0, s1, [sp, #0x60]
6ea0f0c: str s2, [sp, #0x68]
6ea0f10: bl #0x6a18b5c
6ea0f14: mov w9, #0xfdb
6ea0f18: adrp x8, #0xa435000
6ea0f1c: movk w9, #0x40c9, lsl #16
6ea0f20: fmov s12, s0
6ea0f24: ldr s1, [x8, #0x38]
6ea0f28: fmov s2, w9
6ea0f2c: fmul s1, s1, s2
6ea0f30: fmov s0, s1
6ea0f34: bl #0x6a0df68
6ea0f38: fcmp s12, s0
6ea0f3c: cset w25, le
6ea0f40: b #0x6ea0f48
6ea0f44: mov w25, wzr
6ea0f48: ldur s0, [x29, #-0x8c]
6ea0f4c: fmul s10, s10, s15
6ea0f50: ldr s15, [x22, #0xa4]
6ea0f54: fsub s12, s14, s13
6ea0f58: ldr s13, [x22, #0x74]
6ea0f5c: bl #0x6ea1be8
6ea0f60: fneg s0, s0
6ea0f64: ldr s1, [x22, #0x104]
6ea0f68: ldr s2, [x22, #0xd4]
6ea0f6c: bl #0x68ce72c
6ea0f70: fmul s0, s13, s0
6ea0f74: fadd s0, s15, s0
6ea0f78: stp s9, s0, [sp, #0x10]
6ea0f7c: tbz w25, #0, #0x6ea0f88
6ea0f80: mov w26, wzr
6ea0f84: b #0x6ea11f4
6ea0f88: movi d1, #0000000000000000
6ea0f8c: ldur s0, [x29, #-0xa0]
6ea0f90: ldur s2, [x29, #-0x98]
6ea0f94: add x0, sp, #0x70
6ea0f98: bl #0x684bf44
6ea0f9c: add x0, sp, #0x70
6ea0fa0: bl #0x6a2e658
6ea0fa4: fmov s13, s0
6ea0fa8: movi d0, #0000000000000000
6ea0fac: movi d1, #0000000000000000
6ea0fb0: add x0, sp, #0x60
6ea0fb4: fmov s2, #1.00000000
6ea0fb8: bl #0x684bf44
6ea0fbc: mov w8, #0x126f
6ea0fc0: str s10, [sp, #0x18]
6ea0fc4: movk w8, #0x3a83, lsl #16
6ea0fc8: fmov s0, w8
6ea0fcc: fcmp s9, s0
6ea0fd0: b.ge #0x6ea0fe0
6ea0fd4: ldp s1, s0, [sp, #0x64]
6ea0fd8: ldr s3, [sp, #0x60]
6ea0fdc: b #0x6ea1010
6ea0fe0: movi d1, #0000000000000000
6ea0fe4: ldur s0, [x29, #-0x90]
6ea0fe8: ldur s2, [x29, #-0x88]
6ea0fec: add x0, sp, #0x50
6ea0ff0: bl #0x684bf44
6ea0ff4: fmov s0, s9
6ea0ff8: add x0, sp, #0x50
6ea0ffc: bl #0x684b658
6ea1000: fmov s3, s0
6ea1004: fmov s0, s2
6ea1008: str s2, [sp, #0x68]
6ea100c: stp s3, s1, [sp, #0x60]
6ea1010: fneg s2, s3
6ea1014: add x0, sp, #0x50
6ea1018: bl #0x684bf44
6ea101c: ldur s0, [x29, #-0x98]
6ea1020: movi d1, #0000000000000000
6ea1024: ldur s2, [x29, #-0xa0]
6ea1028: add x0, sp, #0x40
6ea102c: fneg s0, s0
6ea1030: bl #0x684bf44
6ea1034: add x0, sp, #0x40
6ea1038: add x1, sp, #0x60
6ea103c: bl #0x684c1f4
6ea1040: fmov s14, #0.50000000
6ea1044: mov w8, #0xfdb
6ea1048: movk w8, #0x4049, lsl #16
6ea104c: add x0, sp, #0x40
6ea1050: add x1, sp, #0x50
6ea1054: fmul s0, s0, s14
6ea1058: fmov s15, w8
6ea105c: fdiv s10, s0, s15
6ea1060: bl #0x684c1f4
6ea1064: fmul s1, s13, s14
6ea1068: fmul s0, s0, s14
6ea106c: add x0, sp, #0x80
6ea1070: fdiv s1, s1, s15
6ea1074: fdiv s13, s0, s15
6ea1078: fmov s0, s11
6ea107c: stp s1, s11, [sp, #8]
6ea1080: bl #0x684b658
6ea1084: add x0, sp, #0x30
6ea1088: stp s0, s1, [sp, #0x30]
6ea108c: str s2, [sp, #0x38]
6ea1090: bl #0x6a2e658
6ea1094: fmul s0, s0, s14
6ea1098: movi d1, #0000000000000000
6ea109c: fdiv s15, s0, s15
6ea10a0: ldr s0, [x24, #0x68]
6ea10a4: fsub s0, s15, s0
6ea10a8: bl #0x684b844
6ea10ac: fsub s0, s15, s0
6ea10b0: ldr s11, [sp, #0x14]
6ea10b4: fsub s0, s0, s10
6ea10b8: fmul s0, s11, s0
6ea10bc: fadd s15, s10, s0
6ea10c0: fsub s0, s10, s15
6ea10c4: bl #0x684c680
6ea10c8: fmov s1, #1.00000000
6ea10cc: fmov s2, #4.00000000
6ea10d0: bl #0x6a182e4
6ea10d4: fmul s0, s0, s14
6ea10d8: ldr s2, [x24, #0x2ac]
6ea10dc: fmul s13, s11, s13
6ea10e0: fneg s1, s2
6ea10e4: fadd s0, s0, s14
6ea10e8: fmul s0, s15, s0
6ea10ec: fsub s0, s10, s0
6ea10f0: bl #0x684b644
6ea10f4: ldr s2, [x24, #0x2ac]
6ea10f8: fmov s15, s0
6ea10fc: fmov s0, s13
6ea1100: fneg s1, s2
6ea1104: bl #0x684b644
6ea1108: fmov s14, s0
6ea110c: fmov s0, s9
6ea1110: fcmp s15, #0.0
6ea1114: ldr s13, [x24, #0x2b0]
6ea1118: cset w26, gt
6ea111c: bl #0x684c680
6ea1120: movi v1.2s, #0x34, lsl #24
6ea1124: fcmp s0, s1
6ea1128: b.le #0x6ea1138
6ea112c: ldur s0, [x29, #-0x8c]
6ea1130: bl #0x684c680
6ea1134: fdiv s13, s0, s9
6ea1138: add x22, x24, x28, lsl #2
6ea113c: fmov s0, #1.00000000
6ea1140: ldr s1, [x24, #0x2b4]
6ea1144: ldr s2, [x24, #0x2b0]
6ea1148: ldr s10, [x22, #0x2b8]
6ea114c: fsub s9, s0, s10
6ea1150: fmov s0, s13
6ea1154: bl #0x68ce72c
6ea1158: fmul s0, s9, s0
6ea115c: ldr s1, [x24, #0x2ac]
6ea1160: fadd s9, s10, s0
6ea1164: fmul s0, s15, s9
6ea1168: fdiv s10, s0, s1
6ea116c: ldr s0, [x22, #0x294]
6ea1170: bl #0x6ea093c
6ea1174: fmul s1, s14, s9
6ea1178: ldr s2, [x24, #0x2ac]
6ea117c: fmul s13, s0, s10
6ea1180: ldr s0, [x22, #0x294]
6ea1184: fdiv s9, s1, s2
6ea1188: bl #0x6ea093c
6ea118c: ldr s1, [x24, #0x290]
6ea1190: fmul s14, s9, s0
6ea1194: ldr s2, [x24, #0x28c]
6ea1198: ldr s0, [sp, #8]
6ea119c: bl #0x68ce72c
6ea11a0: fmul s0, s0, s0
6ea11a4: ldr s1, [x24, #0x288]
6ea11a8: add x0, sp, #0x60
6ea11ac: fmul s9, s0, s1
6ea11b0: fmov s0, s13
6ea11b4: bl #0x684b5dc
6ea11b8: stp s0, s1, [sp, #0x30]
6ea11bc: fmov s0, s14
6ea11c0: add x0, sp, #0x50
6ea11c4: str s2, [sp, #0x38]
6ea11c8: bl #0x684b5dc
6ea11cc: add x0, sp, #0x30
6ea11d0: add x1, sp, #0x20
6ea11d4: stp s0, s1, [sp, #0x20]
6ea11d8: str s2, [sp, #0x28]
6ea11dc: bl #0x684b504
6ea11e0: ldr s10, [sp, #0x18]
6ea11e4: stp s0, s1, [sp, #0x90]
6ea11e8: ldr s11, [sp, #0xc]
6ea11ec: str s2, [sp, #0x98]
6ea11f0: fadd s10, s10, s9
6ea11f4: fmov s0, s11
6ea11f8: add x0, sp, #0xa0
6ea11fc: str s10, [sp, #0x18]
6ea1200: bl #0x684b5dc
6ea1204: stp s0, s1, [sp, #0x40]
6ea1208: fmov s0, s12
6ea120c: add x0, sp, #0x90
6ea1210: str s2, [sp, #0x48]
6ea1214: bl #0x684b5dc
6ea1218: add x0, sp, #0x40
6ea121c: add x1, sp, #0x30
6ea1220: stp s0, s1, [sp, #0x30]
6ea1224: str s2, [sp, #0x38]
6ea1228: bl #0x684b504
6ea122c: sub x0, x29, #0x60
6ea1230: add x1, sp, #0x50
6ea1234: stp s0, s1, [sp, #0x50]
6ea1238: str s2, [sp, #0x58]
6ea123c: bl #0x6a39818
6ea1240: mov w8, #0x96bb
6ea1244: stp s0, s1, [sp, #0x60]
6ea1248: movk w8, #0x3dde, lsl #16
6ea124c: add x0, sp, #0x60
6ea1250: str s2, [sp, #0x68]
6ea1254: fmov s0, w8
6ea1258: bl #0x684b658
6ea125c: add x0, sp, #0x70
6ea1260: stp s0, s1, [sp, #0x70]
6ea1264: str s2, [sp, #0x78]
6ea1268: bl #0x6a1e700
6ea126c: fmov s13, #0.50000000
6ea1270: mov w8, #0xfdb
6ea1274: movk w8, #0x4049, lsl #16
6ea1278: ldr s15, [x24, #0x68]
6ea127c: fmov s14, #1.00000000
6ea1280: fmul s0, s0, s13
6ea1284: fmov s1, w8
6ea1288: fmul s0, s0, s13
6ea128c: fdiv s0, s0, s1
6ea1290: fdiv s0, s0, s1
6ea1294: fmul s1, s15, s15
6ea1298: fcmp s0, s1
6ea129c: fmov s0, #1.00000000
6ea12a0: b.le #0x6ea12c4
6ea12a4: add x0, sp, #0x70
6ea12a8: bl #0x6a2e658
6ea12ac: mov w8, #0xfdb
6ea12b0: fmul s0, s0, s13
6ea12b4: movk w8, #0x4049, lsl #16
6ea12b8: fmov s1, w8
6ea12bc: fdiv s0, s0, s1
6ea12c0: fdiv s0, s15, s0
6ea12c4: ldr s1, [sp, #0x70]
6ea12c8: add x0, sp, #0x70
6ea12cc: ldr s2, [sp, #0x78]
6ea12d0: fmul s1, s0, s1
6ea12d4: fmul s0, s0, s2
6ea12d8: str s1, [sp, #0x70]
6ea12dc: str s0, [sp, #0x78]
6ea12e0: bl #0x6ea088c
6ea12e4: add x0, sp, #0x60
6ea12e8: mov x1, x21
6ea12ec: stp s0, s1, [sp, #0x60]
6ea12f0: str s2, [sp, #0x68]
6ea12f4: bl #0x684b570
6ea12f8: fmov s13, s1
6ea12fc: ldr s1, [sp, #0x14]
6ea1300: orr w8, w25, w26
6ea1304: ldr s3, [x19, #0x18]
6ea1308: cmp w8, #0
6ea130c: add x0, sp, #0x50
6ea1310: fcsel s1, s14, s1, ne
6ea1314: fmul s0, s1, s0
6ea1318: fmul s1, s1, s2
6ea131c: ldr s2, [x19, #0x20]
6ea1320: fadd s0, s3, s0
6ea1324: fadd s2, s1, s2
6ea1328: movi d1, #0000000000000000
6ea132c: str s0, [x19, #0x18]
6ea1330: str s2, [x19, #0x20]
6ea1334: bl #0x684bf44
6ea1338: add x0, sp, #0x50
6ea133c: bl #0x6ea0898
6ea1340: add x22, x24, x28, lsl #2
6ea1344: ldur s0, [x29, #-0x8c]
6ea1348: ldr s9, [x22, #0xbc]
6ea134c: ldr s10, [x22, #0x8c]
6ea1350: bl #0x6ea1be8
6ea1354: fneg s0, s0
6ea1358: ldr s1, [x22, #0x11c]
6ea135c: ldr s2, [x22, #0xec]
6ea1360: bl #0x68ce72c
6ea1364: fmul s0, s10, s0
6ea1368: fadd s14, s9, s0
6ea136c: fmov s0, s13
6ea1370: bl #0x684c680
6ea1374: mov w8, #0xd70a
6ea1378: movi d1, #0000000000000000
6ea137c: movk w8, #0x3c23, lsl #16
6ea1380: fmov s2, w8
6ea1384: bl #0x68ce72c
6ea1388: fmov s1, #2.50000000
6ea138c: mov w8, #0x42c80000
6ea1390: fmul s1, s14, s1
6ea1394: fmov s2, w8
6ea1398: fmul s2, s0, s2
6ea139c: fmov s0, s1
6ea13a0: fmov s1, s14
6ea13a4: bl #0x6a17138
6ea13a8: movi d1, #0000000000000000
6ea13ac: fmov s2, #1.00000000
6ea13b0: bl #0x684b644
6ea13b4: fmul s0, s13, s0
6ea13b8: ldr s1, [x19, #0x1c]
6ea13bc: fadd s0, s1, s0
6ea13c0: str s0, [x19, #0x1c]
6ea13c4: ldr s0, [sp, #0x10]
6ea13c8: bl #0x6ea1be8
6ea13cc: ldr s1, [x22, #0x204]
6ea13d0: fmul s0, s0, s1
6ea13d4: ldr s1, [x24, #0x21c]
6ea13d8: fadd s0, s0, s1
6ea13dc: fmov s1, #6.00000000
6ea13e0: bl #0x683a1dc
6ea13e4: bl #0x6ea093c
6ea13e8: fcmp s8, #0.0
6ea13ec: b.le #0x6ea1400
6ea13f0: fneg s0, s0
6ea13f4: ldur s1, [x29, #-0x6c]
6ea13f8: bl #0x683a1dc
6ea13fc: b #0x6ea1408
6ea1400: ldur s1, [x29, #-0x6c]
6ea1404: bl #0x684b844
6ea1408: ldr s10, [sp, #0x18]
6ea140c: stur s0, [x29, #-0x6c]
6ea1410: fcmp s8, #0.0
6ea1414: b.le #0x6ea1440
6ea1418: fneg s0, s10
6ea141c: sub x0, x29, #0x70
6ea1420: bl #0x6a06200
6ea1424: fmov s0, s11
6ea1428: add x0, sp, #0xa0
6ea142c: bl #0x6a06200
6ea1430: fmov s0, s12
6ea1434: add x0, sp, #0x90
6ea1438: bl #0x6a06200
6ea143c: b #0x6ea1464
6ea1440: fmov s0, s10
6ea1444: sub x0, x29, #0x70
6ea1448: bl #0x6a3865c
6ea144c: fmov s0, s11
6ea1450: add x0, sp, #0xa0
6ea1454: bl #0x6a3865c
6ea1458: fmov s0, s12
6ea145c: add x0, sp, #0x90
6ea1460: bl #0x6a3865c
6ea1464: ldr s0, [x24, #0x2d4]
6ea1468: bl #0x6ea093c
6ea146c: add x0, sp, #0xa0
6ea1470: fmov s9, s0
6ea1474: bl #0x6a1e700
6ea1478: fmul s1, s9, s9
6ea147c: fcmp s0, s1
6ea1480: b.pl #0x6ea148c
6ea1484: add x0, sp, #0xa0
6ea1488: bl #0x68bf588
6ea148c: sub x0, x29, #0x70
6ea1490: add x1, sp, #0xa0
6ea1494: bl #0x684b504
6ea1498: add x0, sp, #0x80
6ea149c: add x1, sp, #0x90
6ea14a0: stp s0, s1, [sp, #0x80]
6ea14a4: str s2, [sp, #0x88]
6ea14a8: bl #0x684b504
6ea14ac: stp s0, s1, [x19, #0xc]
6ea14b0: str s2, [x19, #0x14]
6ea14b4: tbz w23, #0, #0x6ea1518
6ea14b8: ldur s0, [x29, #-0x8c]
6ea14bc: mov w8, #0x96bb
6ea14c0: ldur s1, [x29, #-0x7c]
6ea14c4: movk w8, #0x3dde, lsl #16
6ea14c8: fmul s0, s0, s8
6ea14cc: fadd s0, s1, s0
6ea14d0: fmov s1, w8
6ea14d4: fcmp s0, s1
6ea14d8: b.lt #0x6ea1518
6ea14dc: fmov s0, s8
6ea14e0: sub x0, x29, #0x90
6ea14e4: bl #0x684b5dc
6ea14e8: sub x0, x29, #0x80
6ea14ec: sub x1, x29, #0x60
6ea14f0: stp s0, s1, [x29, #-0x60]
6ea14f4: stur s2, [x29, #-0x58]
6ea14f8: bl #0x684b504
6ea14fc: ldur x8, [x29, #-0x90]
6ea1500: str s0, [x19]
6ea1504: ldur w9, [x29, #-0x88]
6ea1508: str s1, [x19, #4]
6ea150c: str s2, [x19, #8]
6ea1510: str x8, [x20]
6ea1514: str w9, [x20, #8]
6ea1518: bl #0x68c8c14
6ea151c: bl #0x68ce104
6ea1520: cbz x0, #0x6ea18bc
6ea1524: bl #0x722096c
6ea1528: tbz w0, #0, #0x6ea18bc
6ea152c: ldr w8, [sp, #0x1c]
6ea1530: tbz w8, #0, #0x6ea18bc
6ea1534: bl #0x68c8c14
6ea1538: bl #0x6ad2f20
6ea153c: ldr s12, [x0]
6ea1540: bl #0x68c8c14
6ea1544: bl #0x6ad2f20
6ea1548: ldr s11, [x0, #4]
6ea154c: bl #0x68c8c14
6ea1550: bl #0x6ad2f20
6ea1554: ldr s13, [x0, #0xc]
6ea1558: bl #0x68c8c14
6ea155c: bl #0x6ad2f20
6ea1560: ldr s10, [x0, #8]
6ea1564: bl #0x68c8c14
6ea1568: bl #0x6ad2f20
6ea156c: ldr s0, [x19]
6ea1570: ldr s9, [x0, #0x3c]
6ea1574: bl #0x684c680
6ea1578: mov w8, #0x96bb
6ea157c: movk w8, #0xbdde, lsl #16
6ea1580: fmov s1, w8
6ea1584: fadd s8, s12, s1
6ea1588: fcmp s0, s8
6ea158c: b.lt #0x6ea169c
6ea1590: ldur s0, [x29, #-0x80]
6ea1594: bl #0x684c680
6ea1598: fcmp s0, s8
6ea159c: b.hi #0x6ea169c
6ea15a0: ldr s0, [x19, #4]
6ea15a4: bl #0x684c680
6ea15a8: fcmp s0, s13
6ea15ac: b.le #0x6ea15c0
6ea15b0: ldur s0, [x29, #-0x7c]
6ea15b4: bl #0x684c680
6ea15b8: fcmp s0, s13
6ea15bc: b.gt #0x6ea17f0
6ea15c0: ldr s0, [x19, #8]
6ea15c4: bl #0x684c680
6ea15c8: fcmp s0, s10
6ea15cc: b.le #0x6ea15e0
6ea15d0: ldur s0, [x29, #-0x78]
6ea15d4: bl #0x684c680
6ea15d8: fcmp s0, s10
6ea15dc: b.gt #0x6ea17f0
6ea15e0: ldr s0, [x19]
6ea15e4: ldur s1, [x29, #-0x80]
6ea15e8: fsub s0, s0, s1
6ea15ec: bl #0x684c680
6ea15f0: movi v1.2s, #0x34, lsl #24
6ea15f4: fcmp s0, s1
6ea15f8: b.le #0x6ea169c
6ea15fc: fmov s0, #0.50000000
6ea1600: fmul s0, s9, s0
6ea1604: fsub s9, s12, s0
6ea1608: ldur s0, [x29, #-0x80]
6ea160c: bl #0x684c680
6ea1610: fsub s14, s9, s0
6ea1614: ldr s0, [x19]
6ea1618: bl #0x684c680
6ea161c: fmov s9, s0
6ea1620: ldur s0, [x29, #-0x80]
6ea1624: bl #0x684c680
6ea1628: fsub s0, s9, s0
6ea162c: sub x1, x29, #0x80
6ea1630: mov x0, x19
6ea1634: fdiv s9, s14, s0
6ea1638: bl #0x684b570
6ea163c: stp s0, s1, [x29, #-0x70]
6ea1640: fmov s0, s9
6ea1644: sub x0, x29, #0x70
6ea1648: stur s2, [x29, #-0x68]
6ea164c: bl #0x684b5dc
6ea1650: sub x0, x29, #0x60
6ea1654: sub x1, x29, #0x80
6ea1658: stp s0, s1, [x29, #-0x60]
6ea165c: stur s2, [x29, #-0x58]
6ea1660: bl #0x684b504
6ea1664: mov w8, #0x96bb
6ea1668: movk w8, #0xbdde, lsl #16
6ea166c: fmov s0, w8
6ea1670: fadd s0, s13, s0
6ea1674: fcmp s1, s0
6ea1678: b.gt #0x6ea17f0
6ea167c: fmov s0, s2
6ea1680: bl #0x684c680
6ea1684: mov w8, #0x96bb
6ea1688: movk w8, #0xbdde, lsl #16
6ea168c: fmov s1, w8
6ea1690: fadd s1, s10, s1
6ea1694: fcmp s0, s1
6ea1698: b.ge #0x6ea17f0
6ea169c: mov w22, wzr
6ea16a0: ldr s0, [x19, #8]
6ea16a4: bl #0x684c680
6ea16a8: mov w8, #0x96bb
6ea16ac: movk w8, #0xbdde, lsl #16
6ea16b0: fmov s1, w8
6ea16b4: fadd s9, s11, s1
6ea16b8: fcmp s0, s9
6ea16bc: b.ge #0x6ea170c
6ea16c0: tbz w22, #0, #0x6ea18bc
6ea16c4: ldrb w8, [x19, #0x90]
6ea16c8: mov w23, wzr
6ea16cc: cbz w8, #0x6ea1778
6ea16d0: ldrb w8, [x19, #0x91]
6ea16d4: cmp w8, #6
6ea16d8: b.ne #0x6ea1778
6ea16dc: mov w8, #0x96bb
6ea16e0: fmov s2, s8
6ea16e4: movk w8, #0x3dde, lsl #16
6ea16e8: fmov s0, w8
6ea16ec: fsub s1, s0, s12
6ea16f0: ldr s0, [x19]
6ea16f4: bl #0x684b644
6ea16f8: ldr s1, [x19, #0xc]
6ea16fc: str s0, [x19]
6ea1700: fneg s1, s1
6ea1704: str s1, [x19, #0xc]
6ea1708: b #0x6ea18bc
6ea170c: ldr s0, [x19, #8]
6ea1710: ldr s1, [x19, #0x14]
6ea1714: fmul s10, s0, s1
6ea1718: fcmp s10, #0.0
6ea171c: csinc w8, w22, wzr, le
6ea1720: cset w23, gt
6ea1724: tbz w8, #0, #0x6ea18bc
6ea1728: ldrb w8, [x19, #0x90]
6ea172c: cbz w8, #0x6ea1778
6ea1730: ldrb w8, [x19, #0x91]
6ea1734: cmp w8, #6
6ea1738: b.ne #0x6ea1778
6ea173c: cbz w22, #0x6ea18fc
6ea1740: mov w8, #0x96bb
6ea1744: fmov s2, s8
6ea1748: movk w8, #0x3dde, lsl #16
6ea174c: fmov s0, w8
6ea1750: fsub s1, s0, s12
6ea1754: ldr s0, [x19]
6ea1758: bl #0x684b644
6ea175c: ldr s1, [x19, #0xc]
6ea1760: fcmp s10, #0.0
6ea1764: str s0, [x19]
6ea1768: fneg s1, s1
6ea176c: str s1, [x19, #0xc]
6ea1770: b.le #0x6ea18bc
6ea1774: b #0x6ea1904
6ea1778: mov x0, x21
6ea177c: strb wzr, [x19, #0x90]
6ea1780: bl #0x6ea0898
6ea1784: sub x0, x29, #0x70
6ea1788: stp s0, s1, [x29, #-0x60]
6ea178c: stur s2, [x29, #-0x58]
6ea1790: bl #0x68352cc
6ea1794: add x0, sp, #0xa0
6ea1798: bl #0x68352cc
6ea179c: movi d10, #0000000000000000
6ea17a0: cbz w22, #0x6ea17b0
6ea17a4: ldr s0, [x19]
6ea17a8: bl #0x69bb70c
6ea17ac: fneg s10, s0
6ea17b0: tbz w23, #0, #0x6ea17f8
6ea17b4: ldr s0, [x19, #8]
6ea17b8: bl #0x69bb70c
6ea17bc: fneg s2, s0
6ea17c0: movi d1, #0000000000000000
6ea17c4: fmov s0, s10
6ea17c8: add x0, sp, #0x90
6ea17cc: bl #0x684bf44
6ea17d0: and w8, w22, w23
6ea17d4: cmp w8, #1
6ea17d8: b.ne #0x6ea180c
6ea17dc: fmov s0, #2.00000000
6ea17e0: bl #0x6a16f64
6ea17e4: add x0, sp, #0x90
6ea17e8: bl #0x6a3865c
6ea17ec: b #0x6ea180c
6ea17f0: mov w22, #1
6ea17f4: b #0x6ea16a0
6ea17f8: movi d1, #0000000000000000
6ea17fc: movi d2, #0000000000000000
6ea1800: fmov s0, s10
6ea1804: add x0, sp, #0x90
6ea1808: bl #0x684bf44
6ea180c: add x0, sp, #0x80
6ea1810: bl #0x68352cc
6ea1814: mov w8, #0xb852
6ea1818: mov w9, #0xcccd
6ea181c: movk w8, #0x3f7e, lsl #16
6ea1820: movk w9, #0x3f4c, lsl #16
6ea1824: sub x0, x29, #0x70
6ea1828: add x1, sp, #0xa0
6ea182c: add x2, sp, #0x90
6ea1830: add x4, sp, #0x80
6ea1834: fmov s0, w8
6ea1838: fmov s1, w9
6ea183c: fmov s2, #0.25000000
6ea1840: sub x5, x29, #0x60
6ea1844: mov x3, x20
6ea1848: bl #0x6ea1bfc
6ea184c: cbz w22, #0x6ea1870
6ea1850: mov w8, #0x96bb
6ea1854: fmov s2, s8
6ea1858: movk w8, #0x3dde, lsl #16
6ea185c: fmov s0, w8
6ea1860: fsub s1, s0, s12
6ea1864: ldr s0, [x19]
6ea1868: bl #0x684b644
6ea186c: str s0, [x19]
6ea1870: cbz w23, #0x6ea1894
6ea1874: mov w8, #0x96bb
6ea1878: fmov s2, s9
6ea187c: movk w8, #0x3dde, lsl #16
6ea1880: fmov s0, w8
6ea1884: fsub s1, s0, s11
6ea1888: ldr s0, [x19, #8]
6ea188c: bl #0x684b644
6ea1890: str s0, [x19, #8]
6ea1894: ldur x8, [x29, #-0x70]
6ea1898: add x0, sp, #0xa0
6ea189c: ldur w9, [x29, #-0x68]
6ea18a0: str x8, [x20]
6ea18a4: str w9, [x20, #8]
6ea18a8: bl #0x6ea088c
6ea18ac: mov w8, #0x700
6ea18b0: stp s0, s1, [x19, #0x18]
6ea18b4: str s2, [x19, #0x20]
6ea18b8: strh w8, [x19, #0x90]
6ea18bc: ldr x8, [x27, #0x28]
6ea18c0: ldur x9, [x29, #-0x50]
6ea18c4: cmp x8, x9
6ea18c8: b.ne #0x6ea1934
6ea18cc: ldp x20, x19, [sp, #0x1a0]
6ea18d0: ldp x22, x21, [sp, #0x190]
6ea18d4: ldp x24, x23, [sp, #0x180]
6ea18d8: ldp x26, x25, [sp, #0x170]
6ea18dc: ldp x28, x27, [sp, #0x160]
6ea18e0: ldp x29, x30, [sp, #0x150]
6ea18e4: ldp d9, d8, [sp, #0x140]
6ea18e8: ldp d11, d10, [sp, #0x130]
6ea18ec: ldp d13, d12, [sp, #0x120]
6ea18f0: ldp d15, d14, [sp, #0x110]
6ea18f4: add sp, sp, #0x1b0
6ea18f8: ret 
6ea18fc: fcmp s10, #0.0
6ea1900: b.le #0x6ea18bc
6ea1904: mov w8, #0x96bb
6ea1908: fmov s2, s9
6ea190c: movk w8, #0x3dde, lsl #16
6ea1910: fmov s0, w8
6ea1914: fsub s1, s0, s11
6ea1918: ldr s0, [x19, #8]
6ea191c: bl #0x684b644
6ea1920: ldr s1, [x19, #0x14]
6ea1924: str s0, [x19, #8]
6ea1928: fneg s1, s1
6ea192c: str s1, [x19, #0x14]
6ea1930: b #0x6ea18bc
6ea1934: bl #0x8b35290
