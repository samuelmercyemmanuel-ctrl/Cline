6a00e50: sub sp, sp, #0x80
6a00e54: stp x29, x30, [sp, #0x40]
6a00e58: str x23, [sp, #0x50]
6a00e5c: stp x22, x21, [sp, #0x60]
6a00e60: stp x20, x19, [sp, #0x70]
6a00e64: add x29, sp, #0x40
6a00e68: mrs x22, tpidr_el0
6a00e6c: ldr x8, [x22, #0x28]
6a00e70: stur x8, [x29, #-8]
6a00e74: cbz x1, #0x6a01928
6a00e78: ldr w8, [x0, #8]
6a00e7c: mov x19, x0
6a00e80: cmp w8, #0x6d
6a00e84: b.hi #0x6a01928
6a00e88: adrp x9, #0xc6b000
6a00e8c: add x9, x9, #0xdcc
6a00e90: mov x20, x1
6a00e94: adr x10, #0x6a00ea4
6a00e98: ldrh w11, [x9, x8, lsl #1]
6a00e9c: add x10, x10, x11, lsl #2
6a00ea0: br x10
6a00ea4: bl #0x6836474
6a00ea8: ldr x8, [x0]
6a00eac: mov x1, xzr
6a00eb0: ldr x8, [x8, #0x130]
6a00eb4: blr x8
6a00eb8: tbz w0, #0, #0x6a01928
6a00ebc: ldr w8, [x19, #8]
6a00ec0: cmp w8, #0x6c
6a00ec4: b.eq #0x6a01894
6a00ec8: b #0x6a018ac
6a00ecc: mov x0, x19
6a00ed0: mov w1, wzr
6a00ed4: mov w2, #8
6a00ed8: bl #0x6a027f8
6a00edc: mov w8, #0x41
6a00ee0: b #0x6a01924
6a00ee4: mov x0, x19
6a00ee8: mov w1, wzr
6a00eec: mov w2, #9
6a00ef0: bl #0x6a027f8
6a00ef4: mov w8, #0x42
6a00ef8: b #0x6a01924
6a00efc: mov x0, x19
6a00f00: mov w1, #1
6a00f04: mov w2, #8
6a00f08: bl #0x6a027f8
6a00f0c: mov w8, #0x4c
6a00f10: b #0x6a01924
6a00f14: mov x0, x19
6a00f18: mov w1, #1
6a00f1c: mov w2, #9
6a00f20: bl #0x6a027f8
6a00f24: mov w8, #0x4d
6a00f28: b #0x6a01924
6a00f2c: mov x0, x19
6a00f30: mov w1, wzr
6a00f34: mov w2, #0xc
6a00f38: bl #0x6a027f8
6a00f3c: mov w8, #0x50
6a00f40: b #0x6a01924
6a00f44: mov x0, x19
6a00f48: mov w1, wzr
6a00f4c: mov w2, #0xf
6a00f50: bl #0x6a027f8
6a00f54: mov w8, #0x53
6a00f58: b #0x6a01924
6a00f5c: mov x0, x19
6a00f60: mov w1, #1
6a00f64: mov w2, #0xd
6a00f68: bl #0x6a027f8
6a00f6c: mov w8, #0x5d
6a00f70: b #0x6a01924
6a00f74: mov x0, x19
6a00f78: mov w1, #1
6a00f7c: mov w2, #0x13
6a00f80: bl #0x6a027f8
6a00f84: mov w8, #0x63
6a00f88: b #0x6a01924
6a00f8c: mov x0, x19
6a00f90: mov w1, #1
6a00f94: mov w2, #0x16
6a00f98: b #0x6a012f8
6a00f9c: mov x0, x19
6a00fa0: bl #0x6a03c88
6a00fa4: tbz w0, #0, #0x6a01928
6a00fa8: bl #0x6836474
6a00fac: ldr x8, [x0]
6a00fb0: ldr x8, [x8, #0x10]
6a00fb4: blr x8
6a00fb8: tbz w0, #0, #0x6a01894
6a00fbc: bl #0x6836474
6a00fc0: ldr x8, [x0]
6a00fc4: mov w1, #2
6a00fc8: ldr x8, [x8, #0x128]
6a00fcc: blr x8
6a00fd0: ldr x8, [x22, #0x28]
6a00fd4: ldur x9, [x29, #-8]
6a00fd8: cmp x8, x9
6a00fdc: b.ne #0x6a01950
6a00fe0: mov x0, x19
6a00fe4: mov w1, #0x6c
6a00fe8: b #0x6a018f8
6a00fec: bl #0x66cf4cc
6a00ff0: mov w1, #9
6a00ff4: bl #0x66d058c
6a00ff8: tbz w0, #0, #0x6a01928
6a00ffc: bl #0x691be14
6a01000: tbz w0, #0, #0x6a01928
6a01004: add x0, sp, #0x20
6a01008: bl #0x684c338
6a0100c: add x0, sp, #8
6a01010: bl #0x684c338
6a01014: add x0, sp, #0x20
6a01018: add x1, sp, #8
6a0101c: bl #0x66cc674
6a01020: mov w20, w0
6a01024: add x0, sp, #8
6a01028: bl #0x2ef7b54
6a0102c: add x0, sp, #0x20
6a01030: bl #0x2ef7b54
6a01034: tbz w20, #0, #0x6a01928
6a01038: mov x0, x19
6a0103c: bl #0x6a0093c
6a01040: mov w8, #1
6a01044: b #0x6a01924
6a01048: bl #0x6a00cd4
6a0104c: tbz w0, #0, #0x6a01928
6a01050: mov w8, #2
6a01054: b #0x6a01924
6a01058: adrp x20, #0xa417000
6a0105c: ldrb w8, [x20, #0x111]
6a01060: tbnz w8, #0, #0x6a01084
6a01064: add x0, sp, #0x20
6a01068: bl #0x6a01954
6a0106c: bl #0x66cf4cc
6a01070: add x1, sp, #0x20
6a01074: bl #0x66d032c
6a01078: mov w8, #1
6a0107c: str w0, [x19, #0x3ca0]
6a01080: strb w8, [x20, #0x111]
6a01084: mov w8, #3
6a01088: b #0x6a01924
6a0108c: mov x0, x19
6a01090: bl #0x6a0195c
6a01094: tbz w0, #0, #0x6a01928
6a01098: mov x0, x19
6a0109c: bl #0x6a02000
6a010a0: mov w8, #5
6a010a4: b #0x6a01924
6a010a8: bl #0x66cf4cc
6a010ac: bl #0x66d059c
6a010b0: tbz w0, #0, #0x6a01928
6a010b4: mov x0, x19
6a010b8: bl #0x6a027b0
6a010bc: mov w8, #3
6a010c0: mov x0, x20
6a010c4: movk w8, #0x105, lsl #16
6a010c8: mov x2, xzr
6a010cc: add w1, w8, #0x5d
6a010d0: mov w3, wzr
6a010d4: bl #0x68a3eb4
6a010d8: mov w8, #6
6a010dc: b #0x6a01924
6a010e0: mov x0, x19
6a010e4: mov w1, wzr
6a010e8: mov w2, #2
6a010ec: bl #0x6a027f8
6a010f0: mov w8, #9
6a010f4: b #0x6a01924
6a010f8: mov x0, x19
6a010fc: mov w1, wzr
6a01100: mov w2, #3
6a01104: bl #0x6a027f8
6a01108: mov w8, #0xa
6a0110c: b #0x6a01924
6a01110: mov x0, x19
6a01114: mov w1, wzr
6a01118: mov w2, #5
6a0111c: bl #0x6a027f8
6a01120: mov w8, #0xc
6a01124: b #0x6a01924
6a01128: mov x0, x19
6a0112c: mov w1, wzr
6a01130: mov w2, #6
6a01134: bl #0x6a027f8
6a01138: mov w8, #0xd
6a0113c: b #0x6a01924
6a01140: mov x0, x19
6a01144: mov w1, wzr
6a01148: mov w2, #8
6a0114c: bl #0x6a027f8
6a01150: mov w8, #0xf
6a01154: b #0x6a01924
6a01158: mov x0, x19
6a0115c: mov w1, wzr
6a01160: mov w2, #9
6a01164: bl #0x6a027f8
6a01168: mov w8, #0x10
6a0116c: b #0x6a01924
6a01170: mov x0, x19
6a01174: mov w1, #1
6a01178: mov w2, #2
6a0117c: bl #0x6a027f8
6a01180: mov w8, #0x14
6a01184: b #0x6a01924
6a01188: mov x0, x19
6a0118c: mov w1, #1
6a01190: mov w2, #4
6a01194: bl #0x6a027f8
6a01198: mov w8, #0x16
6a0119c: b #0x6a01924
6a011a0: mov x0, x19
6a011a4: mov w1, #1
6a011a8: mov w2, #5
6a011ac: bl #0x6a027f8
6a011b0: mov w8, #0x17
6a011b4: b #0x6a01924
6a011b8: mov x0, x19
6a011bc: mov w1, #1
6a011c0: mov w2, #6
6a011c4: bl #0x6a027f8
6a011c8: mov w8, #0x18
6a011cc: b #0x6a01924
6a011d0: mov x0, x19
6a011d4: mov w1, #1
6a011d8: mov w2, #7
6a011dc: bl #0x6a027f8
6a011e0: mov w8, #0x19
6a011e4: b #0x6a01924
6a011e8: mov x0, x19
6a011ec: mov w1, #1
6a011f0: mov w2, #8
6a011f4: bl #0x6a027f8
6a011f8: mov w8, #0x1a
6a011fc: b #0x6a01924
6a01200: mov x0, x19
6a01204: bl #0x6a02b40
6a01208: tbz w0, #0, #0x6a01928
6a0120c: bl #0x66cf4cc
6a01210: bl #0x66d059c
6a01214: tbz w0, #0, #0x6a01928
6a01218: bl #0x6a02d20
6a0121c: tbz w0, #0, #0x6a01928
6a01220: bl #0x6cee264
6a01224: mov x21, x0
6a01228: mov x0, x19
6a0122c: bl #0x6a02d4c
6a01230: mov x1, x0
6a01234: mov x0, x21
6a01238: bl #0x6cee928
6a0123c: tbz w0, #0, #0x6a01928
6a01240: mov x0, x19
6a01244: mov w23, #3
6a01248: movk w23, #0x105, lsl #16
6a0124c: bl #0x6a02d54
6a01250: mov x0, x19
6a01254: bl #0x6a03178
6a01258: mov x0, x19
6a0125c: bl #0x6a035e0
6a01260: add w1, w23, #0x60, lsl #12
6a01264: mov x0, x20
6a01268: mov x2, xzr
6a0126c: mov w3, wzr
6a01270: bl #0x68a3eb4
6a01274: mov w8, #0x3868
6a01278: add x0, sp, #0x20
6a0127c: add x21, x19, x8
6a01280: mov x1, x21
6a01284: bl #0x68cb134
6a01288: mov x0, x21
6a0128c: bl #0x68cb17c
6a01290: cbz x0, #0x6a012b0
6a01294: bl #0x7220810
6a01298: tbz w0, #0, #0x6a012b0
6a0129c: add w1, w23, #0x5e
6a012a0: mov x0, x20
6a012a4: mov x2, xzr
6a012a8: mov w3, wzr
6a012ac: bl #0x68a3eb4
6a012b0: add x0, sp, #0x20
6a012b4: bl #0x68cb46c
6a012b8: mov x0, x19
6a012bc: mov w1, #0x36
6a012c0: bl #0x6a0016c
6a012c4: b #0x6a01928
6a012c8: mov w8, #3
6a012cc: mov x0, x20
6a012d0: movk w8, #0x105, lsl #16
6a012d4: mov x2, xzr
6a012d8: add w1, w8, #1
6a012dc: mov w3, wzr
6a012e0: bl #0x68a3eb4
6a012e4: mov w8, #0x38
6a012e8: b #0x6a01924
6a012ec: mov x0, x19
6a012f0: mov w1, #2
6a012f4: mov w2, #0xff
6a012f8: bl #0x6a027f8
6a012fc: mov w8, #0x66
6a01300: b #0x6a01924
6a01304: mov x0, x19
6a01308: mov w1, wzr
6a0130c: mov w2, #1
6a01310: bl #0x6a027f8
6a01314: mov w8, #0x3a
6a01318: b #0x6a01924
6a0131c: mov x0, x19
6a01320: mov w1, wzr
6a01324: mov w2, #3
6a01328: bl #0x6a027f8
6a0132c: mov w8, #0x3c
6a01330: b #0x6a01924
6a01334: mov x0, x19
6a01338: mov w1, wzr
6a0133c: mov w2, #6
6a01340: bl #0x6a027f8
6a01344: mov w8, #0x3f
6a01348: b #0x6a01924
6a0134c: mov x0, x19
6a01350: mov w1, wzr
6a01354: mov w2, #0xa
6a01358: bl #0x6a027f8
6a0135c: mov w8, #0x43
6a01360: b #0x6a01924
6a01364: mov x0, x19
6a01368: mov w1, #1
6a0136c: mov w2, wzr
6a01370: bl #0x6a027f8
6a01374: mov w8, #0x44
6a01378: b #0x6a01924
6a0137c: mov x0, x19
6a01380: mov w1, #1
6a01384: mov w2, #3
6a01388: bl #0x6a027f8
6a0138c: mov w8, #0x47
6a01390: b #0x6a01924
6a01394: mov x0, x19
6a01398: mov w1, #1
6a0139c: mov w2, #4
6a013a0: bl #0x6a027f8
6a013a4: mov w8, #0x48
6a013a8: b #0x6a01924
6a013ac: mov x0, x19
6a013b0: mov w1, #1
6a013b4: mov w2, #0xb
6a013b8: bl #0x6a027f8
6a013bc: mov w8, #0x5b
6a013c0: b #0x6a01924
6a013c4: mov x0, x19
6a013c8: mov w1, #1
6a013cc: mov w2, #0x10
6a013d0: bl #0x6a027f8
6a013d4: mov w8, #0x60
6a013d8: b #0x6a01924
6a013dc: mov x0, x19
6a013e0: mov w1, #1
6a013e4: b #0x6a01798
6a013e8: mov w8, #3
6a013ec: mov x0, x20
6a013f0: movk w8, #0x105, lsl #16
6a013f4: mov x2, xzr
6a013f8: add w1, w8, #1
6a013fc: mov w3, wzr
6a01400: bl #0x68a3eb4
6a01404: mov w8, #0x69
6a01408: str w8, [x19, #8]
6a0140c: mov x0, x19
6a01410: mov w1, wzr
6a01414: bl #0x6a03a84
6a01418: mov w8, #0x6a
6a0141c: b #0x6a01924
6a01420: adrp x8, #0xa417000
6a01424: ldrb w8, [x8, #0x111]
6a01428: cmp w8, #1
6a0142c: b.ne #0x6a01440
6a01430: bl #0x66cf4cc
6a01434: mov w1, #0xa
6a01438: bl #0x66d058c
6a0143c: tbz w0, #0, #0x6a01928
6a01440: mov w8, #4
6a01444: b #0x6a01924
6a01448: mov w8, #0x3ca4
6a0144c: add x20, x19, x8
6a01450: ldrb w8, [x20]
6a01454: cbz w8, #0x6a018c8
6a01458: mov x0, x19
6a0145c: mov w1, #2
6a01460: mov w2, #0xff
6a01464: b #0x6a018d4
6a01468: mov x0, x19
6a0146c: mov w1, wzr
6a01470: mov w2, #1
6a01474: bl #0x6a027f8
6a01478: mov w8, #8
6a0147c: b #0x6a01924
6a01480: mov x0, x19
6a01484: mov w1, wzr
6a01488: mov w2, #4
6a0148c: bl #0x6a027f8
6a01490: mov w8, #0xb
6a01494: b #0x6a01924
6a01498: mov x0, x19
6a0149c: mov w1, wzr
6a014a0: mov w2, #7
6a014a4: bl #0x6a027f8
6a014a8: mov w8, #0xe
6a014ac: b #0x6a01924
6a014b0: mov x0, x19
6a014b4: mov w1, wzr
6a014b8: mov w2, #0xa
6a014bc: bl #0x6a027f8
6a014c0: mov w8, #0x11
6a014c4: b #0x6a01924
6a014c8: mov x0, x19
6a014cc: mov w1, #1
6a014d0: mov w2, wzr
6a014d4: bl #0x6a027f8
6a014d8: mov w8, #0x12
6a014dc: b #0x6a01924
6a014e0: mov x0, x19
6a014e4: mov w1, #1
6a014e8: mov w2, #1
6a014ec: bl #0x6a027f8
6a014f0: mov w8, #0x13
6a014f4: b #0x6a01924
6a014f8: mov x0, x19
6a014fc: mov w1, #1
6a01500: mov w2, #3
6a01504: bl #0x6a027f8
6a01508: mov w8, #0x15
6a0150c: b #0x6a01924
6a01510: mov x0, x19
6a01514: mov w1, #1
6a01518: mov w2, #9
6a0151c: bl #0x6a027f8
6a01520: mov w8, #0x1b
6a01524: b #0x6a01924
6a01528: mov x0, x19
6a0152c: mov w1, #1
6a01530: mov w2, #0xa
6a01534: bl #0x6a027f8
6a01538: bl #0x66cf4cc
6a0153c: bl #0x66d0764
6a01540: b #0x6a018e0
6a01544: mov x0, x19
6a01548: mov w1, wzr
6a0154c: mov w2, #2
6a01550: bl #0x6a027f8
6a01554: mov w8, #0x3b
6a01558: b #0x6a01924
6a0155c: mov x0, x19
6a01560: mov w1, wzr
6a01564: mov w2, #4
6a01568: bl #0x6a027f8
6a0156c: mov w8, #0x3d
6a01570: b #0x6a01924
6a01574: mov x0, x19
6a01578: mov w1, wzr
6a0157c: mov w2, #5
6a01580: bl #0x6a027f8
6a01584: mov w8, #0x3e
6a01588: b #0x6a01924
6a0158c: mov x0, x19
6a01590: mov w1, wzr
6a01594: mov w2, #7
6a01598: bl #0x6a027f8
6a0159c: mov w8, #0x40
6a015a0: b #0x6a01924
6a015a4: mov x0, x19
6a015a8: mov w1, #1
6a015ac: mov w2, #1
6a015b0: bl #0x6a027f8
6a015b4: mov w8, #0x45
6a015b8: b #0x6a01924
6a015bc: mov x0, x19
6a015c0: mov w1, #1
6a015c4: mov w2, #5
6a015c8: bl #0x6a027f8
6a015cc: mov w8, #0x49
6a015d0: b #0x6a01924
6a015d4: mov x0, x19
6a015d8: mov w1, #1
6a015dc: mov w2, #6
6a015e0: bl #0x6a027f8
6a015e4: mov w8, #0x4a
6a015e8: b #0x6a01924
6a015ec: mov x0, x19
6a015f0: mov w1, #1
6a015f4: mov w2, #7
6a015f8: bl #0x6a027f8
6a015fc: mov w8, #0x4b
6a01600: b #0x6a01924
6a01604: mov x0, x19
6a01608: mov w1, wzr
6a0160c: mov w2, #0xb
6a01610: bl #0x6a027f8
6a01614: mov w8, #0x4f
6a01618: b #0x6a01924
6a0161c: mov x0, x19
6a01620: mov w1, wzr
6a01624: mov w2, #0xd
6a01628: bl #0x6a027f8
6a0162c: mov w8, #0x51
6a01630: b #0x6a01924
6a01634: mov x0, x19
6a01638: mov w1, wzr
6a0163c: mov w2, #0xe
6a01640: bl #0x6a027f8
6a01644: mov w8, #0x52
6a01648: b #0x6a01924
6a0164c: mov x0, x19
6a01650: mov w1, wzr
6a01654: mov w2, #0x10
6a01658: bl #0x6a027f8
6a0165c: mov w8, #0x54
6a01660: b #0x6a01924
6a01664: mov x0, x19
6a01668: mov w1, wzr
6a0166c: mov w2, #0x11
6a01670: bl #0x6a027f8
6a01674: mov w8, #0x55
6a01678: b #0x6a01924
6a0167c: mov x0, x19
6a01680: mov w1, wzr
6a01684: b #0x6a016f0
6a01688: mov x0, x19
6a0168c: mov w1, wzr
6a01690: mov w2, #0x16
6a01694: bl #0x6a027f8
6a01698: mov w8, #0x5a
6a0169c: b #0x6a01924
6a016a0: mov x0, x19
6a016a4: mov w1, #1
6a016a8: mov w2, #0xc
6a016ac: bl #0x6a027f8
6a016b0: mov w8, #0x5c
6a016b4: b #0x6a01924
6a016b8: mov x0, x19
6a016bc: mov w1, #1
6a016c0: mov w2, #0xe
6a016c4: bl #0x6a027f8
6a016c8: mov w8, #0x5e
6a016cc: b #0x6a01924
6a016d0: mov x0, x19
6a016d4: mov w1, #1
6a016d8: mov w2, #0x12
6a016dc: bl #0x6a027f8
6a016e0: mov w8, #0x62
6a016e4: b #0x6a01924
6a016e8: mov x0, x19
6a016ec: mov w1, #1
6a016f0: mov w2, #0x15
6a016f4: bl #0x6a027f8
6a016f8: mov w8, #0x65
6a016fc: b #0x6a01924
6a01700: mov x0, x19
6a01704: mov w1, #1
6a01708: mov w2, #2
6a0170c: bl #0x6a027f8
6a01710: mov w8, #0x46
6a01714: b #0x6a01924
6a01718: mov x0, x19
6a0171c: mov w1, #1
6a01720: mov w2, #0xa
6a01724: bl #0x6a027f8
6a01728: mov w8, #0x3818
6a0172c: add x20, x19, x8
6a01730: mov x0, x20
6a01734: bl #0x68b0408
6a01738: cbz x0, #0x6a01910
6a0173c: bl #0x721f710
6a01740: mov w21, w0
6a01744: mov x0, x20
6a01748: bl #0x68b047c
6a0174c: tst w21, #1
6a01750: mov w8, #0x66
6a01754: mov w9, #0x4e
6a01758: csel w8, w9, w8, ne
6a0175c: b #0x6a01924
6a01760: mov x0, x19
6a01764: mov w1, wzr
6a01768: mov w2, #0x12
6a0176c: bl #0x6a027f8
6a01770: mov w8, #0x56
6a01774: b #0x6a01924
6a01778: mov x0, x19
6a0177c: mov w1, wzr
6a01780: mov w2, #0x13
6a01784: bl #0x6a027f8
6a01788: mov w8, #0x57
6a0178c: b #0x6a01924
6a01790: mov x0, x19
6a01794: mov w1, wzr
6a01798: mov w2, #0x14
6a0179c: bl #0x6a027f8
6a017a0: mov w8, #0x64
6a017a4: b #0x6a01924
6a017a8: mov x0, x19
6a017ac: mov w1, #1
6a017b0: mov w2, #0xf
6a017b4: bl #0x6a027f8
6a017b8: mov w8, #0x5f
6a017bc: b #0x6a01924
6a017c0: mov x0, x19
6a017c4: mov w1, #1
6a017c8: mov w2, #0x11
6a017cc: bl #0x6a027f8
6a017d0: mov w8, #0x61
6a017d4: b #0x6a01924
6a017d8: mov x0, x19
6a017dc: bl #0x6a02b40
6a017e0: tbz w0, #0, #0x6a01928
6a017e4: bl #0x66cf4cc
6a017e8: bl #0x66d059c
6a017ec: tbz w0, #0, #0x6a01928
6a017f0: mov w20, #0x58
6a017f4: str wzr, [sp, #0x20]
6a017f8: b #0x6a01810
6a017fc: add x0, sp, #0x20
6a01800: bl #0x6837104
6a01804: ldr w8, [sp, #0x20]
6a01808: cmp w8, #2
6a0180c: b.ge #0x6a012b8
6a01810: mov w8, wzr
6a01814: str wzr, [sp, #8]
6a01818: b #0x6a01830
6a0181c: add x0, sp, #8
6a01820: bl #0x6837a60
6a01824: ldr w8, [sp, #8]
6a01828: cmp w8, #0xb
6a0182c: b.ge #0x6a017fc
6a01830: ldr w9, [sp, #0x20]
6a01834: nop
6a01838: umaddl x9, w9, w20, x19
6a0183c: add x8, x9, w8, sxtw #3
6a01840: ldr x0, [x8, #0x10]
6a01844: cbz x0, #0x6a0181c
6a01848: bl #0x70130b4
6a0184c: b #0x6a0181c
6a01850: mov x0, x19
6a01854: bl #0x6a03c88
6a01858: tbz w0, #0, #0x6a01928
6a0185c: mov w8, #0x6b
6a01860: str w8, [x19, #8]
6a01864: ldr x8, [x22, #0x28]
6a01868: ldur x9, [x29, #-8]
6a0186c: cmp x8, x9
6a01870: b.ne #0x6a01950
6a01874: mov x0, x19
6a01878: mov w1, #1
6a0187c: ldp x20, x19, [sp, #0x70]
6a01880: ldp x22, x21, [sp, #0x60]
6a01884: ldp x29, x30, [sp, #0x40]
6a01888: ldr x23, [sp, #0x50]
6a0188c: add sp, sp, #0x80
6a01890: b #0x6a03a84
6a01894: mov w1, #3
6a01898: mov x0, x20
6a0189c: movk w1, #0x105, lsl #16
6a018a0: mov x2, xzr
6a018a4: mov w3, wzr
6a018a8: bl #0x68a3eb4
6a018ac: ldr x8, [x22, #0x28]
6a018b0: ldur x9, [x29, #-8]
6a018b4: cmp x8, x9
6a018b8: b.ne #0x6a01950
6a018bc: mov x0, x19
6a018c0: mov w1, #0x36
6a018c4: b #0x6a018f8
6a018c8: mov x0, x19
6a018cc: mov w1, wzr
6a018d0: mov w2, wzr
6a018d4: bl #0x6a027f8
6a018d8: ldrb w8, [x20]
6a018dc: cbz w8, #0x6a01920
6a018e0: ldr x8, [x22, #0x28]
6a018e4: ldur x9, [x29, #-8]
6a018e8: cmp x8, x9
6a018ec: b.ne #0x6a01950
6a018f0: mov x0, x19
6a018f4: mov w1, #0x34
6a018f8: ldp x20, x19, [sp, #0x70]
6a018fc: ldp x22, x21, [sp, #0x60]
6a01900: ldp x29, x30, [sp, #0x40]
6a01904: ldr x23, [sp, #0x50]
6a01908: add sp, sp, #0x80
6a0190c: b #0x6a0016c
6a01910: mov x0, x20
6a01914: bl #0x68b047c
6a01918: mov w8, #0x66
6a0191c: b #0x6a01924
6a01920: mov w8, #7
6a01924: str w8, [x19, #8]
6a01928: ldr x8, [x22, #0x28]
6a0192c: ldur x9, [x29, #-8]
6a01930: cmp x8, x9
6a01934: b.ne #0x6a01950
6a01938: ldp x20, x19, [sp, #0x70]
6a0193c: ldp x22, x21, [sp, #0x60]
6a01940: ldp x29, x30, [sp, #0x40]
6a01944: ldr x23, [sp, #0x50]
6a01948: add sp, sp, #0x80
6a0194c: ret
6a01950: bl #0x8b35290   ; PLT __stack_chk_fail
6a01954: str wzr, [x0]
6a01958: ret
6a0195c: sub sp, sp, #0xa0
6a01960: stp x29, x30, [sp, #0x40]
6a01964: stp x28, x27, [sp, #0x50]
6a01968: stp x26, x25, [sp, #0x60]
6a0196c: stp x24, x23, [sp, #0x70]
6a01970: stp x22, x21, [sp, #0x80]
6a01974: stp x20, x19, [sp, #0x90]
6a01978: add x29, sp, #0x40
6a0197c: mrs x21, tpidr_el0
6a01980: mov x19, x0
6a01984: ldr x8, [x21, #0x28]
6a01988: stur x8, [x29, #-8]
6a0198c: bl #0x6a03e1c
6a01990: mov w8, #0x3b88
6a01994: add x20, x19, x8
6a01998: mov x0, x20
6a0199c: bl #0x699021c
6a019a0: cbz x0, #0x6a019b0
6a019a4: bl #0x724cc10
6a019a8: mov w23, w0
6a019ac: b #0x6a019b4
6a019b0: mov w23, wzr
6a019b4: mov x0, x20
6a019b8: bl #0x68b9ef8
6a019bc: mov w8, #0x3868
6a019c0: add x20, x19, x8
6a019c4: mov x0, x20
6a019c8: bl #0x68b694c
6a019cc: mov w8, #0x3818
6a019d0: mov x26, x0
6a019d4: add x22, x19, x8
6a019d8: mov x0, x22
6a019dc: bl #0x68b0408
6a019e0: cbz x26, #0x6a01b60
6a019e4: cbz x0, #0x6a01b60
6a019e8: stur x0, [x29, #-0x18]
6a019ec: mov x0, x26
6a019f0: stur w23, [x29, #-0x1c]
6a019f4: bl #0x6836ee4
6a019f8: and w24, w0, #0xff
6a019fc: mov x0, x26
6a01a00: bl #0x6999ed0
6a01a04: and w23, w0, #0xff
6a01a08: mov x0, x26
6a01a0c: bl #0x7220b0c
6a01a10: stur wzr, [x29, #-0xc]
6a01a14: stp x20, x21, [sp, #0x10]
6a01a18: str x22, [sp, #8]
6a01a1c: str w24, [sp, #4]
6a01a20: tbz w0, #0, #0x6a01b78
6a01a24: ldur w8, [x29, #-0x1c]
6a01a28: tbz w8, #0, #0x6a01c24
6a01a2c: mov w28, #1
6a01a30: mov w24, #0x58
6a01a34: mov w20, #0x50
6a01a38: mov w21, #0x39f8
6a01a3c: mov w25, #0xb
6a01a40: mov w22, #0x3bd8
6a01a44: b #0x6a01a5c
6a01a48: sub x0, x29, #0xc
6a01a4c: bl #0x6837104
6a01a50: ldur w8, [x29, #-0xc]
6a01a54: cmp w8, #2
6a01a58: b.ge #0x6a01db8
6a01a5c: mov w9, wzr
6a01a60: stur wzr, [x29, #-0x10]
6a01a64: b #0x6a01a98
6a01a68: mov x27, x0
6a01a6c: bl #0x6993afc
6a01a70: ldp w9, w8, [x29, #-0x10]
6a01a74: sxtw x9, w9
6a01a78: umaddl x8, w8, w24, x19
6a01a7c: add x8, x8, x9, lsl #3
6a01a80: str x27, [x8, #0x10]
6a01a84: sub x0, x29, #0x10
6a01a88: bl #0x6837a60
6a01a8c: ldur w9, [x29, #-0x10]
6a01a90: cmp w9, #0xb
6a01a94: b.ge #0x6a01a48
6a01a98: ldur w8, [x29, #-0xc]
6a01a9c: nop
6a01aa0: umaddl x10, w8, w24, x19
6a01aa4: add x10, x10, w9, sxtw #3
6a01aa8: ldr x10, [x10, #0x10]
6a01aac: cbnz x10, #0x6a01a84
6a01ab0: cbnz w8, #0x6a01ad4
6a01ab4: cmp w9, #9
6a01ab8: b.ne #0x6a01ad4
6a01abc: mov w27, #1
6a01ac0: umaddl x8, w8, w20, x19
6a01ac4: add x0, x8, x21
6a01ac8: bl #0x68cb5c4
6a01acc: cbnz x0, #0x6a01af0
6a01ad0: b #0x6a01b30
6a01ad4: cmp w8, #1
6a01ad8: ccmp w9, #0, #0, eq
6a01adc: cset w27, eq
6a01ae0: umaddl x8, w8, w20, x19
6a01ae4: add x0, x8, x21
6a01ae8: bl #0x68cb5c4
6a01aec: cbz x0, #0x6a01b30
6a01af0: ldur w1, [x29, #-0x10]
6a01af4: bl #0x722c138
6a01af8: cmp w0, #0xa
6a01afc: b.gt #0x6a01b30
6a01b00: ldur w8, [x29, #-0xc]
6a01b04: nop
6a01b08: umaddl x9, w8, w25, x19
6a01b0c: umaddl x8, w8, w20, x19
6a01b10: add x9, x9, w0, uxtw
6a01b14: add x0, x8, x21
6a01b18: ldrb w9, [x9, x22]
6a01b1c: cmp w9, #0
6a01b20: csel w27, wzr, w27, eq
6a01b24: bl #0x68b8e44
6a01b28: tbz w27, #0, #0x6a01a84
6a01b2c: b #0x6a01b48
6a01b30: ldur w8, [x29, #-0xc]
6a01b34: nop
6a01b38: umaddl x8, w8, w20, x19
6a01b3c: add x0, x8, x21
6a01b40: bl #0x68b8e44
6a01b44: cbz w27, #0x6a01a84
6a01b48: sub x0, x29, #0xc
6a01b4c: sub x1, x29, #0x10
6a01b50: bl #0x70c1c00
6a01b54: cbnz x0, #0x6a01a68
6a01b58: mov w28, wzr
6a01b5c: b #0x6a01a84
6a01b60: mov x0, x20
6a01b64: bl #0x68b69a8
6a01b68: mov x0, x22
6a01b6c: bl #0x68b047c
6a01b70: mov w28, wzr
6a01b74: b #0x6a01ea4
6a01b78: ldur w8, [x29, #-0x1c]
6a01b7c: tbz w8, #0, #0x6a01d2c
6a01b80: mov w28, #1
6a01b84: mov w20, #0x58
6a01b88: b #0x6a01ba0
6a01b8c: sub x0, x29, #0xc
6a01b90: bl #0x6837104
6a01b94: ldur w8, [x29, #-0xc]
6a01b98: cmp w8, #2
6a01b9c: b.ge #0x6a01db8
6a01ba0: mov w8, wzr
6a01ba4: stur wzr, [x29, #-0x10]
6a01ba8: b #0x6a01bdc
6a01bac: mov x27, x0
6a01bb0: bl #0x6993afc
6a01bb4: ldp w9, w8, [x29, #-0x10]
6a01bb8: sxtw x9, w9
6a01bbc: umaddl x8, w8, w20, x19
6a01bc0: add x8, x8, x9, lsl #3
6a01bc4: str x27, [x8, #0x10]
6a01bc8: sub x0, x29, #0x10
6a01bcc: bl #0x6837a60
6a01bd0: ldur w8, [x29, #-0x10]
6a01bd4: cmp w8, #0xb
6a01bd8: b.ge #0x6a01b8c
6a01bdc: ldur w9, [x29, #-0xc]
6a01be0: nop
6a01be4: umaddl x10, w9, w20, x19
6a01be8: add x10, x10, w8, sxtw #3
6a01bec: ldr x10, [x10, #0x10]
6a01bf0: cbnz x10, #0x6a01bc8
6a01bf4: cbnz w9, #0x6a01c00
6a01bf8: cmp w8, #9
6a01bfc: b.eq #0x6a01c0c
6a01c00: cmp w9, #1
6a01c04: b.ne #0x6a01bc8
6a01c08: cbnz w8, #0x6a01bc8
6a01c0c: sub x0, x29, #0xc
6a01c10: sub x1, x29, #0x10
6a01c14: bl #0x70c1c00
6a01c18: cbnz x0, #0x6a01bac
6a01c1c: mov w28, wzr
6a01c20: b #0x6a01bc8
6a01c24: mov w28, #1
6a01c28: mov w20, #0x58
6a01c2c: mov w21, #0x50
6a01c30: mov w22, #0x39f8
6a01c34: mov w24, #0xb
6a01c38: mov w25, #0x3bd8
6a01c3c: b #0x6a01c54
6a01c40: sub x0, x29, #0xc
6a01c44: bl #0x6837104
6a01c48: ldur w8, [x29, #-0xc]
6a01c4c: cmp w8, #2
6a01c50: b.ge #0x6a01db8
6a01c54: mov w8, wzr
6a01c58: stur wzr, [x29, #-0x10]
6a01c5c: b #0x6a01c90
6a01c60: mov x27, x0
6a01c64: bl #0x6993afc
6a01c68: ldp w9, w8, [x29, #-0x10]
6a01c6c: sxtw x9, w9
6a01c70: umaddl x8, w8, w20, x19
6a01c74: add x8, x8, x9, lsl #3
6a01c78: str x27, [x8, #0x10]
6a01c7c: sub x0, x29, #0x10
6a01c80: bl #0x6837a60
6a01c84: ldur w8, [x29, #-0x10]
6a01c88: cmp w8, #0xb
6a01c8c: b.ge #0x6a01c40
6a01c90: ldur w9, [x29, #-0xc]
6a01c94: nop
6a01c98: umaddl x10, w9, w20, x19
6a01c9c: add x8, x10, w8, sxtw #3
6a01ca0: ldr x8, [x8, #0x10]
6a01ca4: cbnz x8, #0x6a01c7c
6a01ca8: umaddl x8, w9, w21, x19
6a01cac: add x0, x8, x22
6a01cb0: bl #0x68cb5c4
6a01cb4: cbz x0, #0x6a01d00
6a01cb8: ldur w1, [x29, #-0x10]
6a01cbc: bl #0x722c138
6a01cc0: cmp w0, #0xa
6a01cc4: b.gt #0x6a01d00
6a01cc8: ldur w8, [x29, #-0xc]
6a01ccc: nop
6a01cd0: umaddl x9, w8, w24, x19
6a01cd4: umaddl x8, w8, w21, x19
6a01cd8: add x9, x9, w0, uxtw
6a01cdc: add x0, x8, x22
6a01ce0: ldrb w27, [x9, x25]
6a01ce4: bl #0x68b8e44
6a01ce8: cbz w27, #0x6a01c7c
6a01cec: sub x0, x29, #0xc
6a01cf0: sub x1, x29, #0x10
6a01cf4: bl #0x70c1c00
6a01cf8: cbnz x0, #0x6a01c60
6a01cfc: b #0x6a01d24
6a01d00: ldur w8, [x29, #-0xc]
6a01d04: nop
6a01d08: umaddl x8, w8, w21, x19
6a01d0c: add x0, x8, x22
6a01d10: bl #0x68b8e44
6a01d14: sub x0, x29, #0xc
6a01d18: sub x1, x29, #0x10
6a01d1c: bl #0x70c1c00
6a01d20: cbnz x0, #0x6a01c60
6a01d24: mov w28, wzr
6a01d28: b #0x6a01c7c
6a01d2c: mov w28, #1
6a01d30: mov w20, #0x58
6a01d34: b #0x6a01d4c
6a01d38: sub x0, x29, #0xc
6a01d3c: bl #0x6837104
6a01d40: ldur w8, [x29, #-0xc]
6a01d44: cmp w8, #2
6a01d48: b.ge #0x6a01db8
6a01d4c: mov w8, wzr
6a01d50: stur wzr, [x29, #-0x10]
6a01d54: b #0x6a01d88
6a01d58: mov x27, x0
6a01d5c: bl #0x6993afc
6a01d60: ldp w9, w8, [x29, #-0x10]
6a01d64: sxtw x9, w9
6a01d68: umaddl x8, w8, w20, x19
6a01d6c: add x8, x8, x9, lsl #3
6a01d70: str x27, [x8, #0x10]
6a01d74: sub x0, x29, #0x10
6a01d78: bl #0x6837a60
6a01d7c: ldur w8, [x29, #-0x10]
6a01d80: cmp w8, #0xb
6a01d84: b.ge #0x6a01d38
6a01d88: ldur w9, [x29, #-0xc]
6a01d8c: nop
6a01d90: umaddl x9, w9, w20, x19
6a01d94: add x8, x9, w8, sxtw #3
6a01d98: ldr x8, [x8, #0x10]
6a01d9c: cbnz x8, #0x6a01d74
6a01da0: sub x0, x29, #0xc
6a01da4: sub x1, x29, #0x10
6a01da8: bl #0x70c1c00
6a01dac: cbnz x0, #0x6a01d58
6a01db0: mov w28, wzr
6a01db4: b #0x6a01d74
6a01db8: ldur x0, [x29, #-0x18]
6a01dbc: mov w1, wzr
6a01dc0: bl #0x721f6bc
6a01dc4: tbz w0, #0, #0x6a01df8
6a01dc8: ldp x20, x21, [sp, #0x10]
6a01dcc: stur wzr, [x29, #-0xc]
6a01dd0: ldr x22, [sp, #8]
6a01dd4: ldr w25, [sp, #4]
6a01dd8: ldur w24, [x29, #-0x1c]
6a01ddc: tbz w24, #0, #0x6a01ed8
6a01de0: sub x0, x29, #0xc
6a01de4: bl #0x69ffcb4
6a01de8: ldur w8, [x29, #-0xc]
6a01dec: cmp w8, #3
6a01df0: b.lt #0x6a01de0
6a01df4: b #0x6a01e08
6a01df8: ldp x20, x21, [sp, #0x10]
6a01dfc: ldr x22, [sp, #8]
6a01e00: ldr w25, [sp, #4]
6a01e04: ldur w24, [x29, #-0x1c]
6a01e08: ldur x0, [x29, #-0x18]
6a01e0c: bl #0x721f71c
6a01e10: orn w8, w24, w0
6a01e14: tbnz w8, #0, #0x6a01e44
6a01e18: ldr x8, [x19, #0xd8]
6a01e1c: cbnz x8, #0x6a01e44
6a01e20: ldr w1, [x26, #0x50]
6a01e24: mov w0, wzr
6a01e28: mov w2, w23
6a01e2c: mov w3, w25
6a01e30: bl #0x6fa6f5c
6a01e34: cbz x0, #0x6a01fe8
6a01e38: mov x26, x0
6a01e3c: bl #0x6993afc
6a01e40: str x26, [x19, #0xd8]
6a01e44: ldur x0, [x29, #-0x18]
6a01e48: bl #0x721f728
6a01e4c: tbz w0, #0, #0x6a01e6c
6a01e50: stur wzr, [x29, #-0xc]
6a01e54: tbz w24, #0, #0x6a01f38
6a01e58: sub x0, x29, #0xc
6a01e5c: bl #0x6837104
6a01e60: ldur w8, [x29, #-0xc]
6a01e64: cmp w8, #2
6a01e68: b.lt #0x6a01e58
6a01e6c: ldur x0, [x29, #-0x18]
6a01e70: bl #0x721f734
6a01e74: tbz w0, #0, #0x6a01e94
6a01e78: stur wzr, [x29, #-0xc]
6a01e7c: tbz w24, #0, #0x6a01f8c
6a01e80: sub x0, x29, #0xc
6a01e84: bl #0x6837104
6a01e88: ldur w8, [x29, #-0xc]
6a01e8c: cmp w8, #2
6a01e90: b.lt #0x6a01e80
6a01e94: mov x0, x20
6a01e98: bl #0x68b69a8
6a01e9c: mov x0, x22
6a01ea0: bl #0x68b047c
6a01ea4: ldr x8, [x21, #0x28]
6a01ea8: ldur x9, [x29, #-8]
6a01eac: cmp x8, x9
6a01eb0: b.ne #0x6a01ffc
6a01eb4: and w0, w28, #1
6a01eb8: ldp x20, x19, [sp, #0x90]
6a01ebc: ldp x22, x21, [sp, #0x80]
6a01ec0: ldp x24, x23, [sp, #0x70]
6a01ec4: ldp x26, x25, [sp, #0x60]
6a01ec8: ldp x28, x27, [sp, #0x50]
6a01ecc: ldp x29, x30, [sp, #0x40]
6a01ed0: add sp, sp, #0xa0
6a01ed4: ret
6a01ed8: mov w8, wzr
6a01edc: b #0x6a01f08
6a01ee0: mov x27, x0
6a01ee4: bl #0x6993afc
6a01ee8: ldur w8, [x29, #-0xc]
6a01eec: add x8, x19, x8, lsl #3
6a01ef0: str x27, [x8, #0xc0]
6a01ef4: sub x0, x29, #0xc
6a01ef8: bl #0x69ffcb4
6a01efc: ldur w8, [x29, #-0xc]
6a01f00: cmp w8, #3
6a01f04: b.ge #0x6a01e08
6a01f08: add x9, x19, w8, uxtw #3
6a01f0c: ldr x9, [x9, #0xc0]
6a01f10: cbnz x9, #0x6a01ef4
6a01f14: mov w0, w8
6a01f18: mov w2, w23
6a01f1c: mov w3, w25
6a01f20: add x8, x26, x0, lsl #2
6a01f24: ldr w1, [x8, #0x50]
6a01f28: bl #0x71e1ea8
6a01f2c: cbnz x0, #0x6a01ee0
6a01f30: mov w28, wzr
6a01f34: b #0x6a01ef4
6a01f38: mov w0, wzr
6a01f3c: b #0x6a01f68
6a01f40: mov x26, x0
6a01f44: bl #0x6993afc
6a01f48: ldur w8, [x29, #-0xc]
6a01f4c: add x8, x19, x8, lsl #3
6a01f50: str x26, [x8, #0xe0]
6a01f54: sub x0, x29, #0xc
6a01f58: bl #0x6837104
6a01f5c: ldur w0, [x29, #-0xc]
6a01f60: cmp w0, #2
6a01f64: b.ge #0x6a01e6c
6a01f68: add x8, x19, w0, uxtw #3
6a01f6c: ldr x8, [x8, #0xe0]
6a01f70: cbnz x8, #0x6a01f54
6a01f74: mov w1, w23
6a01f78: mov w2, w25
6a01f7c: bl #0x6fbc05c
6a01f80: cbnz x0, #0x6a01f40
6a01f84: mov w28, wzr
6a01f88: b #0x6a01f54
6a01f8c: mov w1, wzr
6a01f90: b #0x6a01fbc
6a01f94: mov x24, x0
6a01f98: bl #0x6993afc
6a01f9c: ldur w8, [x29, #-0xc]
6a01fa0: add x8, x19, x8, lsl #3
6a01fa4: str x24, [x8, #0xf0]
6a01fa8: sub x0, x29, #0xc
6a01fac: bl #0x6837104
6a01fb0: ldur w1, [x29, #-0xc]
6a01fb4: cmp w1, #2
6a01fb8: b.ge #0x6a01e94
6a01fbc: add x8, x19, w1, uxtw #3
6a01fc0: ldr x8, [x8, #0xf0]
6a01fc4: cbnz x8, #0x6a01fa8
6a01fc8: cmp w1, #1
6a01fcc: mov w2, w23
6a01fd0: cset w0, eq
6a01fd4: mov w3, w25
6a01fd8: bl #0x6fb926c
6a01fdc: cbnz x0, #0x6a01f94
6a01fe0: mov w28, wzr
6a01fe4: b #0x6a01fa8
6a01fe8: mov w28, wzr
6a01fec: ldur x0, [x29, #-0x18]
6a01ff0: bl #0x721f728
6a01ff4: tbnz w0, #0, #0x6a01e50
6a01ff8: b #0x6a01e6c
6a01ffc: bl #0x8b35290   ; PLT __stack_chk_fail
6a02000: sub sp, sp, #0x90
6a02004: stp x29, x30, [sp, #0x30]
6a02008: stp x28, x27, [sp, #0x40]
6a0200c: stp x26, x25, [sp, #0x50]
6a02010: stp x24, x23, [sp, #0x60]
6a02014: stp x22, x21, [sp, #0x70]
6a02018: stp x20, x19, [sp, #0x80]
6a0201c: add x29, sp, #0x30
6a02020: mov w9, #0x3818
6a02024: mrs x19, tpidr_el0
6a02028: add x21, x0, x9
6a0202c: mov x20, x0
6a02030: ldr x8, [x19, #0x28]
6a02034: mov x0, x21
6a02038: stur x8, [x29, #-8]
6a0203c: bl #0x68b0408
6a02040: cbz x0, #0x6a02248
6a02044: stp x19, x0, [sp, #0x10]
6a02048: str x21, [sp, #8]
6a0204c: bl #0x7218b5c
6a02050: str w0, [sp, #4]
6a02054: bl #0x6a04904
6a02058: mov x21, x0
6a0205c: bl #0x6a04944
6a02060: str x0, [x20, #0x3c88]
6a02064: bl #0x6a0498c
6a02068: ldr x8, [x20]
6a0206c: mov x23, x0
6a02070: mov x0, x20
6a02074: ldr x8, [x8, #0x18]
6a02078: blr x8
6a0207c: mov x25, x0
6a02080: bl #0x6836474
6a02084: ldr x8, [x0]
6a02088: ldr x8, [x8, #0x10]
6a0208c: blr x8
6a02090: tbnz w0, #0, #0x6a020ac
6a02094: ldr x1, [x20, #0x3c40]
6a02098: cbz x1, #0x6a020ac
6a0209c: ldr x8, [x25]
6a020a0: mov x0, x25
6a020a4: ldr x8, [x8, #0x28]
6a020a8: blr x8
6a020ac: mov x28, xzr
6a020b0: mov w22, #0x58
6a020b4: stur wzr, [x29, #-0xc]
6a020b8: adrp x25, #0xb7a000
6a020bc: add x25, x25, #0x14
6a020c0: ldur w8, [x29, #-0xc]
6a020c4: nop
6a020c8: umaddl x8, w8, w22, x20
6a020cc: add x8, x8, x28, lsl #3
6a020d0: ldr x8, [x8, #0x10]
6a020d4: cbz x8, #0x6a02154
6a020d8: bl #0x6a049cc
6a020dc: mov x26, x0
6a020e0: bl #0x6a04a0c
6a020e4: ldur w8, [x29, #-0xc]
6a020e8: add x19, x20, #0x10
6a020ec: lsl x24, x28, #3
6a020f0: ldr x9, [x23]
6a020f4: mov x27, x0
6a020f8: mov x0, x23
6a020fc: umaddl x8, w8, w22, x19
6a02100: ldr x1, [x8, x24]
6a02104: ldr x8, [x9, #0x20]
6a02108: blr x8
6a0210c: ldur w8, [x29, #-0xc]
6a02110: mov x0, x26
6a02114: ldr x9, [x26]
6a02118: nop
6a0211c: umaddl x8, w8, w22, x19
6a02120: ldr x1, [x8, x24]
6a02124: ldr x8, [x9, #0x20]
6a02128: blr x8
6a0212c: mov x0, x26
6a02130: mov x1, x25
6a02134: bl #0x6833104
6a02138: ldur w8, [x29, #-0xc]
6a0213c: mov x1, x27
6a02140: ldr x3, [x20, #0x3c40]
6a02144: mov x2, x21
6a02148: umaddl x8, w8, w22, x19
6a0214c: ldr x0, [x8, x24]
6a02150: bl #0x6a04454
6a02154: add x28, x28, #1
6a02158: cmp x28, #0xb
6a0215c: b.ne #0x6a020c0
6a02160: sub x0, x29, #0xc
6a02164: bl #0x6837104
6a02168: ldur w8, [x29, #-0xc]
6a0216c: mov x28, xzr
6a02170: cmp w8, #1
6a02174: b.le #0x6a020c0
6a02178: ldr x22, [sp, #0x18]
6a0217c: mov w1, wzr
6a02180: mov x0, x22
6a02184: bl #0x721f6bc
6a02188: tbz w0, #0, #0x6a02280
6a0218c: bl #0x6a04a0c
6a02190: mov x25, x0
6a02194: mov w22, #2
6a02198: adrp x28, #0xa70000
6a0219c: add x28, x28, #0x2dd
6a021a0: adrp x19, #0xa5c000
6a021a4: add x19, x19, #0xcda
6a021a8: stur wzr, [x29, #-0xc]
6a021ac: b #0x6a021e4
6a021b0: cmp w8, #0
6a021b4: mov x0, x26
6a021b8: csel x1, x19, x28, eq
6a021bc: cinc w27, w22, eq
6a021c0: bl #0x6833104
6a021c4: mov x0, x26
6a021c8: mov w1, w27
6a021cc: bl #0x6a04a4c
6a021d0: sub x0, x29, #0xc
6a021d4: bl #0x69ffcb4
6a021d8: ldur w8, [x29, #-0xc]
6a021dc: cmp w8, #3
6a021e0: b.ge #0x6a0227c
6a021e4: bl #0x6a049cc
6a021e8: ldur w8, [x29, #-0xc]
6a021ec: mov x26, x0
6a021f0: add x9, x20, x8, lsl #3
6a021f4: ldr x1, [x9, #0xc0]
6a021f8: cbz x1, #0x6a021b0
6a021fc: ldr x8, [x26]
6a02200: mov x0, x26
6a02204: ldr x8, [x8, #0x20]
6a02208: blr x8
6a0220c: ldur w8, [x29, #-0xc]
6a02210: add x24, x20, #0xc0
6a02214: ldr x9, [x23]
6a02218: mov x0, x23
6a0221c: ldr x1, [x24, x8, lsl #3]
6a02220: ldr x8, [x9, #0x20]
6a02224: blr x8
6a02228: ldur w8, [x29, #-0xc]
6a0222c: mov x1, x25
6a02230: ldr x3, [x20, #0x3c40]
6a02234: mov x2, x21
6a02238: ldr x0, [x24, x8, lsl #3]
6a0223c: bl #0x6a04454
6a02240: ldur w8, [x29, #-0xc]
6a02244: b #0x6a021b0
6a02248: ldr x8, [x19, #0x28]
6a0224c: ldur x9, [x29, #-8]
6a02250: cmp x8, x9
6a02254: b.ne #0x6a027ac
6a02258: mov x0, x21
6a0225c: ldp x20, x19, [sp, #0x80]
6a02260: ldp x22, x21, [sp, #0x70]
6a02264: ldp x24, x23, [sp, #0x60]
6a02268: ldp x26, x25, [sp, #0x50]
6a0226c: ldp x28, x27, [sp, #0x40]
6a02270: ldp x29, x30, [sp, #0x30]
6a02274: add sp, sp, #0x90
6a02278: b #0x68b047c
6a0227c: ldr x22, [sp, #0x18]
6a02280: mov x0, x22
6a02284: bl #0x721f71c
6a02288: tbz w0, #0, #0x6a022fc
6a0228c: ldr x8, [x20, #0xd8]
6a02290: cbz x8, #0x6a022fc
6a02294: bl #0x6a049cc
6a02298: mov x25, x0
6a0229c: bl #0x6a04a0c
6a022a0: ldr x8, [x25]
6a022a4: mov x26, x0
6a022a8: ldr x1, [x20, #0xd8]
6a022ac: mov x0, x25
6a022b0: ldr x8, [x8, #0x20]
6a022b4: blr x8
6a022b8: ldr x8, [x23]
6a022bc: mov x0, x23
6a022c0: ldr x1, [x20, #0xd8]
6a022c4: ldr x8, [x8, #0x20]
6a022c8: blr x8
6a022cc: ldr x0, [x20, #0xd8]
6a022d0: mov x1, x26
6a022d4: ldr x3, [x20, #0x3c40]
6a022d8: mov x2, x21
6a022dc: bl #0x6a04454
6a022e0: adrp x1, #0xaf5000
6a022e4: add x1, x1, #0x4c3
6a022e8: mov x0, x25
6a022ec: bl #0x6833104
6a022f0: mov x0, x25
6a022f4: mov w1, #1
6a022f8: bl #0x6a04a4c
6a022fc: mov x0, x22
6a02300: bl #0x721f728
6a02304: tbnz w0, #0, #0x6a0264c
6a02308: mov x0, x22
6a0230c: bl #0x721f734
6a02310: tbnz w0, #0, #0x6a026f8
6a02314: bl #0x6a04a0c
6a02318: ldr x8, [x20, #0x3c98]
6a0231c: mov x24, x0
6a02320: cbz x8, #0x6a02388
6a02324: mov x0, x8
6a02328: bl #0x6a35434
6a0232c: bl #0x6a049cc
6a02330: ldr x8, [x0]
6a02334: mov x25, x0
6a02338: ldr x1, [x20, #0x3c98]
6a0233c: ldr x8, [x8, #0x20]
6a02340: blr x8
6a02344: adrp x1, #0xbed000
6a02348: add x1, x1, #0x62e
6a0234c: mov x0, x25
6a02350: bl #0x6833104
6a02354: mov x0, x25
6a02358: mov w1, #1
6a0235c: bl #0x6a04a4c
6a02360: ldr x8, [x23]
6a02364: mov x0, x23
6a02368: ldr x1, [x20, #0x3c98]
6a0236c: ldr x8, [x8, #0x20]
6a02370: blr x8
6a02374: ldr x0, [x20, #0x3c98]
6a02378: mov x1, x24
6a0237c: ldr x3, [x20, #0x3c40]
6a02380: mov x2, x21
6a02384: bl #0x6a04454
6a02388: mov w0, #0x18
6a0238c: bl #0x8b35260   ; PLT _Znwm
6a02390: mov x23, x0
6a02394: bl #0x6a80f30
6a02398: mov x0, x23
6a0239c: str x23, [x20, #0x3c50]
6a023a0: bl #0x6a81004
6a023a4: mov w0, #0x198
6a023a8: bl #0x8b35260   ; PLT _Znwm
6a023ac: mov x25, x0
6a023b0: bl #0x6a9cd60
6a023b4: adrp x26, #0xb08000
6a023b8: add x26, x26, #0x1e3
6a023bc: mov x0, x25
6a023c0: mov x1, x26
6a023c4: mov w2, wzr
6a023c8: bl #0x6993ab8
6a023cc: ldr x8, [x25]
6a023d0: mov x0, x25
6a023d4: mov x1, x23
6a023d8: ldr x8, [x8, #0x20]
6a023dc: blr x8
6a023e0: adrp x1, #0xa95000
6a023e4: add x1, x1, #0xf86
6a023e8: mov x0, x25
6a023ec: bl #0x6833104
6a023f0: mov x0, x25
6a023f4: mov w1, #1
6a023f8: bl #0x6a04a4c
6a023fc: mov x0, x23
6a02400: ldr w1, [sp, #4]
6a02404: bl #0x6a8103c
6a02408: mov w0, #0x3f00
6a0240c: bl #0x8b35260   ; PLT _Znwm
6a02410: mov x22, x0
6a02414: bl #0x6a8dba4
6a02418: mov w0, #0x198
6a0241c: str x22, [x20, #0x3c58]
6a02420: bl #0x8b35260   ; PLT _Znwm
6a02424: mov x23, x0
6a02428: bl #0x6a9cd60
6a0242c: mov x0, x23
6a02430: mov x1, x26
6a02434: mov w2, wzr
6a02438: bl #0x6993ab8
6a0243c: ldr x8, [x23]
6a02440: mov x0, x23
6a02444: mov x1, x22
6a02448: ldr x8, [x8, #0x20]
6a0244c: blr x8
6a02450: adrp x1, #0xbda000
6a02454: add x1, x1, #0xda1
6a02458: mov x0, x23
6a0245c: bl #0x6833104
6a02460: ldr x0, [x20, #0x3c40]
6a02464: cbz x0, #0x6a02470
6a02468: mov x1, x22
6a0246c: bl #0x6a9ef48
6a02470: mov w26, wzr
6a02474: adrp x22, #0xb08000
6a02478: add x22, x22, #0x1e3
6a0247c: adrp x23, #0xb08000
6a02480: add x23, x23, #0x78e
6a02484: stur wzr, [x29, #-0xc]
6a02488: b #0x6a024a0
6a0248c: sub x0, x29, #0xc
6a02490: bl #0x6837104
6a02494: ldur w26, [x29, #-0xc]
6a02498: cmp w26, #2
6a0249c: b.ge #0x6a02520
6a024a0: mov w0, #0x37b8
6a024a4: bl #0x8b35260   ; PLT _Znwm
6a024a8: mov w1, w26
6a024ac: mov x25, x0
6a024b0: bl #0x6a8dfa4
6a024b4: ldur w8, [x29, #-0xc]
6a024b8: mov w0, #0x198
6a024bc: add x8, x20, x8, lsl #3
6a024c0: str x25, [x8, #0x3c60]
6a024c4: bl #0x8b35260   ; PLT _Znwm
6a024c8: mov x26, x0
6a024cc: bl #0x6a9cd60
6a024d0: mov x0, x26
6a024d4: mov x1, x22
6a024d8: mov w2, wzr
6a024dc: bl #0x6993ab8
6a024e0: ldr x8, [x26]
6a024e4: mov x0, x26
6a024e8: mov x1, x25
6a024ec: ldr x8, [x8, #0x20]
6a024f0: blr x8
6a024f4: mov x0, x26
6a024f8: mov x1, x23
6a024fc: bl #0x6833104
6a02500: mov x0, x26
6a02504: mov w1, #6
6a02508: bl #0x6a04a4c
6a0250c: ldr x0, [x20, #0x3c40]
6a02510: cbz x0, #0x6a0248c
6a02514: mov x1, x25
6a02518: bl #0x6a9ef48
6a0251c: b #0x6a0248c
6a02520: bl #0x6a04a54
6a02524: mov w0, wzr
6a02528: bl #0x68a1744
6a0252c: bl #0x68a18a8
6a02530: mov w8, #3
6a02534: cmp w0, #3
6a02538: mov w23, w0
6a0253c: csel w22, w0, w8, lt
6a02540: bl #0x66eca88
6a02544: mov w1, w22
6a02548: bl #0x66eccbc
6a0254c: cmp w23, #1
6a02550: b.lt #0x6a0257c
6a02554: sub w0, w22, #1
6a02558: bl #0x6a04a8c
6a0255c: cmp w22, #1
6a02560: b.le #0x6a0257c
6a02564: subs w0, w22, #2
6a02568: bl #0x6a04a8c
6a0256c: cmp w22, #2
6a02570: b.eq #0x6a0257c
6a02574: sub w0, w22, #3
6a02578: bl #0x6a04a8c
6a0257c: bl #0x6a04acc
6a02580: mov w0, #0x89b0
6a02584: bl #0x8b35260   ; PLT _Znwm
6a02588: mov x22, x0
6a0258c: bl #0x6a442b8
6a02590: ldr x8, [x22]
6a02594: str x22, [x20, #0x3c48]
6a02598: mov x0, x22
6a0259c: ldr x8, [x8, #0xa0]
6a025a0: blr x8
6a025a4: mov w0, #0x198
6a025a8: bl #0x8b35260   ; PLT _Znwm
6a025ac: mov x23, x0
6a025b0: bl #0x6a9cd60
6a025b4: adrp x1, #0xb08000
6a025b8: add x1, x1, #0x1e3
6a025bc: mov x0, x23
6a025c0: mov w2, wzr
6a025c4: bl #0x6993ab8
6a025c8: ldr x8, [x23]
6a025cc: mov x0, x23
6a025d0: mov x1, x22
6a025d4: ldr x8, [x8, #0x20]
6a025d8: blr x8
6a025dc: adrp x1, #0xa36000
6a025e0: add x1, x1, #0x94f
6a025e4: mov x0, x23
6a025e8: bl #0x6833104
6a025ec: mov x0, x23
6a025f0: mov w1, #2
6a025f4: bl #0x6a04a4c
6a025f8: ldr x3, [x20, #0x3c40]
6a025fc: mov x0, x22
6a02600: mov x1, x24
6a02604: mov x2, x21
6a02608: bl #0x6a04454
6a0260c: ldr x0, [sp, #8]
6a02610: str xzr, [x20, #0x3c40]
6a02614: bl #0x68b047c
6a02618: ldr x8, [sp, #0x10]
6a0261c: ldr x8, [x8, #0x28]
6a02620: ldur x9, [x29, #-8]
6a02624: cmp x8, x9
6a02628: b.ne #0x6a027ac
6a0262c: ldp x20, x19, [sp, #0x80]
6a02630: ldp x22, x21, [sp, #0x70]
6a02634: ldp x24, x23, [sp, #0x60]
6a02638: ldp x26, x25, [sp, #0x50]
6a0263c: ldp x28, x27, [sp, #0x40]
6a02640: ldp x29, x30, [sp, #0x30]
6a02644: add sp, sp, #0x90
6a02648: ret
6a0264c: bl #0x6a049cc
6a02650: mov x25, x0
6a02654: bl #0x6a04a0c
6a02658: mov x26, x0
6a0265c: mov x8, xzr
6a02660: stur wzr, [x29, #-0xc]
6a02664: b #0x6a0267c
6a02668: sub x0, x29, #0xc
6a0266c: bl #0x6837104
6a02670: ldur w8, [x29, #-0xc]
6a02674: cmp w8, #2
6a02678: b.ge #0x6a026d0
6a0267c: add x8, x20, x8, lsl #3
6a02680: ldr x1, [x8, #0xe0]
6a02684: cbz x1, #0x6a02668
6a02688: ldr x8, [x25]
6a0268c: mov x0, x25
6a02690: ldr x8, [x8, #0x20]
6a02694: blr x8
6a02698: ldur w8, [x29, #-0xc]
6a0269c: add x19, x20, #0xe0
6a026a0: ldr x9, [x23]
6a026a4: mov x0, x23
6a026a8: ldr x1, [x19, x8, lsl #3]
6a026ac: ldr x8, [x9, #0x20]
6a026b0: blr x8
6a026b4: ldur w8, [x29, #-0xc]
6a026b8: mov x1, x26
6a026bc: ldr x3, [x20, #0x3c40]
6a026c0: mov x2, x21
6a026c4: ldr x0, [x19, x8, lsl #3]
6a026c8: bl #0x6a04454
6a026cc: b #0x6a02668
6a026d0: adrp x1, #0xb66000
6a026d4: add x1, x1, #0xfbe
6a026d8: mov x0, x25
6a026dc: bl #0x6833104
6a026e0: mov x0, x25
6a026e4: mov w1, #3
6a026e8: bl #0x6a04a4c
6a026ec: mov x0, x22
6a026f0: bl #0x721f734
6a026f4: tbz w0, #0, #0x6a02314
6a026f8: bl #0x6a049cc
6a026fc: mov x24, x0
6a02700: bl #0x6a04a0c
6a02704: mov x25, x0
6a02708: mov x8, xzr
6a0270c: stur wzr, [x29, #-0xc]
6a02710: b #0x6a02728
6a02714: sub x0, x29, #0xc
6a02718: bl #0x6837104
6a0271c: ldur w8, [x29, #-0xc]
6a02720: cmp w8, #2
6a02724: b.ge #0x6a0277c
6a02728: add x8, x20, x8, lsl #3
6a0272c: ldr x1, [x8, #0xf0]
6a02730: cbz x1, #0x6a02714
6a02734: ldr x8, [x24]
6a02738: mov x0, x24
6a0273c: ldr x8, [x8, #0x20]
6a02740: blr x8
6a02744: ldur w8, [x29, #-0xc]
6a02748: add x19, x20, #0xf0
6a0274c: ldr x9, [x23]
6a02750: mov x0, x23
6a02754: ldr x1, [x19, x8, lsl #3]
6a02758: ldr x8, [x9, #0x20]
6a0275c: blr x8
6a02760: ldur w8, [x29, #-0xc]
6a02764: mov x1, x25
6a02768: ldr x3, [x20, #0x3c40]
6a0276c: mov x2, x21
6a02770: ldr x0, [x19, x8, lsl #3]
6a02774: bl #0x6a04454
6a02778: b #0x6a02714
6a0277c: adrp x1, #0xacf000
6a02780: add x1, x1, #0x555
6a02784: mov x0, x24
6a02788: bl #0x6833104
6a0278c: mov x0, x24
6a02790: mov w1, #3
6a02794: bl #0x6a04a4c
6a02798: bl #0x6a04a0c
6a0279c: ldr x8, [x20, #0x3c98]
6a027a0: mov x24, x0
6a027a4: cbnz x8, #0x6a02324
6a027a8: b #0x6a02388
6a027ac: bl #0x8b35290   ; PLT __stack_chk_fail
6a027b0: stp x29, x30, [sp, #-0x20]!
6a027b4: str x19, [sp, #0x10]
6a027b8: mov x29, sp
6a027bc: mov x19, x0
6a027c0: bl #0x6a04b04
6a027c4: mov x0, x19
6a027c8: bl #0x6a04b0c
6a027cc: mov x0, x19
6a027d0: bl #0x6a04c54
6a027d4: mov x0, x19
6a027d8: bl #0x6a0527c
6a027dc: bl #0x6a05358
6a027e0: mov x0, x19
6a027e4: bl #0x6a055c4
6a027e8: mov x0, x19
6a027ec: ldr x19, [sp, #0x10]
6a027f0: ldp x29, x30, [sp], #0x20
6a027f4: b #0x6a05618
6a027f8: sub sp, sp, #0xa0
6a027fc: stp x29, x30, [sp, #0x40]
6a02800: stp x28, x27, [sp, #0x50]
6a02804: stp x26, x25, [sp, #0x60]
6a02808: stp x24, x23, [sp, #0x70]
6a0280c: stp x22, x21, [sp, #0x80]
6a02810: stp x20, x19, [sp, #0x90]
6a02814: add x29, sp, #0x40
6a02818: mrs x8, tpidr_el0
6a0281c: mov w9, #0x3868
6a02820: str x8, [sp, #8]
6a02824: add x22, x0, x9
6a02828: mov x21, x0
6a0282c: ldr x8, [x8, #0x28]
6a02830: mov x0, x22
6a02834: mov w19, w2
6a02838: mov w20, w1
6a0283c: stur x8, [x29, #-8]
6a02840: bl #0x68b694c
6a02844: cbz x0, #0x6a0284c
6a02848: bl #0x7220820
6a0284c: mov x0, x22
6a02850: bl #0x68b69a8
6a02854: mov x8, xzr
6a02858: add x9, x21, #0x128
6a0285c: mov w26, #0x50
6a02860: mov w27, #0x39f8
6a02864: mov w25, #0x3958
6a02868: mov w22, #0xff
6a0286c: mov w23, #0x58
6a02870: str x9, [sp, #0x10]
6a02874: stur wzr, [x29, #-0xc]
6a02878: b #0x6a028c0
6a0287c: mov w26, #0x50
6a02880: mov w27, #0x39f8
6a02884: ldur w8, [x29, #-0xc]
6a02888: nop
6a0288c: umaddl x8, w8, w26, x21
6a02890: add x0, x8, x27
6a02894: bl #0x68b8e74
6a02898: ldur w8, [x29, #-0xc]
6a0289c: mov w25, #0x3958
6a028a0: umaddl x8, w8, w26, x21
6a028a4: add x0, x8, x25
6a028a8: bl #0x68b8578
6a028ac: sub x0, x29, #0xc
6a028b0: bl #0x6837104
6a028b4: ldur w8, [x29, #-0xc]
6a028b8: cmp w8, #2
6a028bc: b.ge #0x6a02af0
6a028c0: cmp w20, #1
6a028c4: ccmp x8, #0, #0, eq
6a028c8: cset w9, eq
6a028cc: cmp x8, #1
6a028d0: ccmp w20, #0, #0, eq
6a028d4: b.eq #0x6a028ac
6a028d8: tbnz w9, #0, #0x6a028ac
6a028dc: madd x8, x8, x26, x21
6a028e0: add x0, x8, x27
6a028e4: bl #0x68b2cf0
6a028e8: ldur w8, [x29, #-0xc]
6a028ec: mov x24, x0
6a028f0: umaddl x8, w8, w26, x21
6a028f4: add x0, x8, x25
6a028f8: bl #0x68cb86c
6a028fc: cbz x24, #0x6a02884
6a02900: mov x25, x0
6a02904: cbz x0, #0x6a02884
6a02908: mov x0, x25
6a0290c: bl #0x683754c
6a02910: bl #0x71ec5d0
6a02914: mov w1, w0
6a02918: mov x0, x24
6a0291c: bl #0x722c168
6a02920: mov w26, w0
6a02924: bl #0x6834e70
6a02928: ldur w1, [x29, #-0xc]
6a0292c: mov w2, w26
6a02930: str w26, [sp, #0x1c]
6a02934: bl #0x6837f64
6a02938: mov w8, wzr
6a0293c: stur wzr, [x29, #-0x10]
6a02940: b #0x6a02958
6a02944: sub x0, x29, #0x10
6a02948: bl #0x6837a60
6a0294c: ldur w8, [x29, #-0x10]
6a02950: cmp w8, #0x1a
6a02954: b.ge #0x6a0287c
6a02958: cmp w8, w19
6a0295c: ccmp w19, w22, #4, ne
6a02960: ccmp w8, #0xa, #0, eq
6a02964: b.gt #0x6a02944
6a02968: ldur w9, [x29, #-0xc]
6a0296c: nop
6a02970: umaddl x9, w9, w23, x21
6a02974: add x8, x9, w8, sxtw #3
6a02978: ldr x8, [x8, #0x10]
6a0297c: cbz x8, #0x6a02944
6a02980: mov x0, x25
6a02984: bl #0x683754c
6a02988: ldur w1, [x29, #-0x10]
6a0298c: mov w2, wzr
6a02990: mov w3, #2
6a02994: bl #0x71eba5c
6a02998: ldursw x1, [x29, #-0x10]
6a0299c: cmp w1, #0xa
6a029a0: b.gt #0x6a02944
6a029a4: ldur w8, [x29, #-0xc]
6a029a8: nop
6a029ac: umaddl x8, w8, w23, x21
6a029b0: add x8, x8, x1, lsl #3
6a029b4: ldr x8, [x8, #0x10]
6a029b8: cbz x8, #0x6a02944
6a029bc: mov w27, w0
6a029c0: mov x0, x24
6a029c4: bl #0x722c5d4
6a029c8: bl #0x722c920
6a029cc: ldp w9, w8, [x29, #-0x10]
6a029d0: mov x28, x0
6a029d4: sxtw x9, w9
6a029d8: umaddl x8, w8, w23, x21
6a029dc: add x8, x8, x9, lsl #3
6a029e0: ldr x0, [x8, #0x10]
6a029e4: bl #0x6a03e38
6a029e8: mov x1, x0
6a029ec: adrp x0, #0xc62000
6a029f0: add x0, x0, #0x2f0
6a029f4: bl #0x683a240
6a029f8: tbz w0, #0, #0x6a02a4c
6a029fc: mov x0, x28
6a02a00: bl #0x68418c8
6a02a04: ldp w9, w8, [x29, #-0x10]
6a02a08: stp x0, x1, [sp, #0x20]
6a02a0c: sxtw x9, w9
6a02a10: umaddl x8, w8, w23, x21
6a02a14: add x8, x8, x9, lsl #3
6a02a18: ldr x8, [x8, #0x10]
6a02a1c: mov x0, x8
6a02a20: bl #0x6a03e38
6a02a24: mov x1, x0
6a02a28: add x0, sp, #0x20
6a02a2c: bl #0x683a240
6a02a30: tbz w0, #0, #0x6a02a4c
6a02a34: ldp w9, w8, [x29, #-0x10]
6a02a38: sxtw x9, w9
6a02a3c: umaddl x8, w8, w23, x21
6a02a40: add x8, x8, x9, lsl #3
6a02a44: ldr x0, [x8, #0x10]
6a02a48: bl #0x6f45778
6a02a4c: ldp w2, w1, [x29, #-0x10]
6a02a50: add x26, x21, #0x10
6a02a54: cmp w27, #0
6a02a58: sxtw x2, w2
6a02a5c: cset w4, eq
6a02a60: mov x3, x28
6a02a64: mov w5, wzr
6a02a68: umaddl x8, w1, w23, x26
6a02a6c: ldr x0, [x8, x2, lsl #3]
6a02a70: bl #0x70c1c7c
6a02a74: ldr x0, [sp, #0x10]
6a02a78: bl #0x727c8b0
6a02a7c: ldp w9, w8, [x29, #-0x10]
6a02a80: ldr w10, [sp, #0x1c]
6a02a84: sxtw x9, w9
6a02a88: umaddl x8, w8, w23, x26
6a02a8c: cmp w10, w9
6a02a90: ldr x8, [x8, x9, lsl #3]
6a02a94: cset w9, eq
6a02a98: bic w1, w9, w0
6a02a9c: mov x0, x8
6a02aa0: bl #0x7013118
6a02aa4: ldur w1, [x29, #-0x10]
6a02aa8: mov x0, x24
6a02aac: bl #0x6a03e40
6a02ab0: tbz w0, #0, #0x6a02944
6a02ab4: ldp w9, w8, [x29, #-0x10]
6a02ab8: mov x0, x21
6a02abc: sxtw x9, w9
6a02ac0: umaddl x8, w8, w23, x21
6a02ac4: add x8, x8, x9, lsl #3
6a02ac8: ldr x27, [x8, #0x10]
6a02acc: bl #0x6a02d4c
6a02ad0: mov x1, x0
6a02ad4: mov x0, x27
6a02ad8: bl #0x70c1dec
6a02adc: ldur w1, [x29, #-0x10]
6a02ae0: mov x0, x24
6a02ae4: mov w2, wzr
6a02ae8: bl #0x6a03e50
6a02aec: b #0x6a02944
6a02af0: cmp w20, #2
6a02af4: b.lt #0x6a02b08
6a02af8: cmp w19, #0xa
6a02afc: b.le #0x6a02b08
6a02b00: bl #0x66cf4cc
6a02b04: bl #0x66d0764
6a02b08: ldr x8, [sp, #8]
6a02b0c: ldr x8, [x8, #0x28]
6a02b10: ldur x9, [x29, #-8]
6a02b14: cmp x8, x9
6a02b18: b.ne #0x6a02b3c
6a02b1c: ldp x20, x19, [sp, #0x90]
6a02b20: ldp x22, x21, [sp, #0x80]
6a02b24: ldp x24, x23, [sp, #0x70]
6a02b28: ldp x26, x25, [sp, #0x60]
6a02b2c: ldp x28, x27, [sp, #0x50]
6a02b30: ldp x29, x30, [sp, #0x40]
6a02b34: add sp, sp, #0xa0
6a02b38: ret
6a02b3c: bl #0x8b35290   ; PLT __stack_chk_fail
6a02b40: sub sp, sp, #0x60
6a02b44: stp x29, x30, [sp, #0x20]
6a02b48: stp x24, x23, [sp, #0x30]
6a02b4c: stp x22, x21, [sp, #0x40]
6a02b50: stp x20, x19, [sp, #0x50]
6a02b54: add x29, sp, #0x20
6a02b58: mov w9, #0x3818
6a02b5c: mrs x22, tpidr_el0
6a02b60: add x20, x0, x9
6a02b64: mov x19, x0
6a02b68: ldr x8, [x22, #0x28]
6a02b6c: mov x0, x20
6a02b70: stur x8, [x29, #-8]
6a02b74: bl #0x68b0408
6a02b78: cbz x0, #0x6a02cc8
6a02b7c: mov x21, x0
6a02b80: mov w23, #1
6a02b84: mov w24, #0x58
6a02b88: stur wzr, [x29, #-0xc]
6a02b8c: b #0x6a02ba4
6a02b90: sub x0, x29, #0xc
6a02b94: bl #0x6837104
6a02b98: ldur w8, [x29, #-0xc]
6a02b9c: cmp w8, #2
6a02ba0: b.ge #0x6a02be8
6a02ba4: mov w8, wzr
6a02ba8: str wzr, [sp, #0x10]
6a02bac: b #0x6a02bc4
6a02bb0: add x0, sp, #0x10
6a02bb4: bl #0x6837a60
6a02bb8: ldr w8, [sp, #0x10]
6a02bbc: cmp w8, #0xb
6a02bc0: b.ge #0x6a02b90
6a02bc4: ldur w9, [x29, #-0xc]
6a02bc8: nop
6a02bcc: umaddl x9, w9, w24, x19
6a02bd0: add x8, x9, w8, sxtw #3
6a02bd4: ldr x0, [x8, #0x10]
6a02bd8: cbz x0, #0x6a02bb0
6a02bdc: bl #0x6f456fc
6a02be0: and w23, w23, w0
6a02be4: b #0x6a02bb0
6a02be8: mov x0, x21
6a02bec: mov w1, wzr
6a02bf0: bl #0x721f6bc
6a02bf4: tbz w0, #0, #0x6a02c14
6a02bf8: adrp x1, #0xbc7000
6a02bfc: add x1, x1, #0xcba
6a02c00: mov x0, sp
6a02c04: bl #0x684b818
6a02c08: ldp x0, x1, [sp]
6a02c0c: bl #0x2f0eaf0
6a02c10: cbz w0, #0x6a02ce8
6a02c14: ldr x0, [x19, #0xd8]
6a02c18: cbz x0, #0x6a02c24
6a02c1c: bl #0x6f456fc
6a02c20: and w23, w23, w0
6a02c24: mov x8, xzr
6a02c28: stur wzr, [x29, #-0xc]
6a02c2c: b #0x6a02c44
6a02c30: sub x0, x29, #0xc
6a02c34: bl #0x6837104
6a02c38: ldur w8, [x29, #-0xc]
6a02c3c: cmp w8, #2
6a02c40: b.ge #0x6a02c5c
6a02c44: add x8, x19, x8, lsl #3
6a02c48: ldr x0, [x8, #0xe0]
6a02c4c: cbz x0, #0x6a02c30
6a02c50: bl #0x6f456fc
6a02c54: and w23, w23, w0
6a02c58: b #0x6a02c30
6a02c5c: mov x8, xzr
6a02c60: stur wzr, [x29, #-0xc]
6a02c64: b #0x6a02c7c
6a02c68: sub x0, x29, #0xc
6a02c6c: bl #0x6837104
6a02c70: ldur w8, [x29, #-0xc]
6a02c74: cmp w8, #2
6a02c78: b.ge #0x6a02c94
6a02c7c: add x8, x19, x8, lsl #3
6a02c80: ldr x0, [x8, #0xf0]
6a02c84: cbz x0, #0x6a02c68
6a02c88: bl #0x6f456fc
6a02c8c: and w23, w23, w0
6a02c90: b #0x6a02c68
6a02c94: mov x0, x20
6a02c98: bl #0x68b047c
6a02c9c: ldr x8, [x22, #0x28]
6a02ca0: ldur x9, [x29, #-8]
6a02ca4: cmp x8, x9
6a02ca8: b.ne #0x6a02ce4
6a02cac: and w0, w23, #1
6a02cb0: ldp x20, x19, [sp, #0x50]
6a02cb4: ldp x22, x21, [sp, #0x40]
6a02cb8: ldp x24, x23, [sp, #0x30]
6a02cbc: ldp x29, x30, [sp, #0x20]
6a02cc0: add sp, sp, #0x60
6a02cc4: ret
6a02cc8: mov x0, x20
6a02ccc: bl #0x68b047c
6a02cd0: mov w23, wzr
6a02cd4: ldr x8, [x22, #0x28]
6a02cd8: ldur x9, [x29, #-8]
6a02cdc: cmp x8, x9
6a02ce0: b.eq #0x6a02cac
6a02ce4: bl #0x8b35290   ; PLT __stack_chk_fail
6a02ce8: mov x8, xzr
6a02cec: stur wzr, [x29, #-0xc]
6a02cf0: b #0x6a02d08
6a02cf4: sub x0, x29, #0xc
6a02cf8: bl #0x69ffcb4
6a02cfc: ldur w8, [x29, #-0xc]
6a02d00: cmp w8, #3
6a02d04: b.ge #0x6a02c14
6a02d08: add x8, x19, x8, lsl #3
6a02d0c: ldr x0, [x8, #0xc0]
6a02d10: cbz x0, #0x6a02cf4
6a02d14: bl #0x6f456fc
6a02d18: and w23, w23, w0
6a02d1c: b #0x6a02cf4
6a02d20: stp x29, x30, [sp, #-0x10]!
6a02d24: mov x29, sp
6a02d28: bl #0x6a00cc4
6a02d2c: bl #0x6a0999c
6a02d30: tbz w0, #0, #0x6a02d40
6a02d34: bl #0x68d34a4
6a02d38: ldp x29, x30, [sp], #0x10
6a02d3c: b #0x68d3bec
6a02d40: mov w0, wzr
6a02d44: ldp x29, x30, [sp], #0x10
6a02d48: ret
6a02d4c: add x0, x0, #0x128
6a02d50: ret
6a02d54: str d8, [sp, #-0x70]!
6a02d58: stp x29, x30, [sp, #0x10]
6a02d5c: stp x28, x27, [sp, #0x20]
6a02d60: stp x26, x25, [sp, #0x30]
6a02d64: stp x24, x23, [sp, #0x40]
6a02d68: stp x22, x21, [sp, #0x50]
6a02d6c: stp x20, x19, [sp, #0x60]
6a02d70: add x29, sp, #0x10
6a02d74: sub sp, sp, #0x230
6a02d78: mrs x8, tpidr_el0
6a02d7c: mov w9, #0x3ae8
6a02d80: str x8, [sp, #0x28]
6a02d84: mov x19, x0
6a02d88: ldr x8, [x8, #0x28]
6a02d8c: add x0, x0, x9
6a02d90: stur x8, [x29, #-0x20]
6a02d94: str x0, [sp, #8]
6a02d98: bl #0x6a03e60
6a02d9c: mov w8, #8
6a02da0: mov x25, x0
6a02da4: adrp x1, #0xb53000
6a02da8: add x1, x1, #0xc17
6a02dac: sub x0, x29, #0xe0
6a02db0: sub x2, x29, #0xf8
6a02db4: stur w8, [x29, #-0xf8]
6a02db8: sub x20, x29, #0xe0
6a02dbc: bl #0x6a03ebc
6a02dc0: add x0, x20, #0x20
6a02dc4: adrp x1, #0xba0000
6a02dc8: add x1, x1, #0x54b
6a02dcc: add x2, sp, #0x130
6a02dd0: str wzr, [sp, #0x130]
6a02dd4: str x0, [sp, #0x20]
6a02dd8: bl #0x6a03ebc
6a02ddc: mov w8, #9
6a02de0: add x0, x20, #0x40
6a02de4: adrp x1, #0xbc7000
6a02de8: add x1, x1, #0xcd6
6a02dec: add x2, sp, #0x118
6a02df0: str w8, [sp, #0x118]
6a02df4: str x0, [sp, #0x18]
6a02df8: bl #0x6a03ee8
6a02dfc: mov w8, #1
6a02e00: add x0, x20, #0x60
6a02e04: adrp x1, #0xc13000
6a02e08: add x1, x1, #0xc3f
6a02e0c: add x2, sp, #0x100
6a02e10: str w8, [sp, #0x100]
6a02e14: str x0, [sp, #0x10]
6a02e18: bl #0x6a03ebc
6a02e1c: mov w8, #0xa
6a02e20: add x0, x20, #0x80
6a02e24: adrp x1, #0xa70000
6a02e28: add x1, x1, #0x2cd
6a02e2c: add x2, sp, #0xe8
6a02e30: str w8, [sp, #0xe8]
6a02e34: str x0, [sp]
6a02e38: bl #0x6a03ee8
6a02e3c: add x24, x20, #0xa0
6a02e40: mov w8, #2
6a02e44: adrp x1, #0xa36000
6a02e48: add x1, x1, #0x945
6a02e4c: add x2, sp, #0xd0
6a02e50: mov x0, x24
6a02e54: str w8, [sp, #0xd0]
6a02e58: bl #0x6a03ebc
6a02e5c: adrp x1, #0xaa9000
6a02e60: add x1, x1, #0x92a
6a02e64: sub x0, x29, #0xf8
6a02e68: bl #0x2f649fc
6a02e6c: adrp x20, #0xa77000
6a02e70: add x20, x20, #0x25e
6a02e74: add x0, sp, #0x130
6a02e78: mov x1, x20
6a02e7c: bl #0x2f649fc
6a02e80: add x0, sp, #0x118
6a02e84: mov x1, x20
6a02e88: bl #0x2f649fc
6a02e8c: add x0, sp, #0x100
6a02e90: mov x1, x20
6a02e94: bl #0x2f649fc
6a02e98: add x0, sp, #0xe8
6a02e9c: mov x1, x20
6a02ea0: bl #0x2f649fc
6a02ea4: add x0, sp, #0xd0
6a02ea8: mov x1, x20
6a02eac: bl #0x2f649fc
6a02eb0: add x0, sp, #0xc0
6a02eb4: bl #0x68352cc
6a02eb8: cbz x25, #0x6a030d4
6a02ebc: bl #0x6813f0c
6a02ec0: tbz w0, #0, #0x6a030d4
6a02ec4: mov x21, xzr
6a02ec8: add x25, x19, #0x128
6a02ecc: sub x22, x29, #0xe0
6a02ed0: mov w23, #0x42c80000
6a02ed4: adrp x26, #0xaf5000
6a02ed8: add x26, x26, #0x4a8
6a02edc: adrp x27, #0xb5c000
6a02ee0: add x27, x27, #0x11f
6a02ee4: adrp x28, #0xa70000
6a02ee8: add x28, x28, #0x2d8
6a02eec: adrp x19, #0xaf5000
6a02ef0: add x19, x19, #0x4b4
6a02ef4: b #0x6a02f04
6a02ef8: add x21, x21, #0x20
6a02efc: cmp x21, #0xc0
6a02f00: b.eq #0x6a030d4
6a02f04: mov x0, x25
6a02f08: add x20, x22, x21
6a02f0c: bl #0x71faa94
6a02f10: ldr w1, [x20, #0x18]
6a02f14: bl #0x72103fc
6a02f18: tbz w0, #0, #0x6a02ef8
6a02f1c: add x8, sp, #0xa8
6a02f20: sub x0, x29, #0xf8
6a02f24: mov x1, x20
6a02f28: bl #0x6a03f14
6a02f2c: add x0, sp, #0xe8
6a02f30: add x1, sp, #0xa8
6a02f34: bl #0x66c8274
6a02f38: add x0, sp, #0xa8
6a02f3c: bl #0x2ef7b54
6a02f40: mov x0, x25
6a02f44: bl #0x71faa94
6a02f48: mov x1, x0
6a02f4c: ldr w2, [x20, #0x18]
6a02f50: add x0, sp, #0xc0
6a02f54: bl #0x721027c
6a02f58: add x0, sp, #0xc0
6a02f5c: bl #0x6a03f50
6a02f60: fmov s8, w23
6a02f64: add x8, sp, #0x90
6a02f68: fmul s0, s0, s8
6a02f6c: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a02f70: add x0, sp, #0xa8
6a02f74: add x1, sp, #0x90
6a02f78: bl #0x6a03f58
6a02f7c: add x0, sp, #0x130
6a02f80: add x1, sp, #0xa8
6a02f84: bl #0x66c8274
6a02f88: add x0, sp, #0xa8
6a02f8c: bl #0x2ef7b54
6a02f90: add x0, sp, #0x90
6a02f94: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a02f98: add x0, sp, #0xc0
6a02f9c: bl #0x6a03f84
6a02fa0: fmul s0, s0, s8
6a02fa4: add x8, sp, #0x90
6a02fa8: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a02fac: add x0, sp, #0xa8
6a02fb0: add x1, sp, #0x90
6a02fb4: bl #0x6a03f58
6a02fb8: add x0, sp, #0x118
6a02fbc: add x1, sp, #0xa8
6a02fc0: bl #0x66c8274
6a02fc4: add x0, sp, #0xa8
6a02fc8: bl #0x2ef7b54
6a02fcc: add x0, sp, #0x90
6a02fd0: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a02fd4: add x0, sp, #0xc0
6a02fd8: bl #0x698166c
6a02fdc: fmul s0, s0, s8
6a02fe0: add x8, sp, #0x90
6a02fe4: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a02fe8: add x0, sp, #0xa8
6a02fec: add x1, sp, #0x90
6a02ff0: bl #0x6a03f58
6a02ff4: add x0, sp, #0x100
6a02ff8: add x1, sp, #0xa8
6a02ffc: bl #0x66c8274
6a03000: add x0, sp, #0xa8
6a03004: bl #0x2ef7b54
6a03008: add x0, sp, #0x90
6a0300c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03010: add x8, sp, #0x30
6a03014: add x1, sp, #0x130
6a03018: mov x0, x26
6a0301c: bl #0x2f90aa8
6a03020: add x8, sp, #0x48
6a03024: add x0, sp, #0x30
6a03028: mov x1, x27
6a0302c: bl #0x2f19418
6a03030: add x8, sp, #0x60
6a03034: add x0, sp, #0x48
6a03038: add x1, sp, #0x118
6a0303c: bl #0x6a03f14
6a03040: add x8, sp, #0x78
6a03044: add x0, sp, #0x60
6a03048: mov x1, x27
6a0304c: bl #0x2f19418
6a03050: add x8, sp, #0x90
6a03054: add x0, sp, #0x78
6a03058: add x1, sp, #0x100
6a0305c: bl #0x6a03f14
6a03060: add x8, sp, #0xa8
6a03064: add x0, sp, #0x90
6a03068: mov x1, x28
6a0306c: bl #0x2f19418
6a03070: add x0, sp, #0xd0
6a03074: add x1, sp, #0xa8
6a03078: bl #0x66c8274
6a0307c: add x0, sp, #0xa8
6a03080: bl #0x2ef7b54
6a03084: add x0, sp, #0x90
6a03088: bl #0x2ef7b54
6a0308c: add x0, sp, #0x78
6a03090: bl #0x2ef7b54
6a03094: add x0, sp, #0x60
6a03098: bl #0x2ef7b54
6a0309c: add x0, sp, #0x48
6a030a0: bl #0x2ef7b54
6a030a4: add x0, sp, #0x30
6a030a8: bl #0x2ef7b54
6a030ac: add x0, sp, #0xe8
6a030b0: bl #0x683a870
6a030b4: mov x20, x0
6a030b8: add x0, sp, #0xd0
6a030bc: bl #0x683a870
6a030c0: mov x2, x0
6a030c4: mov x0, x19
6a030c8: mov x1, x20
6a030cc: bl #0x66cb5d8
6a030d0: b #0x6a02ef8
6a030d4: ldr x0, [sp, #8]
6a030d8: bl #0x6a03f8c
6a030dc: add x0, sp, #0xd0
6a030e0: bl #0x2ef7b54
6a030e4: add x0, sp, #0xe8
6a030e8: bl #0x2ef7b54
6a030ec: add x0, sp, #0x100
6a030f0: bl #0x2ef7b54
6a030f4: add x0, sp, #0x118
6a030f8: bl #0x2ef7b54
6a030fc: add x0, sp, #0x130
6a03100: bl #0x2ef7b54
6a03104: sub x0, x29, #0xf8
6a03108: bl #0x2ef7b54
6a0310c: mov x0, x24
6a03110: bl #0x6a03fbc
6a03114: ldr x0, [sp]
6a03118: bl #0x6a03fbc
6a0311c: ldr x0, [sp, #0x10]
6a03120: bl #0x6a03fbc
6a03124: ldr x0, [sp, #0x18]
6a03128: bl #0x6a03fbc
6a0312c: ldr x0, [sp, #0x20]
6a03130: bl #0x6a03fbc
6a03134: sub x0, x29, #0xe0
6a03138: bl #0x6a03fbc
6a0313c: ldr x8, [sp, #0x28]
6a03140: ldr x8, [x8, #0x28]
6a03144: ldur x9, [x29, #-0x20]
6a03148: cmp x8, x9
6a0314c: b.ne #0x6a03174
6a03150: add sp, sp, #0x230
6a03154: ldp x20, x19, [sp, #0x60]
6a03158: ldp x22, x21, [sp, #0x50]
6a0315c: ldp x24, x23, [sp, #0x40]
6a03160: ldp x26, x25, [sp, #0x30]
6a03164: ldp x28, x27, [sp, #0x20]
6a03168: ldp x29, x30, [sp, #0x10]
6a0316c: ldr d8, [sp], #0x70
6a03170: ret
6a03174: bl #0x8b35290   ; PLT __stack_chk_fail
6a03178: str d8, [sp, #-0x70]!
6a0317c: stp x29, x30, [sp, #0x10]
6a03180: stp x28, x27, [sp, #0x20]
6a03184: stp x26, x25, [sp, #0x30]
6a03188: stp x24, x23, [sp, #0x40]
6a0318c: stp x22, x21, [sp, #0x50]
6a03190: stp x20, x19, [sp, #0x60]
6a03194: add x29, sp, #0x10
6a03198: sub sp, sp, #0x200
6a0319c: mrs x8, tpidr_el0
6a031a0: mov w9, #0x3ae8
6a031a4: str x8, [sp, #0x18]
6a031a8: mov x19, x0
6a031ac: ldr x8, [x8, #0x28]
6a031b0: add x0, x0, x9
6a031b4: stur x8, [x29, #-0x28]
6a031b8: str x0, [sp, #0x10]
6a031bc: bl #0x6a03e60
6a031c0: mov w8, #0x3818
6a031c4: mov x20, x0
6a031c8: add x0, x19, x8
6a031cc: str x0, [sp, #8]
6a031d0: bl #0x68b2a3c
6a031d4: str x0, [sp, #0x48]
6a031d8: cbz x20, #0x6a03594
6a031dc: ldr x8, [sp, #0x48]
6a031e0: cbz x8, #0x6a03594
6a031e4: mov w8, #0x3c28
6a031e8: sub x9, x29, #0x50
6a031ec: add x8, x19, x8
6a031f0: mov x23, xzr
6a031f4: add x10, x19, #0x128
6a031f8: add x26, x9, #0xc
6a031fc: add x9, x9, #0x18
6a03200: adrp x28, #0x978c000
6a03204: add x28, x28, #0xf80
6a03208: str x8, [sp, #0x40]
6a0320c: sub x8, x29, #0x80
6a03210: adrp x27, #0xb5c000
6a03214: add x27, x27, #0x11f
6a03218: orr x8, x8, #8
6a0321c: adrp x19, #0xb53000
6a03220: add x19, x19, #0xc21
6a03224: adrp x20, #0x9c5000
6a03228: add x20, x20, #0x68
6a0322c: adrp x22, #0xaa9000
6a03230: add x22, x22, #0x83f
6a03234: adrp x25, #0xbc7000
6a03238: add x25, x25, #0xbe2
6a0323c: stp x8, x9, [sp, #0x20]
6a03240: stp x26, x10, [sp, #0x30]
6a03244: b #0x6a03260
6a03248: ldr x28, [sp, #0x50]
6a0324c: add x23, x23, #1
6a03250: ldr x26, [sp, #0x30]
6a03254: cmp x23, #2
6a03258: add x28, x28, #0x18
6a0325c: b.eq #0x6a03594
6a03260: ldr x0, [sp, #0x40]
6a03264: mov w1, #2
6a03268: bl #0x729c2a8
6a0326c: mov w21, w0
6a03270: sub x0, x29, #0x50
6a03274: bl #0x68352cc
6a03278: mov x0, x26
6a0327c: bl #0x68352cc
6a03280: ldr x0, [sp, #0x28]
6a03284: bl #0x68352cc
6a03288: ldr x24, [sp, #0x38]
6a0328c: sub x8, x29, #0x80
6a03290: movi v0.2d, #0000000000000000
6a03294: and w21, w21, #1
6a03298: bfi w21, w23, #1, #7
6a0329c: mov x0, x24
6a032a0: stp q0, q0, [x8, #0x10]
6a032a4: str q0, [x8]
6a032a8: bl #0x71faa94
6a032ac: mov x1, x0
6a032b0: sub x0, x29, #0x50
6a032b4: mov w2, w21
6a032b8: bl #0x72105ec
6a032bc: mov x0, x24
6a032c0: bl #0x71faa94
6a032c4: mov x1, x0
6a032c8: sub x0, x29, #0x80
6a032cc: mov w2, w21
6a032d0: bl #0x72107f0
6a032d4: cbz x23, #0x6a032e8
6a032d8: ldr x0, [sp, #0x48]
6a032dc: mov x1, x26
6a032e0: bl #0x721f688
6a032e4: b #0x6a032f4
6a032e8: ldr x0, [sp, #0x48]
6a032ec: mov x1, x26
6a032f0: bl #0x721f66c
6a032f4: mov x24, xzr
6a032f8: ldr x26, [sp, #0x20]
6a032fc: str x28, [sp, #0x50]
6a03300: b #0x6a03318
6a03304: add x28, x28, #8
6a03308: add x24, x24, #0xc
6a0330c: add x26, x26, #0x10
6a03310: cmp x24, #0x24
6a03314: b.eq #0x6a03248
6a03318: bl #0x6813ef4
6a0331c: tbz w0, #0, #0x6a03304
6a03320: sub x8, x29, #0x50
6a03324: add x21, x8, x24
6a03328: mov x0, x21
6a0332c: bl #0x6a03f50
6a03330: mov w8, #0x42c80000
6a03334: fmov s8, w8
6a03338: add x8, sp, #0xd0
6a0333c: fmul s0, s0, s8
6a03340: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a03344: add x8, sp, #0xe8
6a03348: add x1, sp, #0xd0
6a0334c: adrp x0, #0xaf5000
6a03350: add x0, x0, #0x44d
6a03354: bl #0x6a04010
6a03358: add x8, sp, #0x100
6a0335c: add x0, sp, #0xe8
6a03360: mov x1, x27
6a03364: bl #0x6a03fc0
6a03368: mov x0, x21
6a0336c: bl #0x6a03f84
6a03370: fmul s0, s0, s8
6a03374: add x8, sp, #0xb8
6a03378: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a0337c: sub x8, x29, #0xf8
6a03380: add x0, sp, #0x100
6a03384: add x1, sp, #0xb8
6a03388: bl #0x6a03fe8
6a0338c: sub x8, x29, #0xe0
6a03390: sub x0, x29, #0xf8
6a03394: mov x1, x27
6a03398: bl #0x6a03fc0
6a0339c: mov x0, x21
6a033a0: bl #0x698166c
6a033a4: fmul s0, s0, s8
6a033a8: add x8, sp, #0xa0
6a033ac: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a033b0: sub x8, x29, #0xc8
6a033b4: sub x0, x29, #0xe0
6a033b8: add x1, sp, #0xa0
6a033bc: bl #0x6a03fe8
6a033c0: sub x8, x29, #0xb0
6a033c4: sub x0, x29, #0xc8
6a033c8: adrp x1, #0xa95000
6a033cc: add x1, x1, #0xf80
6a033d0: bl #0x6a03fc0
6a033d4: sub x0, x29, #0x98
6a033d8: sub x1, x29, #0xb0
6a033dc: bl #0x6a03f58
6a033e0: sub x0, x29, #0xb0
6a033e4: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a033e8: sub x0, x29, #0xc8
6a033ec: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a033f0: add x0, sp, #0xa0
6a033f4: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a033f8: sub x0, x29, #0xe0
6a033fc: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03400: sub x0, x29, #0xf8
6a03404: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03408: add x0, sp, #0xb8
6a0340c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03410: add x0, sp, #0x100
6a03414: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03418: add x0, sp, #0xe8
6a0341c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03420: add x0, sp, #0xd0
6a03424: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03428: sub x0, x29, #0x98
6a0342c: ldr x21, [x28]
6a03430: bl #0x683a870
6a03434: mov x2, x0
6a03438: mov x0, x19
6a0343c: mov x1, x21
6a03440: bl #0x66cb5d8
6a03444: ldur s0, [x26, #-8]
6a03448: add x8, sp, #0xa0
6a0344c: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a03450: add x8, sp, #0xb8
6a03454: add x1, sp, #0xa0
6a03458: mov x0, x20
6a0345c: bl #0x6a04010
6a03460: add x8, sp, #0xd0
6a03464: add x0, sp, #0xb8
6a03468: mov x1, x27
6a0346c: bl #0x6a03fc0
6a03470: ldr s0, [x26]
6a03474: add x8, sp, #0x88
6a03478: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a0347c: add x8, sp, #0xe8
6a03480: add x0, sp, #0xd0
6a03484: add x1, sp, #0x88
6a03488: bl #0x6a03fe8
6a0348c: add x8, sp, #0x100
6a03490: add x0, sp, #0xe8
6a03494: mov x1, x27
6a03498: bl #0x6a03fc0
6a0349c: ldur s0, [x26, #-4]
6a034a0: add x8, sp, #0x70
6a034a4: fneg s0, s0
6a034a8: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a034ac: sub x8, x29, #0xf8
6a034b0: add x0, sp, #0x100
6a034b4: add x1, sp, #0x70
6a034b8: bl #0x6a03fe8
6a034bc: sub x8, x29, #0xe0
6a034c0: sub x0, x29, #0xf8
6a034c4: mov x1, x27
6a034c8: bl #0x6a03fc0
6a034cc: ldr s0, [x26, #4]
6a034d0: add x8, sp, #0x58
6a034d4: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a034d8: sub x8, x29, #0xc8
6a034dc: sub x0, x29, #0xe0
6a034e0: add x1, sp, #0x58
6a034e4: bl #0x6a03fe8
6a034e8: sub x0, x29, #0xb0
6a034ec: sub x1, x29, #0xc8
6a034f0: bl #0x6a03f58
6a034f4: sub x0, x29, #0x98
6a034f8: sub x1, x29, #0xb0
6a034fc: bl #0x66c8274
6a03500: sub x0, x29, #0xb0
6a03504: bl #0x2ef7b54
6a03508: sub x0, x29, #0xc8
6a0350c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03510: add x0, sp, #0x58
6a03514: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03518: sub x0, x29, #0xe0
6a0351c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03520: sub x0, x29, #0xf8
6a03524: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03528: add x0, sp, #0x70
6a0352c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03530: add x0, sp, #0x100
6a03534: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03538: add x0, sp, #0xe8
6a0353c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03540: add x0, sp, #0x88
6a03544: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03548: add x0, sp, #0xd0
6a0354c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03550: add x0, sp, #0xb8
6a03554: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03558: add x0, sp, #0xa0
6a0355c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03560: sub x0, x29, #0x98
6a03564: bl #0x683a870
6a03568: mov x2, x0
6a0356c: mov x0, x19
6a03570: mov x1, x21
6a03574: bl #0x66cb5d8
6a03578: mov x0, x22
6a0357c: mov x1, x21
6a03580: mov x2, x25
6a03584: bl #0x66cb5d8
6a03588: sub x0, x29, #0x98
6a0358c: bl #0x2ef7b54
6a03590: b #0x6a03304
6a03594: ldr x0, [sp, #0x10]
6a03598: bl #0x6a03f8c
6a0359c: ldr x0, [sp, #8]
6a035a0: bl #0x68b6798
6a035a4: ldr x8, [sp, #0x18]
6a035a8: ldr x8, [x8, #0x28]
6a035ac: ldur x9, [x29, #-0x28]
6a035b0: cmp x8, x9
6a035b4: b.ne #0x6a035dc
6a035b8: add sp, sp, #0x200
6a035bc: ldp x20, x19, [sp, #0x60]
6a035c0: ldp x22, x21, [sp, #0x50]
6a035c4: ldp x24, x23, [sp, #0x40]
6a035c8: ldp x26, x25, [sp, #0x30]
6a035cc: ldp x28, x27, [sp, #0x20]
6a035d0: ldp x29, x30, [sp, #0x10]
6a035d4: ldr d8, [sp], #0x70
6a035d8: ret
6a035dc: bl #0x8b35290   ; PLT __stack_chk_fail
6a035e0: str d8, [sp, #-0x70]!
6a035e4: stp x29, x30, [sp, #0x10]
6a035e8: stp x28, x27, [sp, #0x20]
6a035ec: stp x26, x25, [sp, #0x30]
6a035f0: stp x24, x23, [sp, #0x40]
6a035f4: stp x22, x21, [sp, #0x50]
6a035f8: stp x20, x19, [sp, #0x60]
6a035fc: add x29, sp, #0x10
6a03600: sub sp, sp, #0x1a0
6a03604: mov w9, #0x3818
6a03608: mrs x25, tpidr_el0
6a0360c: add x19, x0, x9
6a03610: mov x20, x0
6a03614: ldr x8, [x25, #0x28]
6a03618: mov x0, x19
6a0361c: stur x8, [x29, #-0x20]
6a03620: bl #0x68b2a3c
6a03624: mov x21, x0
6a03628: bl #0x721f71c
6a0362c: tbz w0, #0, #0x6a039c4
6a03630: mov w8, #0x3ae8
6a03634: add x0, x20, x8
6a03638: str x0, [sp, #8]
6a0363c: bl #0x6a03e60
6a03640: cbz x0, #0x6a03a08
6a03644: mov w22, wzr
6a03648: adrp x23, #0xa77000
6a0364c: add x23, x23, #0x25e
6a03650: add x24, x20, #0x128
6a03654: adrp x26, #0xb5c000
6a03658: add x26, x26, #0x11f
6a0365c: adrp x28, #0xb53000
6a03660: add x28, x28, #0xc21
6a03664: adrp x27, #0xbc7000
6a03668: add x27, x27, #0xbe2
6a0366c: sub x0, x29, #0x40
6a03670: bl #0x68352cc
6a03674: sub x0, x29, #0x30
6a03678: bl #0x684b500
6a0367c: mov x0, x24
6a03680: bl #0x71faa94
6a03684: mov x1, x0
6a03688: sub x0, x29, #0x40
6a0368c: mov w2, w22
6a03690: bl #0x720ff38
6a03694: ldur s0, [x29, #-0x40]
6a03698: fcmp s0, #0.0
6a0369c: b.ne #0x6a036ac
6a036a0: ldur s0, [x29, #-0x3c]
6a036a4: fcmp s0, #0.0
6a036a8: b.eq #0x6a039fc
6a036ac: sub x0, x29, #0x50
6a036b0: bl #0x68352cc
6a036b4: sub x0, x29, #0x50
6a036b8: mov x1, x24
6a036bc: mov w2, w22
6a036c0: bl #0x7267f94
6a036c4: movi d0, #0000000000000000
6a036c8: movi d2, #0000000000000000
6a036cc: sub x0, x29, #0x68
6a036d0: fmov s1, #1.00000000
6a036d4: bl #0x684bf44
6a036d8: sub x0, x29, #0x50
6a036dc: bl #0x684bf54
6a036e0: sub x0, x29, #0x80
6a036e4: stur s0, [x29, #-0x80]
6a036e8: bl #0x684c048
6a036ec: sub x0, x29, #0x30
6a036f0: sub x1, x29, #0x68
6a036f4: bl #0x729bc7c
6a036f8: sub x0, x29, #0x68
6a036fc: mov x1, x23
6a03700: bl #0x2f649fc
6a03704: sub x0, x29, #0x68
6a03708: mov w1, w22
6a0370c: bl #0x7267dc0
6a03710: sub x0, x29, #0x68
6a03714: mov x1, x23
6a03718: bl #0x693a4d8
6a0371c: cbz w0, #0x6a03a4c
6a03720: sub x0, x29, #0x40
6a03724: bl #0x6a03f50
6a03728: mov w8, #0x42c80000
6a0372c: fmov s8, w8
6a03730: add x8, sp, #0x88
6a03734: fmul s0, s0, s8
6a03738: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a0373c: add x8, sp, #0xa0
6a03740: add x1, sp, #0x88
6a03744: adrp x0, #0xaf5000
6a03748: add x0, x0, #0x44d
6a0374c: bl #0x6a04010
6a03750: add x8, sp, #0xb8
6a03754: add x0, sp, #0xa0
6a03758: mov x1, x26
6a0375c: bl #0x6a03fc0
6a03760: sub x0, x29, #0x40
6a03764: bl #0x6a03f84
6a03768: fmul s0, s0, s8
6a0376c: add x8, sp, #0x70
6a03770: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a03774: add x8, sp, #0xd0
6a03778: add x0, sp, #0xb8
6a0377c: add x1, sp, #0x70
6a03780: bl #0x6a03fe8
6a03784: sub x8, x29, #0xc8
6a03788: add x0, sp, #0xd0
6a0378c: mov x1, x26
6a03790: bl #0x6a03fc0
6a03794: sub x0, x29, #0x40
6a03798: bl #0x698166c
6a0379c: fmul s0, s0, s8
6a037a0: add x8, sp, #0x58
6a037a4: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a037a8: sub x8, x29, #0xb0
6a037ac: sub x0, x29, #0xc8
6a037b0: add x1, sp, #0x58
6a037b4: bl #0x6a03fe8
6a037b8: sub x8, x29, #0x98
6a037bc: sub x0, x29, #0xb0
6a037c0: adrp x1, #0xa95000
6a037c4: add x1, x1, #0xf80
6a037c8: bl #0x6a03fc0
6a037cc: sub x0, x29, #0x80
6a037d0: sub x1, x29, #0x98
6a037d4: bl #0x6a03f58
6a037d8: sub x0, x29, #0x98
6a037dc: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a037e0: sub x0, x29, #0xb0
6a037e4: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a037e8: add x0, sp, #0x58
6a037ec: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a037f0: sub x0, x29, #0xc8
6a037f4: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a037f8: add x0, sp, #0xd0
6a037fc: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03800: add x0, sp, #0x70
6a03804: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03808: add x0, sp, #0xb8
6a0380c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03810: add x0, sp, #0xa0
6a03814: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03818: add x0, sp, #0x88
6a0381c: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03820: sub x0, x29, #0x68
6a03824: bl #0x683a870
6a03828: mov x20, x0
6a0382c: sub x0, x29, #0x80
6a03830: bl #0x683a870
6a03834: mov x2, x0
6a03838: mov x0, x28
6a0383c: mov x1, x20
6a03840: bl #0x66cb5d8
6a03844: ldur s0, [x29, #-0x30]
6a03848: add x8, sp, #0x58
6a0384c: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a03850: add x8, sp, #0x70
6a03854: add x1, sp, #0x58
6a03858: adrp x0, #0x9c5000
6a0385c: add x0, x0, #0x68
6a03860: bl #0x6a04010
6a03864: add x8, sp, #0x88
6a03868: add x0, sp, #0x70
6a0386c: mov x1, x26
6a03870: bl #0x6a03fc0
6a03874: ldur s0, [x29, #-0x28]
6a03878: add x8, sp, #0x40
6a0387c: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a03880: add x8, sp, #0xa0
6a03884: add x0, sp, #0x88
6a03888: add x1, sp, #0x40
6a0388c: bl #0x6a03fe8
6a03890: add x8, sp, #0xb8
6a03894: add x0, sp, #0xa0
6a03898: mov x1, x26
6a0389c: bl #0x6a03fc0
6a038a0: ldur s0, [x29, #-0x2c]
6a038a4: add x8, sp, #0x28
6a038a8: fneg s0, s0
6a038ac: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a038b0: add x8, sp, #0xd0
6a038b4: add x0, sp, #0xb8
6a038b8: add x1, sp, #0x28
6a038bc: bl #0x6a03fe8
6a038c0: sub x8, x29, #0xc8
6a038c4: add x0, sp, #0xd0
6a038c8: mov x1, x26
6a038cc: bl #0x6a03fc0
6a038d0: ldur s0, [x29, #-0x24]
6a038d4: add x8, sp, #0x10
6a038d8: bl #0x8b3a930   ; PLT _ZNSt6__ndk19to_stringEf
6a038dc: sub x8, x29, #0xb0
6a038e0: sub x0, x29, #0xc8
6a038e4: add x1, sp, #0x10
6a038e8: bl #0x6a03fe8
6a038ec: sub x0, x29, #0x98
6a038f0: sub x1, x29, #0xb0
6a038f4: bl #0x6a03f58
6a038f8: sub x0, x29, #0x80
6a038fc: sub x1, x29, #0x98
6a03900: bl #0x66c8274
6a03904: sub x0, x29, #0x98
6a03908: bl #0x2ef7b54
6a0390c: sub x0, x29, #0xb0
6a03910: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03914: add x0, sp, #0x10
6a03918: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a0391c: sub x0, x29, #0xc8
6a03920: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03924: add x0, sp, #0xd0
6a03928: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a0392c: add x0, sp, #0x28
6a03930: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03934: add x0, sp, #0xb8
6a03938: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a0393c: add x0, sp, #0xa0
6a03940: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03944: add x0, sp, #0x40
6a03948: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a0394c: add x0, sp, #0x88
6a03950: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03954: add x0, sp, #0x70
6a03958: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a0395c: add x0, sp, #0x58
6a03960: bl #0x8b38890   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev
6a03964: sub x0, x29, #0x68
6a03968: bl #0x683a870
6a0396c: mov x20, x0
6a03970: sub x0, x29, #0x80
6a03974: bl #0x683a870
6a03978: mov x2, x0
6a0397c: mov x0, x28
6a03980: mov x1, x20
6a03984: bl #0x66cb5d8
6a03988: sub x0, x29, #0x68
6a0398c: bl #0x683a870
6a03990: mov x1, x0
6a03994: adrp x0, #0xaa9000
6a03998: add x0, x0, #0x83f
6a0399c: mov x2, x27
6a039a0: bl #0x66cb5d8
6a039a4: sub x0, x29, #0x80
6a039a8: bl #0x2ef7b54
6a039ac: sub x0, x29, #0x68
6a039b0: bl #0x2ef7b54
6a039b4: add w22, w22, #1
6a039b8: cmp w22, #0xc
6a039bc: b.ne #0x6a0366c
6a039c0: b #0x6a03a08
6a039c4: ldr x8, [x25, #0x28]
6a039c8: ldur x9, [x29, #-0x20]
6a039cc: cmp x8, x9
6a039d0: b.ne #0x6a03a80
6a039d4: mov x0, x19
6a039d8: add sp, sp, #0x1a0
6a039dc: ldp x20, x19, [sp, #0x60]
6a039e0: ldp x22, x21, [sp, #0x50]
6a039e4: ldp x24, x23, [sp, #0x40]
6a039e8: ldp x26, x25, [sp, #0x30]
6a039ec: ldp x28, x27, [sp, #0x20]
6a039f0: ldp x29, x30, [sp, #0x10]
6a039f4: ldr d8, [sp], #0x70
6a039f8: b #0x68b6798
6a039fc: mov x0, x21
6a03a00: mov w1, wzr
6a03a04: bl #0x721f898
6a03a08: ldr x0, [sp, #8]
6a03a0c: bl #0x6a03f8c
6a03a10: mov x0, x19
6a03a14: bl #0x68b6798
6a03a18: ldr x8, [x25, #0x28]
6a03a1c: ldur x9, [x29, #-0x20]
6a03a20: cmp x8, x9
6a03a24: b.ne #0x6a03a80
6a03a28: add sp, sp, #0x1a0
6a03a2c: ldp x20, x19, [sp, #0x60]
6a03a30: ldp x22, x21, [sp, #0x50]
6a03a34: ldp x24, x23, [sp, #0x40]
6a03a38: ldp x26, x25, [sp, #0x30]
6a03a3c: ldp x28, x27, [sp, #0x20]
6a03a40: ldp x29, x30, [sp, #0x10]
6a03a44: ldr d8, [sp], #0x70
6a03a48: ret
6a03a4c: mov x0, x21
6a03a50: mov w1, wzr
6a03a54: bl #0x721f898
6a03a58: ldr x0, [sp, #8]
6a03a5c: bl #0x6a03f8c
6a03a60: mov x0, x19
6a03a64: bl #0x68b6798
6a03a68: sub x0, x29, #0x68
6a03a6c: bl #0x2ef7b54
6a03a70: ldr x8, [x25, #0x28]
6a03a74: ldur x9, [x29, #-0x20]
6a03a78: cmp x8, x9
6a03a7c: b.eq #0x6a03a28
6a03a80: bl #0x8b35290   ; PLT __stack_chk_fail
6a03a84: sub sp, sp, #0x100
6a03a88: stp x29, x30, [sp, #0xb0]
6a03a8c: str x25, [sp, #0xc0]
6a03a90: stp x24, x23, [sp, #0xd0]
6a03a94: stp x22, x21, [sp, #0xe0]
6a03a98: stp x20, x19, [sp, #0xf0]
6a03a9c: add x29, sp, #0xb0
6a03aa0: mov w9, #0x3818
6a03aa4: mrs x24, tpidr_el0
6a03aa8: add x19, x0, x9
6a03aac: mov x20, x0
6a03ab0: ldr x8, [x24, #0x28]
6a03ab4: mov x0, x19
6a03ab8: mov w22, w1
6a03abc: stur x8, [x29, #-8]
6a03ac0: bl #0x68b0408
6a03ac4: cbz x0, #0x6a03c50
6a03ac8: mov x21, x0
6a03acc: adrp x1, #0xa77000
6a03ad0: add x1, x1, #0x25e
6a03ad4: add x0, sp, #0x10
6a03ad8: bl #0x2f649fc
6a03adc: tst w22, #0xff
6a03ae0: b.eq #0x6a03af0
6a03ae4: mov x0, x21
6a03ae8: bl #0x6836fc8
6a03aec: b #0x6a03c28
6a03af0: mov x8, xzr
6a03af4: mov w22, #0x50
6a03af8: mov w23, #0x3958
6a03afc: add x25, sp, #0x28
6a03b00: str wzr, [sp, #0xc]
6a03b04: nop
6a03b08: madd x8, x8, x22, x20
6a03b0c: add x0, x8, x23
6a03b10: bl #0x68b2c64
6a03b14: ldr w8, [sp, #0xc]
6a03b18: str x0, [x25, x8, lsl #3]
6a03b1c: add x0, sp, #0xc
6a03b20: bl #0x6837104
6a03b24: ldr w8, [sp, #0xc]
6a03b28: cmp w8, #2
6a03b2c: b.lt #0x6a03b04
6a03b30: ldr x22, [sp, #0x28]
6a03b34: mov x0, x22
6a03b38: bl #0x6997ac0
6a03b3c: mov w1, wzr
6a03b40: bl #0x6a057e0
6a03b44: ldr x23, [sp, #0x30]
6a03b48: mov x0, x23
6a03b4c: bl #0x6997ac0
6a03b50: mov w1, wzr
6a03b54: bl #0x6a057e0
6a03b58: mov x0, x22
6a03b5c: bl #0x6997ac0
6a03b60: bl #0x7253e08
6a03b64: mov x0, x23
6a03b68: bl #0x6997ac0
6a03b6c: bl #0x7253e08
6a03b70: mov x8, xzr
6a03b74: mov w22, #0x50
6a03b78: mov w23, #0x3958
6a03b7c: str wzr, [sp, #0xc]
6a03b80: nop
6a03b84: madd x8, x8, x22, x20
6a03b88: add x0, x8, x23
6a03b8c: bl #0x68b85a8
6a03b90: add x0, sp, #0xc
6a03b94: bl #0x6837104
6a03b98: ldr w8, [sp, #0xc]
6a03b9c: cmp w8, #2
6a03ba0: b.lt #0x6a03b80
6a03ba4: mov x0, x21
6a03ba8: bl #0x6836fc8
6a03bac: cmp w0, #6
6a03bb0: b.ne #0x6a03c28
6a03bb4: mov x0, x21
6a03bb8: bl #0x698f680
6a03bbc: mov w22, #0x50
6a03bc0: mov w9, #0x3958
6a03bc4: umaddl x8, w0, w22, x20
6a03bc8: add x0, x8, x9
6a03bcc: bl #0x68cb86c
6a03bd0: cbz x0, #0x6a03c10
6a03bd4: bl #0x68379f4
6a03bd8: mov w1, wzr
6a03bdc: mov w2, wzr
6a03be0: bl #0x6a057ec
6a03be4: and w3, w0, #0xff
6a03be8: adrp x2, #0xba0000
6a03bec: add x2, x2, #0x555
6a03bf0: add x0, sp, #0x28
6a03bf4: mov w1, #0x80
6a03bf8: bl #0x2f1774c
6a03bfc: add x0, sp, #0x28
6a03c00: bl #0x6a0abd4
6a03c04: add x0, sp, #0x10
6a03c08: add x1, sp, #0x28
6a03c0c: bl #0x3557974
6a03c10: mov x0, x21
6a03c14: bl #0x698f680
6a03c18: umaddl x8, w0, w22, x20
6a03c1c: mov w9, #0x3958
6a03c20: add x0, x8, x9
6a03c24: bl #0x68b8578
6a03c28: add x0, sp, #0x10
6a03c2c: bl #0x6842dd8
6a03c30: cbz x0, #0x6a03c48
6a03c34: add x0, sp, #0x10
6a03c38: bl #0x683a870
6a03c3c: mov w1, #1
6a03c40: bl #0x6acf770
6a03c44: str x0, [x20, #0x3bf0]
6a03c48: add x0, sp, #0x10
6a03c4c: bl #0x2ef7b54
6a03c50: mov x0, x19
6a03c54: bl #0x68b047c
6a03c58: ldr x8, [x24, #0x28]
6a03c5c: ldur x9, [x29, #-8]
6a03c60: cmp x8, x9
6a03c64: b.ne #0x6a03c84
6a03c68: ldp x20, x19, [sp, #0xf0]
6a03c6c: ldp x22, x21, [sp, #0xe0]
6a03c70: ldp x24, x23, [sp, #0xd0]
6a03c74: ldp x29, x30, [sp, #0xb0]
6a03c78: ldr x25, [sp, #0xc0]
6a03c7c: add sp, sp, #0x100
6a03c80: ret
6a03c84: bl #0x8b35290   ; PLT __stack_chk_fail
6a03c88: sub sp, sp, #0x70
6a03c8c: stp x29, x30, [sp, #0x20]
6a03c90: str x25, [sp, #0x30]
6a03c94: stp x24, x23, [sp, #0x40]
6a03c98: stp x22, x21, [sp, #0x50]
6a03c9c: stp x20, x19, [sp, #0x60]
6a03ca0: add x29, sp, #0x20
6a03ca4: mrs x23, tpidr_el0
6a03ca8: mov x19, x0
6a03cac: ldr x8, [x23, #0x28]
6a03cb0: stur x8, [x29, #-8]
6a03cb4: ldr x0, [x0, #0x3bf0]
6a03cb8: cbz x0, #0x6a03d74
6a03cbc: mov w1, wzr
6a03cc0: bl #0x6acf7b4
6a03cc4: mov w8, w0
6a03cc8: mov w0, wzr
6a03ccc: tbz w8, #0, #0x6a03d78
6a03cd0: ldr x0, [x19, #0x3bf0]
6a03cd4: bl #0x6a05808
6a03cd8: mov x20, x0
6a03cdc: add x0, x19, #0x128
6a03ce0: bl #0x71faa64
6a03ce4: mov x21, x0
6a03ce8: mov x8, xzr
6a03cec: mov w22, #0x50
6a03cf0: mov w24, #0x3958
6a03cf4: add x25, sp, #8
6a03cf8: str wzr, [sp, #4]
6a03cfc: nop
6a03d00: madd x8, x8, x22, x19
6a03d04: add x0, x8, x24
6a03d08: bl #0x68b2c64
6a03d0c: ldr w8, [sp, #4]
6a03d10: str x0, [x25, x8, lsl #3]
6a03d14: add x0, sp, #4
6a03d18: bl #0x6837104
6a03d1c: ldr w8, [sp, #4]
6a03d20: cmp w8, #2
6a03d24: b.lt #0x6a03cfc
6a03d28: mov w22, wzr
6a03d2c: b #0x6a03d3c
6a03d30: add w22, w22, #1
6a03d34: cmp w22, #0x16
6a03d38: b.eq #0x6a03da4
6a03d3c: mov x0, x20
6a03d40: mov w1, w22
6a03d44: bl #0x6a05810
6a03d48: bl #0x6a0583c
6a03d4c: tbz w0, #0, #0x6a03d30
6a03d50: mov x0, x20
6a03d54: mov w1, w22
6a03d58: bl #0x6a05810
6a03d5c: mov x3, x0
6a03d60: add x1, sp, #8
6a03d64: mov x0, x21
6a03d68: mov w2, w22
6a03d6c: bl #0x6a05844
6a03d70: b #0x6a03d30
6a03d74: mov w0, #1
6a03d78: ldr x8, [x23, #0x28]
6a03d7c: ldur x9, [x29, #-8]
6a03d80: cmp x8, x9
6a03d84: b.ne #0x6a03e18
6a03d88: ldp x20, x19, [sp, #0x60]
6a03d8c: ldp x22, x21, [sp, #0x50]
6a03d90: ldp x24, x23, [sp, #0x40]
6a03d94: ldp x29, x30, [sp, #0x20]
6a03d98: ldr x25, [sp, #0x30]
6a03d9c: add sp, sp, #0x70
6a03da0: ret
6a03da4: ldr x0, [sp, #8]
6a03da8: bl #0x6997ac0
6a03dac: mov w1, #1
6a03db0: bl #0x6a057e0
6a03db4: ldr x0, [sp, #0x10]
6a03db8: bl #0x6997ac0
6a03dbc: mov w1, #1
6a03dc0: bl #0x6a057e0
6a03dc4: mov x8, xzr
6a03dc8: mov w20, #0x50
6a03dcc: mov w21, #0x3958
6a03dd0: str wzr, [sp, #4]
6a03dd4: nop
6a03dd8: madd x8, x8, x20, x19
6a03ddc: add x0, x8, x21
6a03de0: bl #0x68b85a8
6a03de4: add x0, sp, #4
6a03de8: bl #0x6837104
6a03dec: ldr w8, [sp, #4]
6a03df0: cmp w8, #2
6a03df4: b.lt #0x6a03dd4
6a03df8: ldr x0, [x19, #0x3bf0]
6a03dfc: bl #0x6acf7a8
6a03e00: mov w0, #1
6a03e04: str xzr, [x19, #0x3bf0]
6a03e08: ldr x8, [x23, #0x28]
6a03e0c: ldur x9, [x29, #-8]
6a03e10: cmp x8, x9
6a03e14: b.eq #0x6a03d88
6a03e18: bl #0x8b35290   ; PLT __stack_chk_fail
6a03e1c: adrp x8, #0xa417000
6a03e20: ldrb w9, [x8, #0x112]
6a03e24: tbz w9, #0, #0x6a03e2c
6a03e28: ret
6a03e2c: mov w9, #1
6a03e30: strb w9, [x8, #0x112]
6a03e34: b #0x6c78f64
6a03e38: add x0, x0, #0x20
6a03e3c: ret
6a03e40: mov w8, #0x4070
6a03e44: add x9, x0, w1, sxtw
6a03e48: ldrb w0, [x9, x8]
6a03e4c: ret
6a03e50: mov w8, #0x4070
6a03e54: add x9, x0, w1, sxtw
6a03e58: strb w2, [x9, x8]
6a03e5c: ret
6a03e60: stp x29, x30, [sp, #-0x20]!
6a03e64: str x19, [sp, #0x10]
6a03e68: mov x29, sp
6a03e6c: mov x19, x0
6a03e70: bl #0x6a060d4
6a03e74: tbz w0, #0, #0x6a03e90
6a03e78: mov x1, x19
6a03e7c: ldr x0, [x1, #0x40]!
6a03e80: cbz x0, #0x6a03ea4
6a03e84: ldr x19, [sp, #0x10]
6a03e88: ldp x29, x30, [sp], #0x20
6a03e8c: ret
6a03e90: mov x0, x19
6a03e94: bl #0x69ffcc8
6a03e98: mov x1, x19
6a03e9c: ldr x0, [x1, #0x40]!
6a03ea0: cbnz x0, #0x6a03e84
6a03ea4: add x0, x19, #0x10
6a03ea8: bl #0x68c79e8
6a03eac: ldr x0, [x19, #0x40]
6a03eb0: ldr x19, [sp, #0x10]
6a03eb4: ldp x29, x30, [sp], #0x20
6a03eb8: ret
6a03ebc: stp x29, x30, [sp, #-0x20]!
6a03ec0: stp x20, x19, [sp, #0x10]
6a03ec4: mov x29, sp
6a03ec8: mov x19, x2
6a03ecc: mov x20, x0
6a03ed0: bl #0x2f649fc
6a03ed4: ldr w8, [x19]
6a03ed8: str w8, [x20, #0x18]
6a03edc: ldp x20, x19, [sp, #0x10]
6a03ee0: ldp x29, x30, [sp], #0x20
6a03ee4: ret
6a03ee8: stp x29, x30, [sp, #-0x20]!
6a03eec: stp x20, x19, [sp, #0x10]
6a03ef0: mov x29, sp
6a03ef4: mov x19, x2
6a03ef8: mov x20, x0
6a03efc: bl #0x2f649fc
6a03f00: ldr w8, [x19]
6a03f04: str w8, [x20, #0x18]
6a03f08: ldp x20, x19, [sp, #0x10]
6a03f0c: ldp x29, x30, [sp], #0x20
6a03f10: ret
6a03f14: stp x29, x30, [sp, #-0x20]!
6a03f18: stp x20, x19, [sp, #0x10]
6a03f1c: mov x29, sp
6a03f20: mov x19, x1
6a03f24: mov x1, x0
6a03f28: mov x0, x8
6a03f2c: mov x20, x8
6a03f30: bl #0x33f85bc
6a03f34: mov x0, x19
6a03f38: bl #0x683a870
6a03f3c: mov x1, x0
6a03f40: mov x0, x20
6a03f44: ldp x20, x19, [sp, #0x10]
6a03f48: ldp x29, x30, [sp], #0x20
6a03f4c: b #0x684b7d4
6a03f50: ldr s0, [x0]
6a03f54: ret
6a03f58: stp x29, x30, [sp, #-0x20]!
6a03f5c: str x19, [sp, #0x10]
6a03f60: mov x29, sp
6a03f64: mov x19, x0
6a03f68: mov x0, x1
6a03f6c: bl #0x68c7944
6a03f70: mov x1, x0
6a03f74: mov x0, x19
6a03f78: ldr x19, [sp, #0x10]
6a03f7c: ldp x29, x30, [sp], #0x20
6a03f80: b #0x6a06288
6a03f84: ldr s0, [x0, #8]
6a03f88: ret
6a03f8c: stp x29, x30, [sp, #-0x20]!
6a03f90: str x19, [sp, #0x10]
6a03f94: mov x29, sp
6a03f98: ldr x8, [x0, #0x40]
6a03f9c: cbz x8, #0x6a03fb0
6a03fa0: mov x19, x0
6a03fa4: add x0, x0, #0x10
6a03fa8: bl #0x68b7824
6a03fac: str xzr, [x19, #0x40]
6a03fb0: ldr x19, [sp, #0x10]
6a03fb4: ldp x29, x30, [sp], #0x20
6a03fb8: ret
6a03fbc: b #0x2ef7b54
6a03fc0: stp x29, x30, [sp, #-0x20]!
6a03fc4: str x19, [sp, #0x10]
6a03fc8: mov x29, sp
6a03fcc: mov x19, x8
6a03fd0: bl #0x8b387b0   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
6a03fd4: mov x1, x0
6a03fd8: mov x0, x19
6a03fdc: ldr x19, [sp, #0x10]
6a03fe0: ldp x29, x30, [sp], #0x20
6a03fe4: b #0x6a06304
6a03fe8: stp x29, x30, [sp, #-0x20]!
6a03fec: str x19, [sp, #0x10]
6a03ff0: mov x29, sp
6a03ff4: mov x19, x8
6a03ff8: bl #0x6a06388
6a03ffc: mov x1, x0
6a04000: mov x0, x19
6a04004: ldr x19, [sp, #0x10]
6a04008: ldp x29, x30, [sp], #0x20
6a0400c: b #0x6a06304
6a04010: stp x29, x30, [sp, #-0x20]!
6a04014: str x19, [sp, #0x10]
6a04018: mov x29, sp
6a0401c: mov x2, x0
6a04020: mov x0, x1
6a04024: mov x1, xzr
6a04028: mov x19, x8
6a0402c: bl #0x8b38790   ; PLT _ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6insertEmPKc
6a04030: mov x1, x0
6a04034: mov x0, x19
6a04038: ldr x19, [sp, #0x10]
6a0403c: ldp x29, x30, [sp], #0x20
6a04040: b #0x6a06304
6a04044: stp x29, x30, [sp, #-0x30]!
6a04048: stp x22, x21, [sp, #0x10]
6a0404c: stp x20, x19, [sp, #0x20]
6a04050: mov x29, sp
6a04054: mov x20, x0
6a04058: mov w0, #0x38b0
6a0405c: bl #0x8b35260   ; PLT _Znwm
6a04060: mov x19, x0
6a04064: bl #0x6a9be44
6a04068: mov w0, #0x4be8
6a0406c: str x19, [x20, #0x3c78]
6a04070: bl #0x8b35260   ; PLT _Znwm
6a04074: mov x21, x0
6a04078: bl #0x6a41c08
6a0407c: mov x0, x21
6a04080: bl #0x6a421d8
6a04084: ldr x8, [x19]
6a04088: mov x0, x19
6a0408c: ldr x8, [x8, #0x20]
6a04090: blr x8
6a04094: mov x0, x19
6a04098: mov x1, x21
6a0409c: bl #0x6993a8c
6a040a0: adrp x1, #0xb11000
6a040a4: add x1, x1, #0xf93
6a040a8: mov x0, x19
6a040ac: mov w2, wzr
6a040b0: bl #0x6993ab8
6a040b4: adrp x1, #0xbed000
6a040b8: add x1, x1, #0x61e
6a040bc: mov x0, x19
6a040c0: bl #0x6833104
6a040c4: mov x1, x21
6a040c8: bl #0x6a04124
6a040cc: mov w0, #0x120
6a040d0: bl #0x8b35260   ; PLT _Znwm
6a040d4: mov x22, x0
6a040d8: bl #0x6a9e224
6a040dc: mov x0, x22
6a040e0: mov x1, x21
6a040e4: str x22, [x20, #0x3c80]
6a040e8: bl #0x6993ad0
6a040ec: adrp x1, #0xbc7000
6a040f0: add x1, x1, #0x81f
6a040f4: mov x0, x22
6a040f8: mov w2, wzr
6a040fc: bl #0x6993ab8
6a04100: adrp x1, #0xc13000
6a04104: add x1, x1, #0xb6a
6a04108: mov x0, x22
6a0410c: bl #0x6833104
6a04110: mov x0, x19
6a04114: ldp x20, x19, [sp, #0x20]
6a04118: ldp x22, x21, [sp, #0x10]
6a0411c: ldp x29, x30, [sp], #0x30
6a04120: ret
6a04124: stp x29, x30, [sp, #-0x20]!
6a04128: stp x20, x19, [sp, #0x10]
6a0412c: mov x29, sp
6a04130: mov w0, #0x180
6a04134: mov x19, x1
6a04138: bl #0x8b35260   ; PLT _Znwm
6a0413c: mov x20, x0
6a04140: bl #0x6aa2e68
6a04144: adrp x1, #0xa11000
6a04148: add x1, x1, #0x2fd
6a0414c: mov x0, x20
6a04150: mov w2, wzr
6a04154: bl #0x6993ab8
6a04158: mov x0, x20
6a0415c: mov x1, x19
6a04160: ldp x20, x19, [sp, #0x10]
6a04164: ldp x29, x30, [sp], #0x20
6a04168: b #0x6a0416c
6a0416c: stp x29, x30, [sp, #-0x20]!
6a04170: stp x20, x19, [sp, #0x10]
6a04174: mov x29, sp
6a04178: mov x20, x0
6a0417c: mov x0, x1
6a04180: mov x19, x1
6a04184: bl #0x6993afc
6a04188: str x19, [x20, #0x128]
6a0418c: ldp x20, x19, [sp, #0x10]
6a04190: ldp x29, x30, [sp], #0x20
6a04194: ret
6a04198: sub sp, sp, #0x40
6a0419c: stp x29, x30, [sp, #0x10]
6a041a0: stp x22, x21, [sp, #0x20]
6a041a4: stp x20, x19, [sp, #0x30]
6a041a8: add x29, sp, #0x10
6a041ac: mrs x22, tpidr_el0
6a041b0: mov x19, x0
6a041b4: ldr x8, [x22, #0x28]
6a041b8: mov w0, #0x128
6a041bc: mov w20, w2
6a041c0: str x8, [sp, #8]
6a041c4: bl #0x8b35260   ; PLT _Znwm
6a041c8: mov x21, x0
6a041cc: bl #0x6a9aff0
6a041d0: adrp x1, #0xa6f000
6a041d4: add x1, x1, #0xd34
6a041d8: mov x0, x21
6a041dc: mov w2, wzr
6a041e0: bl #0x6993ab8
6a041e4: mov w0, #0x3840
6a041e8: bl #0x8b35260   ; PLT _Znwm
6a041ec: mov x21, x0
6a041f0: bl #0x6a9c458
6a041f4: adrp x1, #0xa95000
6a041f8: add x1, x1, #0xa60
6a041fc: mov x0, x21
6a04200: mov w2, wzr
6a04204: str x21, [x19, #0x3c90]
6a04208: bl #0x6993ab8
6a0420c: tbnz w20, #0, #0x6a04360
6a04210: add x1, x19, #0x128
6a04214: mov x0, sp
6a04218: bl #0x699a244
6a0421c: bl #0x6a04388
6a04220: str x0, [x19, #0x3c40]
6a04224: bl #0x6a043d0
6a04228: mov x0, sp
6a0422c: bl #0x699a254
6a04230: mov w0, #0x3748
6a04234: bl #0x8b35260   ; PLT _Znwm
6a04238: mov x20, x0
6a0423c: bl #0x6a352c4
6a04240: mov w0, #0x20
6a04244: str x20, [x19, #0x3c98]
6a04248: bl #0x8b35260   ; PLT _Znwm
6a0424c: mov x20, x0
6a04250: bl #0x6a8244c
6a04254: mov w0, #0x140
6a04258: str x20, [x19, #0x3c70]
6a0425c: bl #0x8b35260   ; PLT _Znwm
6a04260: mov x21, x0
6a04264: bl #0x6a9e504
6a04268: mov x0, x21
6a0426c: bl #0x6a9e54c
6a04270: mov x0, x21
6a04274: mov x1, x20
6a04278: bl #0x6a9e550
6a0427c: ldr x1, [x19, #0x3c98]
6a04280: mov x0, x21
6a04284: bl #0x6a9e56c
6a04288: mov x0, x20
6a0428c: bl #0x6a824fc
6a04290: adrp x1, #0xaa9000
6a04294: add x1, x1, #0x37b
6a04298: mov x0, x21
6a0429c: mov w2, wzr
6a042a0: bl #0x6993ab8
6a042a4: ldr x3, [x19, #0x3c40]
6a042a8: mov x0, x20
6a042ac: mov x1, xzr
6a042b0: mov x2, xzr
6a042b4: bl #0x6a04454
6a042b8: mov w0, #0x20
6a042bc: bl #0x8b35260   ; PLT _Znwm
6a042c0: mov w1, wzr
6a042c4: mov x19, x0
6a042c8: bl #0x6a0ad5c
6a042cc: mov w0, #0x138
6a042d0: bl #0x8b35260   ; PLT _Znwm
6a042d4: mov x20, x0
6a042d8: bl #0x6a9ac7c
6a042dc: mov x0, x20
6a042e0: bl #0x6a9acc4
6a042e4: mov x0, x20
6a042e8: mov x1, x19
6a042ec: bl #0x6a9acc8
6a042f0: mov x0, x19
6a042f4: bl #0x6a0ae2c
6a042f8: adrp x19, #0xbc7000
6a042fc: add x19, x19, #0x82c
6a04300: mov x0, x20
6a04304: mov x1, x19
6a04308: mov w2, wzr
6a0430c: bl #0x6993ab8
6a04310: mov w0, #0x20
6a04314: bl #0x8b35260   ; PLT _Znwm
6a04318: mov w1, #1
6a0431c: mov x20, x0
6a04320: bl #0x6a0ad5c
6a04324: mov w0, #0x138
6a04328: bl #0x8b35260   ; PLT _Znwm
6a0432c: mov x21, x0
6a04330: bl #0x6a9ac7c
6a04334: mov x0, x21
6a04338: bl #0x6a9acc4
6a0433c: mov x0, x21
6a04340: mov x1, x20
6a04344: bl #0x6a9acc8
6a04348: mov x0, x20
6a0434c: bl #0x6a0ae2c
6a04350: mov x0, x21
6a04354: mov x1, x19
6a04358: mov w2, wzr
6a0435c: bl #0x6993ab8
6a04360: ldr x8, [x22, #0x28]
6a04364: ldr x9, [sp, #8]
6a04368: cmp x8, x9
6a0436c: b.ne #0x6a04384
6a04370: ldp x20, x19, [sp, #0x30]
6a04374: ldp x22, x21, [sp, #0x20]
6a04378: ldp x29, x30, [sp, #0x10]
6a0437c: add sp, sp, #0x40
6a04380: ret
6a04384: bl #0x8b35290   ; PLT __stack_chk_fail
6a04388: stp x29, x30, [sp, #-0x20]!
6a0438c: str x19, [sp, #0x10]
6a04390: mov x29, sp
6a04394: mov w0, #0x39e8
6a04398: bl #0x8b35260   ; PLT _Znwm
6a0439c: mov x19, x0
6a043a0: bl #0x6a9e9c0
6a043a4: mov x0, x19
6a043a8: bl #0x6a9ec48
6a043ac: adrp x1, #0xbc7000
6a043b0: add x1, x1, #0x82c
6a043b4: mov x0, x19
6a043b8: mov w2, wzr
6a043bc: bl #0x6993ab8
6a043c0: mov x0, x19
6a043c4: ldr x19, [sp, #0x10]
6a043c8: ldp x29, x30, [sp], #0x20
6a043cc: ret
6a043d0: cbz x0, #0x6a04450
6a043d4: stp x29, x30, [sp, #-0x30]!
6a043d8: str x21, [sp, #0x10]
6a043dc: stp x20, x19, [sp, #0x20]
6a043e0: mov x29, sp
6a043e4: mov x19, x0
6a043e8: mov w0, #0x278
6a043ec: bl #0x8b35260   ; PLT _Znwm
6a043f0: mov x20, x0
6a043f4: bl #0x6f4ba74
6a043f8: mov w0, #0x18
6a043fc: bl #0x8b35260   ; PLT _Znwm
6a04400: mov x21, x0
6a04404: bl #0x6f4c178
6a04408: mov x0, x20
6a0440c: mov x1, x21
6a04410: bl #0x6f4bb50
6a04414: mov x0, x19
6a04418: mov x1, x21
6a0441c: bl #0x6a9ef48
6a04420: adrp x1, #0xc13000
6a04424: add x1, x1, #0x70e
6a04428: mov x0, x20
6a0442c: mov w2, wzr
6a04430: bl #0x6993ab8
6a04434: adrp x1, #0x9eb000
6a04438: add x1, x1, #0x92f
6a0443c: mov x0, x20
6a04440: ldp x20, x19, [sp, #0x20]
6a04444: ldr x21, [sp, #0x10]
6a04448: ldp x29, x30, [sp], #0x30
6a0444c: b #0x6833104
6a04450: ret
6a04454: stp x29, x30, [sp, #-0x30]!
6a04458: str x21, [sp, #0x10]
6a0445c: stp x20, x19, [sp, #0x20]
6a04460: mov x29, sp
6a04464: mov x19, x3
6a04468: mov x21, x2
6a0446c: mov x20, x0
6a04470: cbz x1, #0x6a04488
6a04474: ldr x8, [x1]
6a04478: mov x0, x1
6a0447c: mov x1, x20
6a04480: ldr x8, [x8, #0x20]
6a04484: blr x8
6a04488: cbz x21, #0x6a044a0
6a0448c: ldr x8, [x21]
6a04490: mov x0, x21
6a04494: mov x1, x20
6a04498: ldr x8, [x8, #0x20]
6a0449c: blr x8
6a044a0: cbz x19, #0x6a044bc
6a044a4: mov x0, x19
6a044a8: mov x1, x20
6a044ac: ldp x20, x19, [sp, #0x20]
6a044b0: ldr x21, [sp, #0x10]
6a044b4: ldp x29, x30, [sp], #0x30
6a044b8: b #0x6a9ef48
6a044bc: ldp x20, x19, [sp, #0x20]
6a044c0: ldr x21, [sp, #0x10]
6a044c4: ldp x29, x30, [sp], #0x30
6a044c8: ret
6a044cc: sub sp, sp, #0x40
6a044d0: stp x29, x30, [sp, #0x10]
6a044d4: stp x22, x21, [sp, #0x20]
6a044d8: stp x20, x19, [sp, #0x30]
6a044dc: add x29, sp, #0x10
6a044e0: mrs x21, tpidr_el0
6a044e4: mov w19, w1
6a044e8: mov x20, x0
6a044ec: ldr x8, [x21, #0x28]
6a044f0: mov w22, #0x58
6a044f4: str x8, [sp, #8]
6a044f8: str wzr, [sp, #4]
6a044fc: b #0x6a04514
6a04500: add x0, sp, #4
6a04504: bl #0x6837104
6a04508: ldr w8, [sp, #4]
6a0450c: cmp w8, #2
6a04510: b.ge #0x6a04564
6a04514: mov w8, wzr
6a04518: str wzr, [sp]
6a0451c: b #0x6a04538
6a04520: mov x0, sp
6a04524: mov w1, wzr
6a04528: bl #0x68b3fa8
6a0452c: ldr w8, [sp]
6a04530: cmp w8, #0xb
6a04534: b.ge #0x6a04500
6a04538: ldr w9, [sp, #4]
6a0453c: nop
6a04540: umaddl x9, w9, w22, x20
6a04544: add x8, x9, w8, sxtw #3
6a04548: ldr x0, [x8, #0x10]
6a0454c: cbz x0, #0x6a04520
6a04550: ldr x8, [x0]
6a04554: and w1, w19, #1
6a04558: ldr x8, [x8, #0x70]
6a0455c: blr x8
6a04560: b #0x6a04520
6a04564: mov x8, xzr
6a04568: str wzr, [sp, #4]
6a0456c: b #0x6a04584
6a04570: add x0, sp, #4
6a04574: bl #0x69ffcb4
6a04578: ldr w8, [sp, #4]
6a0457c: cmp w8, #3
6a04580: b.ge #0x6a045a4
6a04584: add x8, x20, x8, lsl #3
6a04588: ldr x0, [x8, #0xc0]
6a0458c: cbz x0, #0x6a04570
6a04590: ldr x8, [x0]
6a04594: and w1, w19, #1
6a04598: ldr x8, [x8, #0x70]
6a0459c: blr x8
6a045a0: b #0x6a04570
6a045a4: ldr x0, [x20, #0xd8]
6a045a8: cbz x0, #0x6a045bc
6a045ac: ldr x8, [x0]
6a045b0: and w1, w19, #1
6a045b4: ldr x8, [x8, #0x70]
6a045b8: blr x8
6a045bc: mov x8, xzr
6a045c0: str wzr, [sp, #4]
6a045c4: b #0x6a045dc
6a045c8: add x0, sp, #4
6a045cc: bl #0x6837104
6a045d0: ldr w8, [sp, #4]
6a045d4: cmp w8, #2
6a045d8: b.ge #0x6a045fc
6a045dc: add x8, x20, x8, lsl #3
6a045e0: ldr x0, [x8, #0xe0]
6a045e4: cbz x0, #0x6a045c8
6a045e8: ldr x8, [x0]
6a045ec: and w1, w19, #1
6a045f0: ldr x8, [x8, #0x70]
6a045f4: blr x8
6a045f8: b #0x6a045c8
6a045fc: mov x8, xzr
6a04600: str wzr, [sp, #4]
6a04604: b #0x6a0461c
6a04608: add x0, sp, #4
6a0460c: bl #0x6837104
6a04610: ldr w8, [sp, #4]
6a04614: cmp w8, #2
6a04618: b.ge #0x6a0463c
6a0461c: add x8, x20, x8, lsl #3
6a04620: ldr x0, [x8, #0xf0]
6a04624: cbz x0, #0x6a04608
6a04628: ldr x8, [x0]
6a0462c: and w1, w19, #1
6a04630: ldr x8, [x8, #0x70]
6a04634: blr x8
6a04638: b #0x6a04608
6a0463c: ldr x8, [x21, #0x28]
6a04640: ldr x9, [sp, #8]
6a04644: cmp x8, x9
6a04648: b.ne #0x6a04660
6a0464c: ldp x20, x19, [sp, #0x30]
6a04650: ldp x22, x21, [sp, #0x20]
6a04654: ldp x29, x30, [sp, #0x10]
6a04658: add sp, sp, #0x40
6a0465c: ret
6a04660: bl #0x8b35290   ; PLT __stack_chk_fail
6a04664: sub sp, sp, #0x40
6a04668: stp x29, x30, [sp, #0x10]
6a0466c: str x21, [sp, #0x20]
6a04670: stp x20, x19, [sp, #0x30]
6a04674: add x29, sp, #0x10
6a04678: mrs x20, tpidr_el0
6a0467c: mov x19, x0
6a04680: ldr x8, [x20, #0x28]
6a04684: mov w21, #0x58
6a04688: str x8, [sp, #8]
6a0468c: str wzr, [sp, #4]
6a04690: b #0x6a046a8
6a04694: add x0, sp, #4
6a04698: bl #0x6837104
6a0469c: ldr w8, [sp, #4]
6a046a0: cmp w8, #2
6a046a4: b.ge #0x6a046f4
6a046a8: mov w8, wzr
6a046ac: str wzr, [sp]
6a046b0: b #0x6a046cc
6a046b4: mov x0, sp
6a046b8: mov w1, wzr
6a046bc: bl #0x68b3fa8
6a046c0: ldr w8, [sp]
6a046c4: cmp w8, #0xb
6a046c8: b.ge #0x6a04694
6a046cc: ldr w9, [sp, #4]
6a046d0: nop
6a046d4: umaddl x9, w9, w21, x19
6a046d8: add x8, x9, w8, sxtw #3
6a046dc: ldr x0, [x8, #0x10]
6a046e0: cbz x0, #0x6a046b4
6a046e4: ldr x8, [x0]
6a046e8: ldr x8, [x8, #0x60]
6a046ec: blr x8
6a046f0: b #0x6a046b4
6a046f4: mov x8, xzr
6a046f8: str wzr, [sp, #4]
6a046fc: b #0x6a04714
6a04700: add x0, sp, #4
6a04704: bl #0x69ffcb4
6a04708: ldr w8, [sp, #4]
6a0470c: cmp w8, #3
6a04710: b.ge #0x6a04730
6a04714: add x8, x19, x8, lsl #3
6a04718: ldr x0, [x8, #0xc0]
6a0471c: cbz x0, #0x6a04700
6a04720: ldr x8, [x0]
6a04724: ldr x8, [x8, #0x60]
6a04728: blr x8
6a0472c: b #0x6a04700
6a04730: str wzr, [sp, #4]
6a04734: add x0, sp, #4
6a04738: bl #0x6837104
6a0473c: ldr w8, [sp, #4]
6a04740: cmp w8, #2
6a04744: b.lt #0x6a04734
6a04748: str wzr, [sp, #4]
6a0474c: add x0, sp, #4
6a04750: bl #0x6837104
6a04754: ldr w8, [sp, #4]
6a04758: cmp w8, #2
6a0475c: b.lt #0x6a0474c
6a04760: ldr x8, [x20, #0x28]
6a04764: ldr x9, [sp, #8]
6a04768: cmp x8, x9
6a0476c: b.ne #0x6a04784
6a04770: ldp x20, x19, [sp, #0x30]
6a04774: ldp x29, x30, [sp, #0x10]
6a04778: ldr x21, [sp, #0x20]
6a0477c: add sp, sp, #0x40
6a04780: ret
6a04784: bl #0x8b35290   ; PLT __stack_chk_fail
6a04788: ldr x0, [x0, #0x3c98]
6a0478c: cbz x0, #0x6a04798
6a04790: and w1, w1, #1
6a04794: b #0x6a369d0
6a04798: ret
6a0479c: ldr x0, [x0, #0x3c98]
6a047a0: cbz x0, #0x6a047a8
6a047a4: b #0x6a36bd4
6a047a8: ret
6a047ac: sub sp, sp, #0x50
6a047b0: stp x29, x30, [sp, #0x10]
6a047b4: str x23, [sp, #0x20]
6a047b8: stp x22, x21, [sp, #0x30]
6a047bc: stp x20, x19, [sp, #0x40]
6a047c0: add x29, sp, #0x10
6a047c4: mrs x20, tpidr_el0
6a047c8: mov x19, x0
6a047cc: ldr x8, [x20, #0x28]
6a047d0: mov w21, #0x58
6a047d4: mov w22, #2
6a047d8: str x8, [sp, #8]
6a047dc: str wzr, [sp, #4]
6a047e0: b #0x6a047fc
6a047e4: add x0, sp, #4
6a047e8: mov w1, wzr
6a047ec: bl #0x683a9c4
6a047f0: ldr w8, [sp, #4]
6a047f4: cmp w8, #2
6a047f8: b.ge #0x6a04868
6a047fc: mov w8, wzr
6a04800: str wzr, [sp]
6a04804: b #0x6a04820
6a04808: mov x0, sp
6a0480c: mov w1, wzr
6a04810: bl #0x68b3fa8
6a04814: ldr w8, [sp]
6a04818: cmp w8, #0xb
6a0481c: b.ge #0x6a047e4
6a04820: ldr w23, [sp, #4]
6a04824: nop
6a04828: umaddl x9, w23, w21, x19
6a0482c: add x8, x9, w8, sxtw #3
6a04830: ldr x0, [x8, #0x10]
6a04834: cbz x0, #0x6a04808
6a04838: bl #0x6a048d8
6a0483c: ldp w9, w8, [sp]
6a04840: sxtw x9, w9
6a04844: umaddl x8, w8, w21, x19
6a04848: add x8, x8, x9, lsl #3
6a0484c: ands w9, w0, #1
6a04850: cinc w10, w22, ne
6a04854: cmp w23, #0
6a04858: csel w1, w9, w10, eq
6a0485c: ldr x0, [x8, #0x10]
6a04860: bl #0x6f450f0
6a04864: b #0x6a04808
6a04868: mov x8, xzr
6a0486c: mov w21, #4
6a04870: str wzr, [sp, #4]
6a04874: b #0x6a04890
6a04878: add x0, sp, #4
6a0487c: mov w1, wzr
6a04880: bl #0x6a048e0
6a04884: ldr w8, [sp, #4]
6a04888: cmp w8, #3
6a0488c: b.ge #0x6a048ac
6a04890: add x9, x19, x8, lsl #3
6a04894: ldr x0, [x9, #0xc0]
6a04898: cbz x0, #0x6a04878
6a0489c: cmp x8, #0
6a048a0: cinc w1, w21, ne
6a048a4: bl #0x6f450f0
6a048a8: b #0x6a04878
6a048ac: ldr x8, [x20, #0x28]
6a048b0: ldr x9, [sp, #8]
6a048b4: cmp x8, x9
6a048b8: b.ne #0x6a048d4
6a048bc: ldp x20, x19, [sp, #0x40]
6a048c0: ldp x22, x21, [sp, #0x30]
6a048c4: ldp x29, x30, [sp, #0x10]
6a048c8: ldr x23, [sp, #0x20]
6a048cc: add sp, sp, #0x50
6a048d0: ret
6a048d4: bl #0x8b35290   ; PLT __stack_chk_fail
6a048d8: ldrb w0, [x0, #0x79c]
6a048dc: ret
6a048e0: stp x29, x30, [sp, #-0x20]!
6a048e4: str x19, [sp, #0x10]
6a048e8: mov x29, sp
6a048ec: ldr w19, [x0]
6a048f0: bl #0x69ffcb4
6a048f4: mov w0, w19
6a048f8: ldr x19, [sp, #0x10]
6a048fc: ldp x29, x30, [sp], #0x20
6a04900: ret
6a04904: stp x29, x30, [sp, #-0x20]!
6a04908: str x19, [sp, #0x10]
6a0490c: mov x29, sp
6a04910: mov w0, #0x140
6a04914: bl #0x8b35260   ; PLT _Znwm
6a04918: mov x19, x0
6a0491c: bl #0x6a0610c
6a04920: adrp x1, #0xc13000
6a04924: add x1, x1, #0x70e
6a04928: mov x0, x19
6a0492c: mov w2, wzr
6a04930: bl #0x6993ab8
6a04934: mov x0, x19
6a04938: ldr x19, [sp, #0x10]
6a0493c: ldp x29, x30, [sp], #0x20
6a04940: ret
6a04944: stp x29, x30, [sp, #-0x20]!
6a04948: str x19, [sp, #0x10]
6a0494c: mov x29, sp
6a04950: mov w0, #0x1d8
6a04954: bl #0x8b35260   ; PLT _Znwm
6a04958: mov x19, x0
6a0495c: bl #0x6a9b238
6a04960: mov x0, x19
6a04964: bl #0x6a9b290
6a04968: adrp x1, #0xa3f000
6a0496c: add x1, x1, #0xdd
6a04970: mov x0, x19
6a04974: mov w2, wzr
6a04978: bl #0x6993ab8
6a0497c: mov x0, x19
6a04980: ldr x19, [sp, #0x10]
6a04984: ldp x29, x30, [sp], #0x20
6a04988: ret
6a0498c: stp x29, x30, [sp, #-0x20]!
6a04990: str x19, [sp, #0x10]
6a04994: mov x29, sp
6a04998: mov w0, #0x1b00
6a0499c: bl #0x8b35260   ; PLT _Znwm
6a049a0: mov x19, x0
6a049a4: bl #0x6a9d158
6a049a8: adrp x1, #0x9d7000
6a049ac: add x1, x1, #0xe54
6a049b0: mov x0, x19
6a049b4: mov w2, wzr
6a049b8: bl #0x6993ab8
6a049bc: mov x0, x19
6a049c0: ldr x19, [sp, #0x10]
6a049c4: ldp x29, x30, [sp], #0x20
6a049c8: ret
6a049cc: stp x29, x30, [sp, #-0x20]!
6a049d0: str x19, [sp, #0x10]
6a049d4: mov x29, sp
6a049d8: mov w0, #0x198
6a049dc: bl #0x8b35260   ; PLT _Znwm
6a049e0: mov x19, x0
6a049e4: bl #0x6a9cd60
6a049e8: adrp x1, #0xb08000
6a049ec: add x1, x1, #0x1e3
6a049f0: mov x0, x19
6a049f4: mov w2, wzr
6a049f8: bl #0x6993ab8
6a049fc: mov x0, x19
6a04a00: ldr x19, [sp, #0x10]
6a04a04: ldp x29, x30, [sp], #0x20
6a04a08: ret
6a04a0c: stp x29, x30, [sp, #-0x20]!
6a04a10: str x19, [sp, #0x10]
6a04a14: mov x29, sp
6a04a18: mov w0, #0x140
6a04a1c: bl #0x8b35260   ; PLT _Znwm
6a04a20: mov x19, x0
6a04a24: bl #0x6a06148
6a04a28: adrp x1, #0xaa9000
6a04a2c: add x1, x1, #0x36c
6a04a30: mov x0, x19
6a04a34: mov w2, wzr
6a04a38: bl #0x6993ab8
6a04a3c: mov x0, x19
6a04a40: ldr x19, [sp, #0x10]
6a04a44: ldp x29, x30, [sp], #0x20
6a04a48: ret
6a04a4c: str w1, [x0, #0x190]
6a04a50: ret
6a04a54: stp x29, x30, [sp, #-0x20]!
6a04a58: str x19, [sp, #0x10]
6a04a5c: mov x29, sp
6a04a60: mov w0, #0x178
6a04a64: bl #0x8b35260   ; PLT _Znwm
6a04a68: mov x19, x0
6a04a6c: bl #0x6a9b93c
6a04a70: adrp x1, #0xa5c000
6a04a74: add x1, x1, #0x6f4
6a04a78: mov x0, x19
6a04a7c: mov w2, wzr
6a04a80: ldr x19, [sp, #0x10]
6a04a84: ldp x29, x30, [sp], #0x20
6a04a88: b #0x6993ab8
6a04a8c: stp x29, x30, [sp, #-0x20]!
6a04a90: stp x20, x19, [sp, #0x10]
6a04a94: mov x29, sp
6a04a98: mov w19, w0
6a04a9c: mov w0, #0x130
6a04aa0: bl #0x8b35260   ; PLT _Znwm
6a04aa4: mov w1, w19
6a04aa8: mov x20, x0
6a04aac: bl #0x6a9b814
6a04ab0: adrp x1, #0xaa9000
6a04ab4: add x1, x1, #0x362
6a04ab8: mov x0, x20
6a04abc: mov w2, wzr
6a04ac0: ldp x20, x19, [sp, #0x10]
6a04ac4: ldp x29, x30, [sp], #0x20
6a04ac8: b #0x6993ab8
6a04acc: stp x29, x30, [sp, #-0x20]!
6a04ad0: str x19, [sp, #0x10]
6a04ad4: mov x29, sp
6a04ad8: mov w0, #0x128
6a04adc: bl #0x8b35260   ; PLT _Znwm
6a04ae0: mov x19, x0
6a04ae4: bl #0x6a9bbbc
6a04ae8: adrp x1, #0xbb4000
6a04aec: add x1, x1, #0x433
6a04af0: mov x0, x19
6a04af4: mov w2, wzr
6a04af8: ldr x19, [sp, #0x10]
6a04afc: ldp x29, x30, [sp], #0x20
6a04b00: b #0x6993ab8
6a04b04: add x0, x0, #0x128
6a04b08: b #0x71fa210
6a04b0c: sub sp, sp, #0xe0
6a04b10: stp x29, x30, [sp, #0xb0]
6a04b14: str x21, [sp, #0xc0]
6a04b18: stp x20, x19, [sp, #0xd0]
6a04b1c: add x29, sp, #0xb0
6a04b20: mrs x21, tpidr_el0
6a04b24: mov x19, x0
6a04b28: ldr x8, [x21, #0x28]
6a04b2c: add x0, sp, #0x28
6a04b30: stur x8, [x29, #-8]
6a04b34: bl #0x6a05620
6a04b38: mov x8, #0x20
6a04b3c: mov w0, #0xb0
6a04b40: movk x8, #0x108, lsl #32
6a04b44: movk x8, #0x203, lsl #48
6a04b48: str x8, [sp, #0x28]
6a04b4c: bl #0x8b35260   ; PLT _Znwm
6a04b50: mov x20, x0
6a04b54: sub x0, x29, #0x50
6a04b58: bl #0x68352cc
6a04b5c: sub x0, x29, #0x40
6a04b60: bl #0x684b500
6a04b64: add x1, sp, #0x28
6a04b68: sub x2, x29, #0x50
6a04b6c: sub x3, x29, #0x40
6a04b70: mov x0, x20
6a04b74: bl #0x6a05668
6a04b78: str x20, [x19, #0x108]
6a04b7c: bl #0x66f0238
6a04b80: ldr x4, [x19, #0x108]
6a04b84: mov w1, #8
6a04b88: mov w2, #1
6a04b8c: mov w3, #9
6a04b90: bl #0x66f03dc
6a04b94: bl #0x6813ef4
6a04b98: tbz w0, #0, #0x6a04c2c
6a04b9c: sub x0, x29, #0x40
6a04ba0: bl #0x6a05620
6a04ba4: mov x8, #0x21
6a04ba8: mov w0, #0xb0
6a04bac: movk x8, #0x109, lsl #32
6a04bb0: movk x8, #0x203, lsl #48
6a04bb4: stur x8, [x29, #-0x40]
6a04bb8: bl #0x8b35260   ; PLT _Znwm
6a04bbc: mov x20, x0
6a04bc0: add x0, sp, #0x18
6a04bc4: bl #0x68352cc
6a04bc8: sub x0, x29, #0x50
6a04bcc: bl #0x684b500
6a04bd0: sub x1, x29, #0x40
6a04bd4: add x2, sp, #0x18
6a04bd8: sub x3, x29, #0x50
6a04bdc: mov x0, x20
6a04be0: bl #0x6a05668
6a04be4: str x20, [x19, #0x110]
6a04be8: bl #0x66f0238
6a04bec: mov w8, #0x3bf8
6a04bf0: mov x20, x0
6a04bf4: add x0, x19, x8
6a04bf8: bl #0x683a870
6a04bfc: mov x1, x0
6a04c00: mov x0, sp
6a04c04: bl #0x66f92ec
6a04c08: ldr x5, [x19, #0x110]
6a04c0c: mov x1, sp
6a04c10: mov x0, x20
6a04c14: mov w2, #9
6a04c18: mov w3, #1
6a04c1c: mov w4, wzr
6a04c20: bl #0x66f05d0
6a04c24: mov x0, sp
6a04c28: bl #0x66f9510
6a04c2c: ldr x8, [x21, #0x28]
6a04c30: ldur x9, [x29, #-8]
6a04c34: cmp x8, x9
6a04c38: b.ne #0x6a04c50
6a04c3c: ldp x20, x19, [sp, #0xd0]
6a04c40: ldp x29, x30, [sp, #0xb0]
6a04c44: ldr x21, [sp, #0xc0]
6a04c48: add sp, sp, #0xe0
6a04c4c: ret
6a04c50: bl #0x8b35290   ; PLT __stack_chk_fail
6a04c54: sub sp, sp, #0x110
6a04c58: stp d9, d8, [sp, #0xc0]
6a04c5c: stp x29, x30, [sp, #0xd0]
6a04c60: stp x28, x23, [sp, #0xe0]
6a04c64: stp x22, x21, [sp, #0xf0]
6a04c68: stp x20, x19, [sp, #0x100]
6a04c6c: add x29, sp, #0xd0
6a04c70: mrs x22, tpidr_el0
6a04c74: mov x19, x0
6a04c78: ldr x8, [x22, #0x28]
6a04c7c: stur x8, [x29, #-0x18]
6a04c80: bl #0x6a02d4c
6a04c84: bl #0x727c8b0
6a04c88: tbz w0, #0, #0x6a050e0
6a04c8c: add x0, x19, #0x128
6a04c90: bl #0x71faa50
6a04c94: mov x19, x0
6a04c98: add x0, sp, #0x68
6a04c9c: add x8, sp, #0x68
6a04ca0: add x21, x8, #0x2c
6a04ca4: add x20, x8, #0x20
6a04ca8: bl #0x6a05620
6a04cac: ldr s0, [x19, #0x40]
6a04cb0: fmov s9, #0.50000000
6a04cb4: mov x23, #0x22
6a04cb8: movi d2, #0000000000000000
6a04cbc: movk x23, #0x10a, lsl #32
6a04cc0: mov x0, x21
6a04cc4: fmul s0, s0, s9
6a04cc8: movk x23, #0x201, lsl #48
6a04ccc: str x23, [sp, #0x68]
6a04cd0: str s0, [sp, #0x74]
6a04cd4: ldr s1, [x19, #0xc]
6a04cd8: fmul s1, s1, s9
6a04cdc: fadd s1, s0, s1
6a04ce0: movi d0, #0000000000000000
6a04ce4: bl #0x684b6c0
6a04ce8: ldr s0, [x19, #0xc]
6a04cec: movi d2, #0000000000000000
6a04cf0: ldr s1, [x19, #0x40]
6a04cf4: mov x0, x20
6a04cf8: fmul s0, s0, s9
6a04cfc: fmul s1, s1, s9
6a04d00: fadd s0, s0, s1
6a04d04: fneg s1, s0
6a04d08: movi d0, #0000000000000000
6a04d0c: bl #0x684b6c0
6a04d10: ldr s0, [x19, #0x40]
6a04d14: add x0, sp, #0x50
6a04d18: ldp s4, s3, [x19, #8]
6a04d1c: ldr s1, [x19]
6a04d20: fmul s2, s0, s9
6a04d24: fsub s0, s1, s2
6a04d28: fmul s1, s3, s9
6a04d2c: fadd s2, s2, s4
6a04d30: bl #0x684bf44
6a04d34: sub x0, x29, #0x30
6a04d38: bl #0x684b500
6a04d3c: ldr s0, [sp, #0x50]
6a04d40: ldr s1, [sp, #0x58]
6a04d44: fneg s0, s0
6a04d48: fneg s1, s1
6a04d4c: str s0, [sp, #0x50]
6a04d50: str s1, [sp, #0x58]
6a04d54: bl #0x6a067b8
6a04d58: add x1, sp, #0x68
6a04d5c: add x2, sp, #0x50
6a04d60: sub x3, x29, #0x30
6a04d64: bl #0x6a0833c
6a04d68: add x0, sp, #0x68
6a04d6c: bl #0x6a05620
6a04d70: ldr s0, [x19, #0x40]
6a04d74: movi d2, #0000000000000000
6a04d78: mov x0, x21
6a04d7c: str x23, [sp, #0x68]
6a04d80: fmul s0, s0, s9
6a04d84: str s0, [sp, #0x74]
6a04d88: ldr s1, [x19, #0xc]
6a04d8c: fmul s1, s1, s9
6a04d90: fadd s1, s0, s1
6a04d94: movi d0, #0000000000000000
6a04d98: bl #0x684b6c0
6a04d9c: ldr s0, [x19, #0xc]
6a04da0: movi d2, #0000000000000000
6a04da4: ldr s1, [x19, #0x40]
6a04da8: mov x0, x20
6a04dac: fmul s0, s0, s9
6a04db0: fmul s1, s1, s9
6a04db4: fadd s0, s0, s1
6a04db8: fneg s1, s0
6a04dbc: movi d0, #0000000000000000
6a04dc0: bl #0x684b6c0
6a04dc4: ldr s0, [x19, #0x40]
6a04dc8: add x0, sp, #0x50
6a04dcc: ldp s4, s3, [x19, #8]
6a04dd0: ldr s1, [x19]
6a04dd4: fmul s2, s0, s9
6a04dd8: fsub s0, s1, s2
6a04ddc: fmul s1, s3, s9
6a04de0: fadd s2, s2, s4
6a04de4: bl #0x684bf44
6a04de8: sub x0, x29, #0x30
6a04dec: bl #0x684b500
6a04df0: ldr s0, [sp, #0x58]
6a04df4: fneg s0, s0
6a04df8: str s0, [sp, #0x58]
6a04dfc: bl #0x6a067b8
6a04e00: add x1, sp, #0x68
6a04e04: add x2, sp, #0x50
6a04e08: sub x3, x29, #0x30
6a04e0c: bl #0x6a0833c
6a04e10: add x0, sp, #0x68
6a04e14: bl #0x6a05620
6a04e18: ldr s0, [x19, #0x40]
6a04e1c: movi d2, #0000000000000000
6a04e20: mov x0, x21
6a04e24: str x23, [sp, #0x68]
6a04e28: fmul s0, s0, s9
6a04e2c: str s0, [sp, #0x74]
6a04e30: ldr s1, [x19, #0xc]
6a04e34: fmul s1, s1, s9
6a04e38: fadd s1, s0, s1
6a04e3c: movi d0, #0000000000000000
6a04e40: bl #0x684b6c0
6a04e44: ldr s0, [x19, #0xc]
6a04e48: movi d2, #0000000000000000
6a04e4c: ldr s1, [x19, #0x40]
6a04e50: mov x0, x20
6a04e54: fmul s0, s0, s9
6a04e58: fmul s1, s1, s9
6a04e5c: fadd s0, s0, s1
6a04e60: fneg s1, s0
6a04e64: movi d0, #0000000000000000
6a04e68: bl #0x684b6c0
6a04e6c: ldr s0, [x19, #0x40]
6a04e70: add x0, sp, #0x50
6a04e74: ldp s4, s3, [x19, #8]
6a04e78: ldr s1, [x19]
6a04e7c: fmul s2, s0, s9
6a04e80: fsub s0, s1, s2
6a04e84: fmul s1, s3, s9
6a04e88: fadd s2, s2, s4
6a04e8c: bl #0x684bf44
6a04e90: sub x0, x29, #0x30
6a04e94: bl #0x684b500
6a04e98: ldr s0, [sp, #0x50]
6a04e9c: fneg s0, s0
6a04ea0: str s0, [sp, #0x50]
6a04ea4: bl #0x6a067b8
6a04ea8: add x1, sp, #0x68
6a04eac: add x2, sp, #0x50
6a04eb0: sub x3, x29, #0x30
6a04eb4: bl #0x6a0833c
6a04eb8: add x0, sp, #0x68
6a04ebc: bl #0x6a05620
6a04ec0: ldr s0, [x19, #0x40]
6a04ec4: movi d2, #0000000000000000
6a04ec8: mov x0, x21
6a04ecc: str x23, [sp, #0x68]
6a04ed0: fmul s0, s0, s9
6a04ed4: str s0, [sp, #0x74]
6a04ed8: ldr s1, [x19, #0xc]
6a04edc: fmul s1, s1, s9
6a04ee0: fadd s1, s0, s1
6a04ee4: movi d0, #0000000000000000
6a04ee8: bl #0x684b6c0
6a04eec: ldr s0, [x19, #0xc]
6a04ef0: movi d2, #0000000000000000
6a04ef4: ldr s1, [x19, #0x40]
6a04ef8: mov x0, x20
6a04efc: fmul s0, s0, s9
6a04f00: fmul s1, s1, s9
6a04f04: fadd s0, s0, s1
6a04f08: fneg s1, s0
6a04f0c: movi d0, #0000000000000000
6a04f10: bl #0x684b6c0
6a04f14: ldr s0, [x19, #0x40]
6a04f18: add x0, sp, #0x50
6a04f1c: ldp s4, s3, [x19, #8]
6a04f20: ldr s1, [x19]
6a04f24: fmul s2, s0, s9
6a04f28: fsub s0, s1, s2
6a04f2c: fmul s1, s3, s9
6a04f30: fadd s2, s2, s4
6a04f34: bl #0x684bf44
6a04f38: sub x0, x29, #0x30
6a04f3c: bl #0x684b500
6a04f40: bl #0x6a067b8
6a04f44: add x1, sp, #0x68
6a04f48: add x2, sp, #0x50
6a04f4c: sub x3, x29, #0x30
6a04f50: bl #0x6a0833c
6a04f54: add x0, sp, #0x68
6a04f58: bl #0x6a05620
6a04f5c: ldr s0, [x19, #0x40]
6a04f60: mov x0, x21
6a04f64: str x23, [sp, #0x68]
6a04f68: fmul s0, s0, s9
6a04f6c: str s0, [sp, #0x74]
6a04f70: ldr s1, [x19, #8]
6a04f74: fadd s2, s0, s1
6a04f78: movi d0, #0000000000000000
6a04f7c: movi d1, #0000000000000000
6a04f80: bl #0x684b6c0
6a04f84: ldr s0, [x19, #0x40]
6a04f88: mov x0, x20
6a04f8c: ldr s1, [x19, #8]
6a04f90: fmul s0, s0, s9
6a04f94: fadd s0, s1, s0
6a04f98: movi d1, #0000000000000000
6a04f9c: fneg s2, s0
6a04fa0: movi d0, #0000000000000000
6a04fa4: bl #0x684b6c0
6a04fa8: ldr s0, [x19, #0x40]
6a04fac: add x0, sp, #0x50
6a04fb0: ldr s1, [x19]
6a04fb4: ldr s3, [x19, #0xc]
6a04fb8: fmul s2, s0, s9
6a04fbc: fsub s0, s1, s2
6a04fc0: fadd s1, s3, s2
6a04fc4: movi d2, #0000000000000000
6a04fc8: bl #0x684bf44
6a04fcc: sub x0, x29, #0x30
6a04fd0: bl #0x684b500
6a04fd4: movi d1, #0000000000000000
6a04fd8: movi d2, #0000000000000000
6a04fdc: add x0, sp, #0x38
6a04fe0: fmov s0, #1.00000000
6a04fe4: bl #0x684bf44
6a04fe8: mov w8, #0xfdb
6a04fec: sub x0, x29, #0x30
6a04ff0: movk w8, #0x3fc9, lsl #16
6a04ff4: add x1, sp, #0x38
6a04ff8: fmov s8, w8
6a04ffc: fmov s0, s8
6a05000: bl #0x729bc7c
6a05004: ldr s0, [sp, #0x50]
6a05008: fneg s0, s0
6a0500c: str s0, [sp, #0x50]
6a05010: bl #0x6a067b8
6a05014: add x1, sp, #0x68
6a05018: add x2, sp, #0x50
6a0501c: sub x3, x29, #0x30
6a05020: bl #0x6a0833c
6a05024: add x0, sp, #0x68
6a05028: bl #0x6a05620
6a0502c: ldr s0, [x19, #0x40]
6a05030: mov x0, x21
6a05034: str x23, [sp, #0x68]
6a05038: fmul s0, s0, s9
6a0503c: str s0, [sp, #0x74]
6a05040: ldr s1, [x19, #8]
6a05044: fadd s2, s0, s1
6a05048: movi d0, #0000000000000000
6a0504c: movi d1, #0000000000000000
6a05050: bl #0x684b6c0
6a05054: ldr s0, [x19, #0x40]
6a05058: mov x0, x20
6a0505c: ldr s1, [x19, #8]
6a05060: fmul s0, s0, s9
6a05064: fadd s0, s1, s0
6a05068: movi d1, #0000000000000000
6a0506c: fneg s2, s0
6a05070: movi d0, #0000000000000000
6a05074: bl #0x684b6c0
6a05078: ldr s0, [x19, #0x40]
6a0507c: add x0, sp, #0x50
6a05080: ldr s1, [x19]
6a05084: ldr s3, [x19, #0xc]
6a05088: fmul s2, s0, s9
6a0508c: fsub s0, s1, s2
6a05090: fadd s1, s3, s2
6a05094: movi d2, #0000000000000000
6a05098: bl #0x684bf44
6a0509c: sub x0, x29, #0x30
6a050a0: bl #0x684b500
6a050a4: movi d1, #0000000000000000
6a050a8: movi d2, #0000000000000000
6a050ac: add x0, sp, #0x38
6a050b0: fmov s0, #1.00000000
6a050b4: bl #0x684bf44
6a050b8: fmov s0, s8
6a050bc: sub x0, x29, #0x30
6a050c0: add x1, sp, #0x38
6a050c4: bl #0x729bc7c
6a050c8: bl #0x6a067b8
6a050cc: add x1, sp, #0x68
6a050d0: add x2, sp, #0x50
6a050d4: sub x3, x29, #0x30
6a050d8: bl #0x6a0833c
6a050dc: b #0x6a0524c
6a050e0: add x0, sp, #0x68
6a050e4: bl #0x6a05620
6a050e8: mov x8, #0x22
6a050ec: mov w0, #0xb0
6a050f0: movk x8, #0x10a, lsl #32
6a050f4: movk x8, #0x203, lsl #48
6a050f8: str x8, [sp, #0x68]
6a050fc: bl #0x8b35260   ; PLT _Znwm
6a05100: mov x20, x0
6a05104: add x0, sp, #0x50
6a05108: bl #0x68352cc
6a0510c: sub x0, x29, #0x30
6a05110: bl #0x684b500
6a05114: add x1, sp, #0x68
6a05118: add x2, sp, #0x50
6a0511c: sub x3, x29, #0x30
6a05120: mov x0, x20
6a05124: bl #0x6a05668
6a05128: adrp x1, #0xb08000
6a0512c: add x1, x1, #0x75a
6a05130: sub x0, x29, #0x30
6a05134: str x20, [x19, #0x118]
6a05138: bl #0x2f649fc
6a0513c: sub x0, x29, #0x30
6a05140: bl #0x683a870
6a05144: bl #0x812ce6c
6a05148: tbnz w0, #0, #0x6a05170
6a0514c: adrp x1, #0xc13000
6a05150: add x1, x1, #0xc16
6a05154: add x0, sp, #0x50
6a05158: bl #0x2f649fc
6a0515c: sub x0, x29, #0x30
6a05160: add x1, sp, #0x50
6a05164: bl #0x66c8274
6a05168: add x0, sp, #0x50
6a0516c: bl #0x2ef7b54
6a05170: adrp x1, #0xbc7000
6a05174: add x1, x1, #0xc86
6a05178: add x0, sp, #0x50
6a0517c: bl #0x2f649fc
6a05180: add x0, sp, #0x50
6a05184: bl #0x683a870
6a05188: bl #0x812ce6c
6a0518c: tbnz w0, #0, #0x6a051b4
6a05190: adrp x1, #0xaf5000
6a05194: add x1, x1, #0x47f
6a05198: add x0, sp, #0x38
6a0519c: bl #0x2f649fc
6a051a0: add x0, sp, #0x50
6a051a4: add x1, sp, #0x38
6a051a8: bl #0x66c8274
6a051ac: add x0, sp, #0x38
6a051b0: bl #0x2ef7b54
6a051b4: bl #0x66f0238
6a051b8: mov x20, x0
6a051bc: sub x0, x29, #0x30
6a051c0: bl #0x683a870
6a051c4: mov x1, x0
6a051c8: add x0, sp, #0x20
6a051cc: bl #0x66f92ec
6a051d0: ldr x5, [x19, #0x118]
6a051d4: add x1, sp, #0x20
6a051d8: mov x0, x20
6a051dc: mov w2, #0xa
6a051e0: mov w3, #1
6a051e4: mov w4, wzr
6a051e8: mov w6, wzr
6a051ec: bl #0x66f09b8
6a051f0: add x0, sp, #0x20
6a051f4: bl #0x66f9510
6a051f8: bl #0x66f0238
6a051fc: mov x20, x0
6a05200: add x0, sp, #0x50
6a05204: bl #0x683a870
6a05208: mov x1, x0
6a0520c: add x0, sp, #8
6a05210: bl #0x66f92ec
6a05214: ldr x5, [x19, #0x118]
6a05218: add x1, sp, #8
6a0521c: mov x0, x20
6a05220: mov w2, #0xa
6a05224: mov w3, #1
6a05228: mov w4, wzr
6a0522c: mov w6, #1
6a05230: bl #0x66f09b8
6a05234: add x0, sp, #8
6a05238: bl #0x66f9510
6a0523c: add x0, sp, #0x50
6a05240: bl #0x2ef7b54
6a05244: sub x0, x29, #0x30
6a05248: bl #0x2ef7b54
6a0524c: ldr x8, [x22, #0x28]
6a05250: ldur x9, [x29, #-0x18]
6a05254: cmp x8, x9
6a05258: b.ne #0x6a05278
6a0525c: ldp x20, x19, [sp, #0x100]
6a05260: ldp x22, x21, [sp, #0xf0]
6a05264: ldp x28, x23, [sp, #0xe0]
6a05268: ldp x29, x30, [sp, #0xd0]
6a0526c: ldp d9, d8, [sp, #0xc0]
6a05270: add sp, sp, #0x110
6a05274: ret
6a05278: bl #0x8b35290   ; PLT __stack_chk_fail
6a0527c: sub sp, sp, #0xb0
6a05280: stp x29, x30, [sp, #0x80]
6a05284: str x21, [sp, #0x90]
6a05288: stp x20, x19, [sp, #0xa0]
6a0528c: add x29, sp, #0x80
6a05290: mrs x21, tpidr_el0
6a05294: mov x19, x0
6a05298: ldr x8, [x21, #0x28]
6a0529c: add x0, sp, #0x30
6a052a0: stur x8, [x29, #-8]
6a052a4: bl #0x6a05620
6a052a8: mov x8, #0x23
6a052ac: mov w0, #0xb0
6a052b0: movk x8, #0x106, lsl #32
6a052b4: movk x8, #0x203, lsl #48
6a052b8: str x8, [sp, #0x30]
6a052bc: bl #0x8b35260   ; PLT _Znwm
6a052c0: mov x20, x0
6a052c4: add x0, sp, #0x20
6a052c8: bl #0x68352cc
6a052cc: sub x0, x29, #0x18
6a052d0: bl #0x684b500
6a052d4: add x1, sp, #0x30
6a052d8: add x2, sp, #0x20
6a052dc: sub x3, x29, #0x18
6a052e0: mov x0, x20
6a052e4: bl #0x6a05668
6a052e8: str x20, [x19, #0x120]
6a052ec: bl #0x66f0238
6a052f0: mov w8, #0x3c10
6a052f4: mov x20, x0
6a052f8: add x0, x19, x8
6a052fc: bl #0x683a870
6a05300: mov x1, x0
6a05304: add x0, sp, #8
6a05308: bl #0x66f92ec
6a0530c: ldr x5, [x19, #0x120]
6a05310: add x1, sp, #8
6a05314: mov x0, x20
6a05318: mov w2, #6
6a0531c: mov w3, #1
6a05320: mov w4, wzr
6a05324: bl #0x66f0d44
6a05328: add x0, sp, #8
6a0532c: bl #0x66f9510
6a05330: ldr x8, [x21, #0x28]
6a05334: ldur x9, [x29, #-8]
6a05338: cmp x8, x9
6a0533c: b.ne #0x6a05354
6a05340: ldp x20, x19, [sp, #0xa0]
6a05344: ldp x29, x30, [sp, #0x80]
6a05348: ldr x21, [sp, #0x90]
6a0534c: add sp, sp, #0xb0
6a05350: ret
6a05354: bl #0x8b35290   ; PLT __stack_chk_fail
6a05358: sub sp, sp, #0xb0
6a0535c: str d10, [sp, #0x60]
6a05360: stp d9, d8, [sp, #0x68]
6a05364: stp x29, x30, [sp, #0x78]
6a05368: str x23, [sp, #0x88]
6a0536c: stp x22, x21, [sp, #0x90]
6a05370: stp x20, x19, [sp, #0xa0]
6a05374: add x29, sp, #0x78
6a05378: mrs x21, tpidr_el0
6a0537c: add x0, sp, #0x10
6a05380: ldr x8, [x21, #0x28]
6a05384: add x9, sp, #0x10
6a05388: add x20, x9, #0x2c
6a0538c: add x19, x9, #0x20
6a05390: stur x8, [x29, #-0x20]
6a05394: bl #0x6a05620
6a05398: mov w8, #0x6c8b
