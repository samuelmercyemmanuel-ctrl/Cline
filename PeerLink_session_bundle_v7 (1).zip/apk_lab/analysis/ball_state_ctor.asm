6d82418: stp x29, x30, [sp, #-0x50]!
6d8241c: str x25, [sp, #0x10]
6d82420: stp x24, x23, [sp, #0x20]
6d82424: stp x22, x21, [sp, #0x30]
6d82428: stp x20, x19, [sp, #0x40]
6d8242c: mov x29, sp
6d82430: mov x19, x0
6d82434: bl #0x68352cc
6d82438: add x0, x19, #0xc
6d8243c: bl #0x68352cc
6d82440: add x0, x19, #0x18
6d82444: bl #0x68352cc
6d82448: add x20, x19, #0x2c
6d8244c: mov x0, x20
6d82450: bl #0x68352cc
6d82454: add x21, x19, #0x38
6d82458: mov x0, x21
6d8245c: bl #0x68352cc
6d82460: add x22, x19, #0x44
6d82464: mov x0, x22
6d82468: bl #0x68352cc
6d8246c: add x23, x19, #0x50
6d82470: mov x0, x23
6d82474: bl #0x68352cc
6d82478: add x24, x19, #0x5c
6d8247c: mov x0, x24
6d82480: bl #0x68352cc
6d82484: add x25, x19, #0x68
6d82488: mov x0, x25
6d8248c: bl #0x68352cc
6d82490: add x0, x19, #0x98
6d82494: bl #0x684b500
6d82498: add x0, x19, #0xa8
6d8249c: bl #0x684c044
6d824a0: add x0, x19, #0xe8
6d824a4: bl #0x684c044
6d824a8: mov w8, #0x96bb
6d824ac: mov w9, #0x700
6d824b0: movk w8, #0x3dde, lsl #16
6d824b4: mov w10, #6
6d824b8: mov x0, x20
6d824bc: stp wzr, wzr, [x19, #0x24]
6d824c0: strh w9, [x19, #0x90]
6d824c4: str w8, [x19, #4]
6d824c8: str w10, [x19, #0x94]
6d824cc: bl #0x68bf588
6d824d0: mov x0, x21
6d824d4: str wzr, [x19, #0x74]
6d824d8: bl #0x68bf588
6d824dc: mov x0, x22
6d824e0: str wzr, [x19, #0x78]
6d824e4: bl #0x68bf588
6d824e8: mov x0, x23
6d824ec: str wzr, [x19, #0x7c]
6d824f0: bl #0x68bf588
6d824f4: mov x0, x24
6d824f8: str wzr, [x19, #0x80]
6d824fc: bl #0x68bf588
6d82500: mov x0, x25
6d82504: str wzr, [x19, #0x84]
6d82508: bl #0x68bf588
6d8250c: str xzr, [x19, #0x88]
6d82510: ldp x20, x19, [sp, #0x40]
6d82514: ldp x22, x21, [sp, #0x30]
6d82518: ldp x24, x23, [sp, #0x20]
6d8251c: ldr x25, [sp, #0x10]
6d82520: ldp x29, x30, [sp], #0x50
6d82524: ret 
