6e938a0: sub sp, sp, #0x1c0
6e938a4: stp d9, d8, [sp, #0x160]
6e938a8: stp x29, x30, [sp, #0x170]
6e938ac: str x28, [sp, #0x180]
6e938b0: stp x24, x23, [sp, #0x190]
6e938b4: stp x22, x21, [sp, #0x1a0]
6e938b8: stp x20, x19, [sp, #0x1b0]
6e938bc: add x29, sp, #0x170
6e938c0: mrs x24, tpidr_el0
6e938c4: add x22, x0, #0x2c8
6e938c8: mov x21, x0
6e938cc: ldr x8, [x24, #0x28]
6e938d0: mov x0, x22
6e938d4: mov w1, wzr
6e938d8: stur x8, [x29, #-0x18]
6e938dc: bl #0x6a3863c
6e938e0: tbz w0, #0, #0x6e93aa8
6e938e4: add x19, x21, #0x358
6e938e8: mov x0, x19
6e938ec: bl #0x6a3562c
6e938f0: mov x20, x0
6e938f4: mov x0, x22
6e938f8: mov w1, wzr
6e938fc: bl #0x6e9427c
6e93900: mov x0, x21
6e93904: bl #0x6a36a38
6e93908: mov w8, #0x4ed4
6e9390c: ldr x9, [x0]
6e93910: add x8, x20, x8
6e93914: ldr w10, [x0, #8]
6e93918: mov x0, x21
6e9391c: str x9, [x8]
6e93920: str w10, [x8, #8]
6e93924: bl #0x6e942a4
6e93928: mov w8, #0x4ee0
6e9392c: ldr x9, [x0]
6e93930: add x8, x20, x8
6e93934: ldr w10, [x0, #8]
6e93938: mov x0, x21
6e9393c: strb wzr, [x20, #0xa0]
6e93940: str x9, [x20, #0x4ee0]
6e93944: str w10, [x8, #8]
6e93948: bl #0x6e942ac
6e9394c: mov x22, x0
6e93950: mov x0, x20
6e93954: bl #0x6e942b4
6e93958: ldr q0, [x22]
6e9395c: add x1, x21, #0x30
6e93960: mov w2, #0x128
6e93964: str q0, [x0]
6e93968: add x0, sp, #0x30
6e9396c: bl #0x8b35300
6e93970: ldrb w8, [x21, #0x2d3]
6e93974: cbz w8, #0x6e939c0
6e93978: add x8, sp, #8
6e9397c: add x0, sp, #0x30
6e93980: bl #0x6e942c0
6e93984: adrp x23, #0x9959000
6e93988: add x23, x23, #0xf98
6e9398c: ldr w8, [x23]
6e93990: cmp w8, #1
6e93994: b.lt #0x6e939d8
6e93998: mov w22, wzr
6e9399c: add x2, sp, #8
6e939a0: mov x0, x20
6e939a4: mov w1, w22
6e939a8: bl #0x6a6b604
6e939ac: ldr w8, [x23]
6e939b0: add w22, w22, #1
6e939b4: cmp w22, w8
6e939b8: b.lt #0x6e9399c
6e939bc: b #0x6e939d8
6e939c0: mov x0, x21
6e939c4: bl #0x6e93adc
6e939c8: and w2, w0, #1
6e939cc: add x0, sp, #0x30
6e939d0: mov x1, x20
6e939d4: bl #0x6ea1e90
6e939d8: add x0, x21, #0x158
6e939dc: add x1, sp, #0x30
6e939e0: mov w2, #0x128
6e939e4: bl #0x8b35300
6e939e8: add x22, x21, #0x448
6e939ec: mov x0, x22
6e939f0: bl #0x68d3054
6e939f4: mov x23, x0
6e939f8: bl #0x68d30b0
6e939fc: mov x0, x23
6e93a00: fmov s9, s0
6e93a04: bl #0x698e774
6e93a08: mov x0, x22
6e93a0c: fmov s8, s0
6e93a10: bl #0x68b9130
6e93a14: bl #0x68c8c14
6e93a18: bl #0x69a5790
6e93a1c: bl #0x6836fbc
6e93a20: mov w22, w0
6e93a24: bl #0x68c8c14
6e93a28: bl #0x6adb3b8
6e93a2c: bl #0x723770c
6e93a30: ldr s0, [x21, #0x30]
6e93a34: mov w23, w0
6e93a38: bl #0x684c680
6e93a3c: fcmp s0, s9
6e93a40: b.gt #0x6e93a94
6e93a44: ldr s0, [x21, #0x38]
6e93a48: bl #0x684c680
6e93a4c: fcmp s0, s8
6e93a50: b.gt #0x6e93a94
6e93a54: cmp w22, #9
6e93a58: b.ne #0x6e93a64
6e93a5c: cmp w23, #1
6e93a60: b.hi #0x6e93a94
6e93a64: cmp w22, #0xa
6e93a68: b.hi #0x6e93aa0
6e93a6c: mov w8, #1
6e93a70: mov w9, #0x554
6e93a74: lsl w8, w8, w22
6e93a78: tst w8, w9
6e93a7c: b.eq #0x6e93aa0
6e93a80: bl #0x68c8c14
6e93a84: bl #0x69a5790
6e93a88: bl #0x68b6d14
6e93a8c: cmp w0, #3
6e93a90: b.eq #0x6e93aa0
6e93a94: mov x0, x20
6e93a98: mov w1, wzr
6e93a9c: bl #0x6e94310
6e93aa0: mov x0, x19
6e93aa4: bl #0x68b9464
6e93aa8: ldr x8, [x24, #0x28]
6e93aac: ldur x9, [x29, #-0x18]
6e93ab0: cmp x8, x9
6e93ab4: b.ne #0x6e93ad8
6e93ab8: ldp x20, x19, [sp, #0x1b0]
6e93abc: ldp x22, x21, [sp, #0x1a0]
6e93ac0: ldp x24, x23, [sp, #0x190]
6e93ac4: ldp x29, x30, [sp, #0x170]
6e93ac8: ldp d9, d8, [sp, #0x160]
6e93acc: ldr x28, [sp, #0x180]
6e93ad0: add sp, sp, #0x1c0
6e93ad4: ret 
6e93ad8: bl #0x8b35290
